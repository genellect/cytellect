"""Durable worker."""
