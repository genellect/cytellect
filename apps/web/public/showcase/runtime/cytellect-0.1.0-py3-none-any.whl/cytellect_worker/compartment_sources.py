"""Locate each field's saved compartment-summary.json for a reviewed nucleoplasm revision.

The current measurement's summary is preferred: background remeasurement keeps
the mask but changes corrected summaries and dependency references. Historical
raw-only children may fall back to the mask origin after verifying mask identity.
"""
import numpy as np
from cytellect_analysis.compartment_observations import require_compartment_source
from cytellect_analysis.masks import validate_label_array
from cytellect_analysis.regions import _array_hash
from cytellect_api.db import revisions
from cytellect_api.storage import read_json


def load_compartment_summaries(store, rev, report):
    recipe = rev["config"].get("recipe", {})
    require_compartment_source(recipe, recipe.get("region_set_id"))
    summaries = {}
    for fid in sorted(report["field_tables"]):
        mask = report.get("field_masks", {}).get(fid)
        if not mask:
            raise ValueError("compartment_summary_unavailable")
        current_summary = store.safe_path(rev["result_dir"], fid, "compartment-summary.json")
        origin = rev if current_summary.is_file() else store.one(revisions, id=mask["mask_revision_id"])
        if (not current_summary.is_file()
                and (rev["config"].get("measurement") or {}).get("mode") == "automatic_background"):
            raise ValueError("compartment_summary_unavailable")
        if (origin is None or origin["workspace_id"] != rev["workspace_id"] or origin["state"] != "succeeded"
                or not origin["result_dir"]):
            raise ValueError("compartment_summary_unavailable")
        # The origin must itself derive nucleoplasm from adopted nucleoli; its summary
        # records which nucleolar revision, and the mask hash binds it to this report.
        require_compartment_source(origin["config"].get("recipe"), recipe.get("region_set_id"))
        folder = store.safe_path(origin["result_dir"], fid)
        labels_path, summary_path = folder / "labels.npy", folder / "compartment-summary.json"
        if any(path.is_symlink() or not path.is_file() for path in (labels_path, summary_path)):
            raise ValueError("compartment_summary_unavailable")
        labels = np.load(labels_path, allow_pickle=False)
        validate_label_array(labels)
        if list(labels.shape) != mask["shape"] or _array_hash(labels, "<u4") != mask["mask_sha256"]:
            raise ValueError("compartment_summary_mask_mismatch")
        # A remeasurement may keep its own summary and label copy, but its report
        # still names the adopted canonical mask. Bind both copies to that identity.
        mask_origin = store.one(revisions, id=mask["mask_revision_id"])
        if (mask_origin is None or mask_origin["workspace_id"] != rev["workspace_id"]
                or mask_origin["state"] != "succeeded" or not mask_origin["result_dir"]):
            raise ValueError("compartment_summary_unavailable")
        canonical_path = store.safe_path(mask_origin["result_dir"], fid, "labels.npy")
        if canonical_path.is_symlink() or not canonical_path.is_file():
            raise ValueError("compartment_summary_unavailable")
        if canonical_path != labels_path:
            canonical = np.load(canonical_path, allow_pickle=False)
            validate_label_array(canonical)
            if list(canonical.shape) != mask["shape"] or _array_hash(canonical, "<u4") != mask["mask_sha256"]:
                raise ValueError("compartment_summary_mask_mismatch")
        summaries[fid] = read_json(summary_path)
    return summaries


def load_nucleolar_shapes(store, rev, report, summaries):
    """Per-nucleus nucleolar shapes from the adopted nuclear and nucleolar masks of each field.

    Each field uses its own source revision (a cohort pins one per field). The shapes are
    bound to the saved summary: every summarized nucleus must have the same nuclear and
    nucleolar-union pixel areas in these masks.
    """
    from cytellect_analysis.nucleolar_shape import nucleolar_eccentricity
    from cytellect_analysis.region_contracts import RegionCompartmentRecipe, RegionImageInfo

    from .regions import _adopted_nucleoli, _compartment_nuclei

    shapes = {}
    pins = rev["config"].get("cohort_sources") or {}
    for fid in sorted(report["field_tables"]):
        source = store.one(revisions, id=pins[fid]["revision_id"]) if fid in pins else rev
        if (source is None or source["workspace_id"] != rev["workspace_id"] or source["state"] != "succeeded"
                or fid not in source["config"].get("field_snapshot", {})):
            raise ValueError("compartment_summary_shape_unavailable")
        recipe = RegionCompartmentRecipe.model_validate(source["config"]["recipe"])
        if recipe.nucleolar_revision_id is None:
            raise ValueError("compartment_summary_shape_unavailable")
        image_info = RegionImageInfo.model_validate(source["config"]["field_snapshot"][fid]["image_info"])
        nuclei, _, _ = _compartment_nuclei(store, recipe, rev["workspace_id"], fid, image_info)
        nucleoli, _, _ = _adopted_nucleoli(store, recipe, rev["workspace_id"], fid, image_info)
        rows = next(iter(summaries[fid]["channels"].values()))["rows"]
        for row in rows:
            nucleus = nuclei == row["nucleus_id"]
            if (int(nucleus.sum()) != row["nucleus_area_px"]
                    or int((nucleus & (nucleoli > 0)).sum()) != row["nucleolar_area_px"]):
                raise ValueError("compartment_summary_shape_mismatch")
        shapes[fid] = nucleolar_eccentricity(nuclei, nucleoli)
    return shapes
