"""Pinned, offline Cellpose-SAM candidates; original-coordinate integer labels."""
from __future__ import annotations

import functools
import hashlib
import http.client
import io
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

import numpy as np
from pydantic import Field, FiniteFloat, model_validator
from scipy import ndimage as ndi

from .masks import validate_label_array
from .regions import RegionModel, _array_hash

MODEL_SHA256: Literal["0f1cc3f7ecdd8a037a57c6c48d9d8921391be4cbce3fa9f13c3e3a2e1253c667"] = "0f1cc3f7ecdd8a037a57c6c48d9d8921391be4cbce3fa9f13c3e3a2e1253c667"
MODEL_SIZE = 1233586851
NCL_MODEL_ID = "ncl-r1-step0375"
NCL_MODEL_SHA256 = "bc5ea7f25ce9a9f96e9ff510cee20587e1328ac834a0f7f82aee0bc06156d906"
NCL_MODEL_SIZE = 1233577155
NCL_750_MODEL_ID = "ncl-r1-step0750"
NCL_750_MODEL_SHA256 = "9d2c2ec06aa1aa71f36695b49b0828f82fd3cb633da2832c99a9f194d0bd4099"
NCL_MODEL_HASHES = {NCL_MODEL_ID: NCL_MODEL_SHA256, NCL_750_MODEL_ID: NCL_750_MODEL_SHA256}


class CellposeParameters(RegionModel):
    model: Literal["cpsam_v2", "ncl-r1-step0375", "ncl-r1-step0750"] = "cpsam_v2"
    model_sha256: Literal[
        "0f1cc3f7ecdd8a037a57c6c48d9d8921391be4cbce3fa9f13c3e3a2e1253c667",
        "bc5ea7f25ce9a9f96e9ff510cee20587e1328ac834a0f7f82aee0bc06156d906",
        "9d2c2ec06aa1aa71f36695b49b0828f82fd3cb633da2832c99a9f194d0bd4099",
    ] = MODEL_SHA256
    diameter_px: FiniteFloat | None = Field(default=None, gt=0, le=4096)
    normalization_percentile_low: FiniteFloat = Field(default=1.0, ge=0, lt=100)
    normalization_percentile_high: FiniteFloat = Field(default=99.0, gt=0, le=100)
    flow_threshold: FiniteFloat = Field(default=0.4, gt=0, le=10)
    cellprob_threshold: FiniteFloat = Field(default=0.0, ge=-20, le=20)
    minimum_area_px: int = Field(default=15, ge=1, le=16777216)
    maximum_size_fraction: FiniteFloat = Field(default=1.0, gt=0, le=1)
    iterations: int | None = Field(default=None, ge=1, le=10000)
    batch_size: int = Field(default=1, ge=1, le=8)
    compute_device: Literal["cpu", "auto", "cuda"] = "cpu"

    @model_validator(mode="after")
    def ordered_percentiles(self):
        if self.normalization_percentile_low >= self.normalization_percentile_high:
            raise ValueError("cellpose_normalization_range_invalid")
        return self


class CellposeDetectorSpec(CellposeParameters):
    model: Literal["cpsam_v2"] = "cpsam_v2"
    model_sha256: Literal["0f1cc3f7ecdd8a037a57c6c48d9d8921391be4cbce3fa9f13c3e3a2e1253c667"] = MODEL_SHA256
    engine: Literal["cellpose-sam"] = "cellpose-sam"
    protocol_version: Literal["4.0.0"] = "4.0.0"


class NclCellposeDetectorSpec(CellposeParameters):
    model: Literal["cpsam_v2"] = "cpsam_v2"
    model_sha256: Literal["0f1cc3f7ecdd8a037a57c6c48d9d8921391be4cbce3fa9f13c3e3a2e1253c667"] = MODEL_SHA256
    engine: Literal["cellpose-sam-ncl"] = "cellpose-sam-ncl"
    protocol_version: Literal["4.1.0"] = "4.1.0"
    smoothing_sigma_px: FiniteFloat = Field(default=0.9, gt=0, le=16)
    background_radius_px: int = Field(default=10, ge=1, le=128)


class NclParentCellposeDetectorSpec(CellposeParameters):
    """Parent-conditioned NCL copy; 4.0/4.1 replay is deliberately unchanged."""
    engine: Literal["cellpose-sam-ncl-parent"] = "cellpose-sam-ncl-parent"
    protocol_version: Literal["4.2.0", "4.2.1", "4.3.0"] = "4.3.0"
    smoothing_sigma_px: FiniteFloat = Field(default=0.9, gt=0, le=16)
    parent_background_percentile: FiniteFloat = Field(default=75, ge=0, lt=100)
    nuclear_diameter_fraction: FiniteFloat = Field(default=0.25, gt=0, le=1)
    crop_padding_px: int = Field(default=32, ge=1, le=256)
    minimum_contrast_snr: FiniteFloat = Field(default=5, gt=0, le=100)
    local_background_radius_px: int = Field(default=8, ge=1, le=128)
    maximum_nuclear_coverage: FiniteFloat = Field(default=0.5, gt=0, lt=1)

    @model_validator(mode="after")
    def pinned_model_selection(self):
        expected = MODEL_SHA256 if self.model == "cpsam_v2" else NCL_MODEL_HASHES[self.model]
        if self.model_sha256 != expected:
            raise ValueError("cellpose_model_identity_mismatch")
        if self.model != "cpsam_v2" and self.protocol_version != "4.3.0":
            raise ValueError("cellpose_model_protocol_mismatch")
        return self


def model_profile(lock: dict, model_id: str = "cpsam_v2") -> dict:
    """Resolve only registered identities, never a job-supplied URL."""
    expected_sha: str
    if model_id == "cpsam_v2":
        profile, expected_sha, expected_size = lock["model"], MODEL_SHA256, MODEL_SIZE
    elif model_id in NCL_MODEL_HASHES:
        profile = lock.get("ncl_candidates", {}).get(model_id)
        expected_sha, expected_size = NCL_MODEL_HASHES[model_id], NCL_MODEL_SIZE
    else:
        raise ValueError("cellpose_model_identity_mismatch")
    if (not isinstance(profile, dict) or profile.get("id") != model_id
            or profile.get("sha256") != expected_sha or profile.get("size") != expected_size):
        raise ValueError("cellpose_model_identity_mismatch")
    return profile


def _assets() -> Path:
    configured = os.environ.get("CYTELLECT_CELLPOSE_ASSETS")
    if configured:
        return Path(configured)
    for parent in Path(__file__).resolve().parents:
        candidate = parent / "engines" / "cellpose"
        if (candidate / "runtime.lock.json").is_file():
            return candidate
    # Windows wheels can live outside the extracted application. The managed
    # launcher fixes cwd to that version's app directory. Accept only its
    # release-bound adapter; never search arbitrary sibling/global directories.
    root = Path.cwd()
    candidate = root / "engines" / "cellpose"
    if (candidate / "runtime.lock.json").is_file():
        _verify_release_assets(root, candidate)
        return candidate
    raise ValueError("cellpose_adapter_missing")


def _verify_file(path: Path, expected: str, size: int | None, error: str):
    if not path.is_file():
        raise ValueError(error)
    stat = path.stat()
    if size is not None and stat.st_size != size:
        raise ValueError(error)
    # Windows timestamps can stay unchanged across a same-size rewrite. Hash
    # the bytes before use instead of treating metadata as an integrity check.
    with path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != expected:
        raise ValueError(error)


def _verify_release_assets(root: Path, assets: Path):
    """Bind the cwd fallback to the installer's complete release manifest."""
    error = "cellpose_adapter_integrity_failed"
    try:
        release = json.loads((root / "local-release.json").read_text(encoding="utf-8"))
        if (not isinstance(release, dict) or release.get("schema") != "cytellect-local-release/1"
                or release.get("platform") != "windows-x64"):
            raise ValueError(error)
        files = release.get("files")
        if not isinstance(files, list) or any(not isinstance(entry, dict) for entry in files):
            raise ValueError(error)
        for name in ("runtime.lock.json", "gpu.lock.json", "runner.py", "requirements.lock"):
            relative = f"engines/cellpose/{name}"
            entries = [entry for entry in files if entry.get("path") == relative]
            path = assets / name
            if len(entries) != 1 or not path.resolve().is_relative_to(root.resolve()):
                raise ValueError(error)
            if any(part.is_symlink() or part.is_junction() for part in [path, assets, assets.parent, root]):
                raise ValueError(error)
            _verify_file(path, entries[0]["sha256"], entries[0]["size"], error)
        lock = json.loads((assets / "runtime.lock.json").read_text(encoding="utf-8"))
        if (not isinstance(lock, dict) or not isinstance(lock.get("model"), dict)
                or lock.get("schema") != "cytellect-cellpose-runtime/1" or lock.get("python") != "3.12"
                or lock["model"]["sha256"] != MODEL_SHA256 or lock["model"]["size"] != MODEL_SIZE):
            raise ValueError(error)
        _verify_file(assets / "runner.py", lock["runner_sha256"], None, error)
        _verify_file(assets / "requirements.lock", lock["requirements_sha256"], None, error)
    except (OSError, KeyError, TypeError, json.JSONDecodeError) as exception:
        raise ValueError(error) from exception


REMOTE_WAIT_SECONDS = 900
REMOTE_REQUEST_TIMEOUT_SECONDS = 1800
REMOTE_RESPONSE_LIMIT = 512 * 1024 * 1024


CLOUD_ACCOUNT_SCHEMA = "cytellect-cloud-account/1"


def _service_url(url: str) -> str:
    parts = urlsplit(url)
    loopback = parts.hostname in {"127.0.0.1", "localhost", "::1"}
    if (parts.scheme not in {"https", "http"} or (parts.scheme == "http" and not loopback) or not parts.hostname
            or parts.username or parts.password or parts.query or parts.fragment):
        raise ValueError("cellpose_remote_url_invalid")
    return url.rstrip("/")


def remote_endpoint() -> str | None:
    """Explicitly configured GPU inference service; https only, except a loopback test service."""
    url = os.environ.get("CYTELLECT_CELLPOSE_REMOTE_URL", "").strip()
    return _service_url(url) if url else None


def _cloud_account() -> tuple[str, str] | None:
    """The signed-in Windows installation's cloud service and device token.

    The local launcher names the account file; it is read at each use so signing
    in or out takes effect without restarting the worker. The token goes only to
    the base URL that issued it, under its ``/v1/cellpose`` routes.
    """
    configured = os.environ.get("CYTELLECT_CLOUD_ACCOUNT_FILE", "")
    if not configured:
        return None
    path = Path(configured)
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 16_384:
            return None
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(value, dict) or value.get("schema") != CLOUD_ACCOUNT_SCHEMA or value.get("state") != "allowed":
        return None
    token, base = value.get("device_token"), value.get("base_url")
    if (not isinstance(token, str) or not isinstance(base, str)
            or not 20 <= len(token) <= 512 or any(c.isspace() or not c.isascii() for c in token)):
        return None
    return _service_url(base) + "/v1/cellpose", token


def remote_target() -> tuple[str, dict[str, str]] | None:
    """Explicit CYTELLECT_CELLPOSE_REMOTE_* settings first, then the signed-in cloud account."""
    url = remote_endpoint()
    if url is not None:
        headers = {}
        if os.environ.get("CYTELLECT_CELLPOSE_REMOTE_TOKEN"):
            headers["Authorization"] = "Bearer " + os.environ["CYTELLECT_CELLPOSE_REMOTE_TOKEN"]
        if os.environ.get("CYTELLECT_CELLPOSE_REMOTE_SECRET"):
            headers["X-Cytellect-Secret"] = os.environ["CYTELLECT_CELLPOSE_REMOTE_SECRET"]
        return url, headers
    account = _cloud_account()
    if account is not None:
        return account[0], {"Authorization": "Bearer " + account[1]}
    return None


def _remote_status(assets: Path, model_id: str = "cpsam_v2") -> dict:
    lock = json.loads((assets / "runtime.lock.json").read_text(encoding="utf-8"))
    gpu = json.loads((assets / "gpu.lock.json").read_text(encoding="utf-8"))
    _verify_file(assets / "runner.py", lock["runner_sha256"], None, "cellpose_adapter_integrity_failed")
    if gpu["runner_sha256"] != lock["runner_sha256"] or gpu["model"]["sha256"] != MODEL_SHA256:
        raise ValueError("cellpose_adapter_integrity_failed")
    profile = model_profile(lock, model_id)
    if model_profile(gpu, model_id) != profile:
        raise ValueError("cellpose_model_identity_mismatch")
    return {"available": True, "backend": "remote", "model": model_id, "model_sha256": profile["sha256"],
            "packages": gpu["packages"], "python": "3.12", "runtime_downloads": False}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """A redirect would resend the image and the Authorization header to another URL; refuse it."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class _LazyOpener:
    """Builds the no-redirect opener at first use.

    Python 3.14 creates an SSL context when the HTTPS handler is built. Doing that
    at import time fails in restricted environments (e.g. a Windows child process
    without its usual variables) that never make a request.
    """

    def open(self, *args, **kwargs):
        return _no_redirect_opener().open(*args, **kwargs)


@functools.cache
def _no_redirect_opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(_NoRedirect)


_OPENER = _LazyOpener()


def _service_error(error: urllib.error.HTTPError) -> str:
    """The JSON ``error`` code of a failed response, or ''."""
    try:
        code = json.loads(error.read(4096).decode("utf-8")).get("error", "")
    except (OSError, ValueError, AttributeError):
        return ""
    return code if isinstance(code, str) else ""


def _remote_error(status: int, code: str) -> str:
    """A final failure as a fixed code; the cloud gateway's states get their own codes."""
    if 300 <= status < 400:
        return "cellpose_remote_failed"
    if status == 403 and code == "revoked":
        return "cellpose_remote_revoked"
    if status == 401 and code == "auth_required":
        return "cellpose_remote_auth_required"
    if status in (401, 403):
        return "cellpose_remote_rejected"
    if status == 429 and code == "quota_exceeded":
        return "cellpose_remote_quota_exceeded"
    if status == 503 and code == "gpu_service_disabled":
        return "cellpose_remote_disabled"
    return code if code.startswith("cellpose_") and len(code) < 80 else "cellpose_remote_failed"


def _remote_inference(image: np.ndarray, parent: np.ndarray | None, detector: CellposeParameters) -> tuple[np.ndarray, dict]:
    """Run the same pinned runner on the remote service; only raw labels come back.

    Binding to nuclei, refinement and measurement stay local. The service must
    report the runner, model and package lock this release expects.
    """
    target = remote_target()
    if target is None:
        raise ValueError("cellpose_remote_url_invalid")
    url, credentials = target
    assets = _assets()
    lock = json.loads((assets / "runtime.lock.json").read_text(encoding="utf-8"))
    gpu = json.loads((assets / "gpu.lock.json").read_text(encoding="utf-8"))
    parameters = detector.model_dump(mode="json")
    # compute_device states a preference; the remote service uses its GPU and the
    # receipt records the device actually used next to the requested value.
    requested_device, parameters["compute_device"] = parameters["compute_device"], "auto"
    request = json.dumps({"parameters": parameters}).encode("utf-8")
    stream = io.BytesIO()
    if parent is None:
        np.savez_compressed(stream, request=np.frombuffer(request, dtype=np.uint8), image=image)
    else:
        np.savez_compressed(stream, request=np.frombuffer(request, dtype=np.uint8), image=image, parent=parent)
    headers = {"Content-Type": "application/octet-stream", "Accept": "application/octet-stream",
               # Hugging Face holds the request while a scaled-to-zero endpoint starts.
               "X-Scale-Up-Timeout": str(REMOTE_WAIT_SECONDS), **credentials}
    deadline, delay = time.monotonic() + REMOTE_WAIT_SECONDS, 5.0
    while True:
        try:
            outgoing = urllib.request.Request(url + "/v1/cellpose", data=stream.getvalue(), headers=headers, method="POST")
            with _OPENER.open(outgoing, timeout=REMOTE_REQUEST_TIMEOUT_SECONDS) as response:
                content = response.read(REMOTE_RESPONSE_LIMIT + 1)
            break
        except urllib.error.HTTPError as error:
            # 502-504 while the endpoint starts or restarts (also gpu_starting/gpu_busy);
            # anything else is final. A disabled service or invalid upstream does not
            # recover by waiting. Redirects are refused (see _OPENER) and are final.
            code = _service_error(error)
            starting = error.code in (502, 503, 504) and code not in ("gpu_service_disabled", "gpu_upstream_invalid")
            if not starting:
                raise ValueError(_remote_error(error.code, code)) from None
            if time.monotonic() + delay > deadline:
                raise ValueError("cellpose_remote_unavailable") from None
        except (urllib.error.URLError, http.client.HTTPException, ConnectionError, TimeoutError):
            if time.monotonic() + delay > deadline:
                raise ValueError("cellpose_remote_unreachable") from None
        time.sleep(delay)
        delay = min(delay * 2, 30.0)
    if len(content) > REMOTE_RESPONSE_LIMIT:
        raise ValueError("cellpose_remote_output_invalid")
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            if sum(item.file_size for item in archive.infolist()) > REMOTE_RESPONSE_LIMIT * 4:
                raise ValueError("cellpose_remote_output_invalid")
        with np.load(io.BytesIO(content), allow_pickle=False) as arrays:
            if set(arrays.files) != {"labels", "receipt"}:
                raise ValueError("cellpose_remote_output_invalid")
            raw, receipt = arrays["labels"], json.loads(arrays["receipt"].tobytes().decode("utf-8"))
    except (zipfile.BadZipFile, OSError, ValueError, UnicodeDecodeError) as error:
        if isinstance(error, ValueError) and str(error).startswith("cellpose_"):
            raise
        raise ValueError("cellpose_remote_output_invalid") from error
    service = receipt.get("service") if isinstance(receipt, dict) else None
    accepted_runners = {lock["runner_sha256"]}
    if detector.model == "cpsam_v2":
        accepted_runners.add(gpu["baseline_runner_sha256"])
    if (not isinstance(service, dict) or service.get("runner_sha256") not in accepted_runners
            or service.get("model_sha256") != detector.model_sha256
            or service.get("requirements_sha256") not in {lock["requirements_sha256"], gpu["requirements_sha256"]}):
        raise ValueError("cellpose_remote_version_mismatch")
    receipt["execution_backend"] = {"kind": "remote", "host": urlsplit(url).hostname,
                                    "requested_compute_device": requested_device}
    return raw, receipt


def runtime_status(model_id: str = "cpsam_v2") -> dict:
    """Sanitized capability probe, without loading Torch or making requests."""
    try:
        if remote_target():
            return _remote_status(_assets(), model_id)
        assets = _assets()
        lock = json.loads((assets / "runtime.lock.json").read_text(encoding="utf-8"))
        python = os.environ.get("CYTELLECT_CELLPOSE_PYTHON")
        model_dir = os.environ.get("CYTELLECT_CELLPOSE_MODEL_DIR")
        if not python or not Path(python).is_file():
            raise ValueError("cellpose_runtime_missing")
        if not model_dir:
            raise ValueError("cellpose_model_missing")
        _verify_file(assets / "runner.py", lock["runner_sha256"], None, "cellpose_adapter_integrity_failed")
        profile = model_profile(lock, model_id)
        model = Path(model_dir) / profile["id"]
        if not model.is_file():
            raise ValueError("cellpose_model_missing")
        _verify_file(model, profile["sha256"], profile["size"], "cellpose_model_integrity_failed")
        return {"available": True, "model": model_id, "model_sha256": profile["sha256"], "model_identity": profile,
                "packages": lock["packages"], "python": "3.12", "runtime_downloads": False}
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as error:
        message = str(error)
        return {"available": False, "error": message if message.startswith("cellpose_")
                else "cellpose_runtime_invalid", "runtime_downloads": False}


def exclude_nuclear_scale_candidates(raw: np.ndarray, nuclei: np.ndarray, maximum_coverage: float) -> tuple[np.ndarray, list[dict]]:
    """Remove whole candidate instances, never subtract adopted nuclear pixels.

    A candidate must be predominantly in one parent (90% of its pixels) and
    occupy more than the recorded fraction of that parent. Boundary/ambiguous
    candidates still go through the independent parent binder. Raw labels stay
    available as an artifact; a rejected nucleus does not imply absent nucleoli.
    """
    validate_label_array(raw)
    validate_label_array(nuclei)
    if raw.shape != nuclei.shape:
        raise ValueError("cellpose_parent_shape_invalid")
    if not 0 < maximum_coverage < 1:
        raise ValueError("cellpose_nuclear_coverage_invalid")
    filtered = raw.copy()
    parent_area = {int(v): int(count) for v, count in zip(*np.unique(nuclei, return_counts=True)) if v}
    excluded = []
    for source in (int(v) for v in np.unique(raw) if v):
        pieces, count = ndi.label(raw == source, np.ones((3, 3), bool))
        for component in range(1, count + 1):
            mask = pieces == component
            ids, overlaps = np.unique(nuclei[mask], return_counts=True)
            for parent, overlap in zip(ids, overlaps):
                if not parent:
                    continue
                coverage = float(overlap / parent_area[int(parent)])
                purity = float(overlap / mask.sum())
                if coverage > maximum_coverage and purity >= 0.9:
                    filtered[mask] = 0
                    excluded.append({"source_label_id": source, "component": component,
                                     "parent_id": int(parent), "reason": "nuclear_scale_candidate",
                                     "nuclear_coverage": coverage, "parent_purity": purity})
                    break
    return filtered, excluded


def bind_nucleolar_candidates(raw: np.ndarray, nuclei: np.ndarray) -> tuple[np.ndarray, dict]:
    """Reject ambiguous/boundary objects whole, retaining raw masks for review."""
    validate_label_array(raw)
    validate_label_array(nuclei)
    if raw.shape != nuclei.shape:
        raise ValueError("cellpose_parent_shape_invalid")
    labels = np.zeros_like(raw, dtype=np.uint32)
    states = {int(value): "no_candidate" for value in np.unique(nuclei) if value}
    parents: dict[int, int] = {}
    objects: dict[int, dict] = {}
    review: list[dict] = []
    next_id = 1
    for source_id in (int(value) for value in np.unique(raw) if value):
        # Defensive split: disconnected pixels must never share one object ID.
        pieces, count = ndi.label(raw == source_id, np.ones((3, 3), dtype=bool))
        for piece in range(1, count + 1):
            mask = pieces == piece
            present = np.unique(nuclei[mask])
            nonzero = [int(value) for value in present if value]
            reason = None
            if not nonzero:
                reason = "outside_adopted_nuclei"
            elif len(nonzero) != 1:
                reason = "multiple_parent_nuclei"
            elif 0 in present:
                reason = "crosses_nuclear_boundary"
            elif (mask & ~ndi.binary_erosion(nuclei == nonzero[0], np.ones((3, 3), bool))).any():
                reason = "touches_nuclear_boundary"
            if reason:
                review.append({"source_label_id": source_id, "component": piece,
                               "reason": reason, "parent_ids": nonzero})
                for parent in nonzero:
                    states[parent] = "review_required"
                continue
            parent = nonzero[0]
            labels[mask] = next_id
            parents[next_id] = parent
            objects[next_id] = {"parent_id": parent, "source_label_id": source_id, "component": piece}
            if states[parent] != "review_required":
                states[parent] = "candidate"
            next_id += 1
    return labels, {"parent_ids": parents, "objects": objects, "nucleolar_states": states,
                    "review_candidates": review, "review_candidate_count": len(review),
                    "parent_policy": "fully_contained_single_parent_no_clipping"}


def detect_cellpose(image: np.ndarray, detector: CellposeDetectorSpec | NclCellposeDetectorSpec | NclParentCellposeDetectorSpec, output_dir: Path,
                    nuclei: np.ndarray | None = None) -> tuple[np.ndarray, dict]:
    detector = (NclParentCellposeDetectorSpec.model_validate(detector) if isinstance(detector, NclParentCellposeDetectorSpec)
                else NclCellposeDetectorSpec.model_validate(detector) if isinstance(detector, NclCellposeDetectorSpec)
                else CellposeDetectorSpec.model_validate(detector))
    if image.ndim != 2 or image.dtype not in (np.uint8, np.uint16) or not image.size:
        raise ValueError("cellpose_input_invalid")
    if nuclei is not None:
        validate_label_array(nuclei)
        if nuclei.shape != image.shape:
            raise ValueError("cellpose_parent_shape_invalid")
    if isinstance(detector, NclParentCellposeDetectorSpec) and nuclei is None:
        raise ValueError("cellpose_adopted_nuclei_required")
    capability = runtime_status() if detector.model == "cpsam_v2" else runtime_status(detector.model)
    if not capability["available"]:
        raise ValueError(capability["error"])
    assets = _assets()
    lock = json.loads((assets / "runtime.lock.json").read_text(encoding="utf-8"))
    profile = model_profile(lock, detector.model)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    source, raw_path = output_dir / "cellpose-input.npy", output_dir / "cellpose-raw-labels.npy"
    request_path, receipt_path = output_dir / "cellpose-request.json", output_dir / "cellpose-receipt.json"
    parent_path = output_dir / "cellpose-parent-input.npy"
    parent = nuclei if isinstance(detector, NclParentCellposeDetectorSpec) else None
    try:
        if capability.get("backend") == "remote":
            remote_raw, remote_receipt = _remote_inference(image, parent, detector)
            np.save(raw_path, remote_raw, allow_pickle=False)
            receipt_path.write_text(json.dumps(remote_receipt), encoding="utf-8")
            returncode = 0
        else:
            np.save(source, image, allow_pickle=False)
            request = {"input_path": str(source.resolve()), "output_path": str(raw_path.resolve()),
                       "model_path": str((Path(os.environ["CYTELLECT_CELLPOSE_MODEL_DIR"]) / profile["id"]).resolve()),
                       "parameters": detector.model_dump(mode="json")}
            if isinstance(detector, NclParentCellposeDetectorSpec):
                assert nuclei is not None
                np.save(parent_path, nuclei, allow_pickle=False)
                request["parent_path"] = str(parent_path.resolve())
            request_path.write_text(json.dumps(request), encoding="utf-8")
            environment = os.environ.copy()
            environment.update({"HF_HUB_OFFLINE": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"})
            environment.pop("PYTHONPATH", None)
            environment.pop("HF_TOKEN", None)
            environment.pop("HUGGING_FACE_HUB_TOKEN", None)
            result = subprocess.run([os.environ["CYTELLECT_CELLPOSE_PYTHON"], "-I", str(assets / "runner.py"),
                                     str(request_path.resolve()), str(receipt_path.resolve())],
                                    capture_output=True, env=environment, timeout=1800, check=False)
            returncode = result.returncode
        if not receipt_path.is_file():
            raise ValueError("cellpose_inference_failed")
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        if returncode or receipt.get("status") != "succeeded":
            code = receipt.get("error", "cellpose_inference_failed")
            raise ValueError(code if code.startswith("cellpose_") and len(code) < 80 else "cellpose_inference_failed")
        if detector.model != "cpsam_v2" and receipt.get("model_identity") != profile:
            raise ValueError("cellpose_model_identity_mismatch")
        raw = np.load(raw_path, allow_pickle=False)
        try:
            validate_label_array(raw)
        except ValueError as error:
            raise ValueError("cellpose_output_invalid") from error
        if raw.shape != image.shape:
            raise ValueError("cellpose_output_shape_invalid")
        binding_input = raw
        nuclear_exclusions: list[dict] = []
        if isinstance(detector, NclParentCellposeDetectorSpec) and detector.protocol_version in ("4.2.1", "4.3.0"):
            assert nuclei is not None
            binding_input, nuclear_exclusions = exclude_nuclear_scale_candidates(raw, nuclei, detector.maximum_nuclear_coverage)
        labels, binding = bind_nucleolar_candidates(binding_input, nuclei) if nuclei is not None else (raw.astype(np.uint32), {})
        if isinstance(detector, NclParentCellposeDetectorSpec) and detector.protocol_version in ("4.2.1", "4.3.0"):
            binding["nuclear_candidate_filter"] = {"protocol_version": "1.0.0", "maximum_nuclear_coverage": detector.maximum_nuclear_coverage,
                                                  "minimum_parent_purity": 0.9, "policy": "reject_whole_instance_keep_raw_artifact"}
            binding["nuclear_candidate_exclusions"] = nuclear_exclusions
            binding["indeterminate_parent_reasons"] = {}
            for exclusion in nuclear_exclusions:
                parent = exclusion["parent_id"]
                if binding["nucleolar_states"].get(parent) == "no_candidate":
                    binding["nucleolar_states"][parent] = "indeterminate"
                    binding["indeterminate_parent_reasons"][str(parent)] = "nuclear_scale_candidates_only"
        if isinstance(detector, NclParentCellposeDetectorSpec):
            for parent, reason in receipt.get("indeterminate_parents", {}).items():
                binding["nucleolar_states"][int(parent)] = "indeterminate"
            binding.setdefault("indeterminate_parent_reasons", {}).update(receipt.get("indeterminate_parents", {}))
            binding["parent_conditioning"] = receipt.get("parent_conditioning", [])
            binding["signal_review_candidates"] = receipt.get("signal_review_candidates", [])
        if nuclei is not None and receipt.get("normalization", {}).get("constant_signal"):
            binding["nucleolar_states"] = {parent: "indeterminate" for parent in binding["nucleolar_states"]}
            binding["indeterminate_reason"] = "constant_detection_signal"
        if isinstance(detector, NclParentCellposeDetectorSpec) and detector.protocol_version == "4.3.0":
            from .ncl_signal_support import refine_ncl_signal_support

            assert nuclei is not None
            anchors = labels.copy()
            np.save(output_dir / "cellpose-anchor-labels.npy", anchors, allow_pickle=False)
            labels, support, refined = refine_ncl_signal_support(image, anchors, nuclei)
            # Preserve source model identity, parent evidence and review states.
            for item in refined["objects"].values():
                item["source_model_objects"] = [binding["objects"][ident] for ident in item["source_anchor_ids"]]
            binding.update(refined)
            np.save(output_dir / "cellpose-signal-support-labels.npy", support, allow_pickle=False)
            binding.update({"anchor_mask_artifact": "cellpose-anchor-labels.npy",
                            "anchor_mask_sha256": _array_hash(anchors, "<u4"),
                            "signal_support_artifact": "cellpose-signal-support-labels.npy",
                            "signal_support_sha256": _array_hash(support, "<u4")})
        np.save(output_dir / "cellpose-labels.npy", labels, allow_pickle=False)
        info = {"engine": detector.engine, "nucleolar_detector_protocol_version": detector.protocol_version,
                "model": detector.model, "model_sha256": profile["sha256"],
                "model_identity": profile,
                "runtime_manifest_sha256": hashlib.sha256((assets / "runtime.lock.json").read_bytes()).hexdigest(),
                "runner_sha256": receipt.get("service", {}).get("runner_sha256", lock["runner_sha256"]),
                "parameters": detector.model_dump(mode="json"), "runtime": receipt,
                "detection_preprocessing": receipt.get("preprocessing", {"algorithm": "none"}),
                "source_sha256": _array_hash(image, image.dtype.newbyteorder("<").str),
                "mask_sha256": _array_hash(labels, "<u4"),
                "raw_mask_sha256": _array_hash(raw, "<u4"), "raw_mask_artifact": raw_path.name,
                "measurement_pixels": "original, unchanged", "coordinate_transform": receipt["coordinate_transform"],
                "input_dtype": str(image.dtype), "input_shape": list(image.shape),
                "mask_meaning": "Cellpose-SAM instance candidates, requiring researcher review", **binding}
        if nuclei is not None:
            info["nucleolar_definition_source"] = "marker"
        return labels, info
    except subprocess.TimeoutExpired as error:
        raise ValueError("cellpose_inference_timeout") from error
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("cellpose_inference_failed") from error
    finally:
        # Original research pixels/paths exist only within the private attempt.
        # Remove transient duplicated inputs/descriptors after execution.
        source.unlink(missing_ok=True)
        parent_path.unlink(missing_ok=True)
        request_path.unlink(missing_ok=True)
