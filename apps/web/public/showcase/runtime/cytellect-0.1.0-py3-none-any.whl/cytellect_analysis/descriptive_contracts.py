"""Explicit descriptive-only contracts; existing inferential requests are unchanged."""
from typing import Annotated, Any, Literal, Union

from pydantic import (
    BaseModel,
    ConfigDict,
    Discriminator,
    Field,
    FiniteFloat,
    StrictInt,
    Tag,
    TypeAdapter,
    model_serializer,
    model_validator,
)
from pydantic.json_schema import SkipJsonSchema

from .contracts import PlotSpec, StrictModel
from .regions import Id
from .statistical_methods import StatisticalMethodsTemplate

LegacyMetric = Literal[
    "ncl_nucleus_mean", "ncl_nucleus_median", "ncl_nucleus_integrated",
    "ncl_nucleus_mean_corrected", "ncl_nucleus_median_corrected", "ncl_nucleus_integrated_corrected",
    "ncl_nucleoli_mean", "ncl_nucleoli_median", "ncl_nucleoli_integrated",
    "ncl_nucleoli_mean_corrected", "ncl_nucleoli_median_corrected", "ncl_nucleoli_integrated_corrected",
    "ncl_nucleoplasm_mean", "ncl_nucleoplasm_median", "ncl_nucleoplasm_integrated",
    "ncl_nucleoplasm_mean_corrected", "ncl_nucleoplasm_median_corrected", "ncl_nucleoplasm_integrated_corrected",
    "gfp_mean", "gfp_median", "gfp_integrated", "gfp_mean_corrected", "gfp_median_corrected",
    "gfp_integrated_corrected", "nucleus_area_px", "nucleus_area_um2", "nucleolar_area_px",
    "nucleolar_area_um2", "nucleoplasm_area_px", "nucleoplasm_area_um2", "nucleolar_count",
    "nucleolar_area_fraction", "ncl_nucleoplasm_over_nucleoli", "ncl_log2_nucleoplasm_over_nucleoli",
    "ncl_legacy_release",
]
RegionMetric = Literal[
    "area_px", "area_um2", "mean", "median", "integrated",
    "mean_corrected", "median_corrected", "integrated_corrected",
]


class GfpGateFilter(StrictModel):
    """Optional nucleus filter 1.0.0: keep nuclei by the negative-control GFP gate (gfp-gate/2.0.0).

    The percentile is the researcher's recorded choice (50 to <100); it is never
    searched or tuned by the software. Control fields supply the per-date
    threshold and are never compared observations.
    """
    version: Literal["1.0.0"]
    gate_protocol: Literal["gfp-gate/2.0.0"]
    gfp_channel_id: Id
    percentile: Annotated[float, Field(strict=True, ge=50, lt=100, allow_inf_nan=False)] = 99.0
    control_field_ids: Annotated[list[Id], Field(min_length=1, max_length=100)]
    keep: Literal["positive", "negative"]

    @model_validator(mode="after")
    def distinct_controls(self):
        if len(set(self.control_field_ids)) != len(self.control_field_ids):
            raise ValueError("gfp_gate_duplicate_control_field")
        return self


class ExploratoryGfpGateFilter(StrictModel):
    """Nuclear-object mean gate; thresholds never classify individual image pixels."""
    version: Literal["1.1.0"]
    gate_protocol: Literal["gfp-gate/3.0.0"]
    gfp_channel_id: Id
    method: Literal["manual", "batch_otsu"]
    threshold: FiniteFloat | None = None
    values: Literal["raw", "corrected"] = "raw"
    unit: Literal["nucleus", "cell_roi"] = "nucleus"
    keep: Literal["positive", "negative"]

    @property
    def control_field_ids(self) -> list[str]:
        return []

    @model_validator(mode="after")
    def manual_threshold_only(self):
        if (self.method == "manual") != (self.threshold is not None):
            raise ValueError("gfp_exploratory_threshold_invalid")
        return self

    @model_serializer(mode="wrap")
    def omit_default_unit(self, handler):
        result = handler(self)
        if self.unit == "nucleus":
            result.pop("unit", None)
        return result


GfpFilter = GfpGateFilter | ExploratoryGfpGateFilter
GFP_FILTER: TypeAdapter[GfpFilter] = TypeAdapter(GfpFilter)


def _omit_default(schema: dict[str, Any]) -> None:
    # An absent filter is optional in generated clients and omitted from saved bytes.
    schema.pop("default", None)


class CompartmentMissingRow(StrictModel):
    """One condition × experimental unit of the confirmed unresolved-nucleoli ledger (Q-05):
    nuclei = resolved + missing; excluded is part of resolved; the denominator is all nuclei."""
    condition: str | None
    experimental_unit: str | None
    run: str | None
    fields: Annotated[StrictInt, Field(ge=0)]
    nuclei: Annotated[StrictInt, Field(ge=0)]
    resolved: Annotated[StrictInt, Field(ge=0)]
    missing: Annotated[StrictInt, Field(ge=0)]
    excluded: Annotated[StrictInt, Field(ge=0)]
    reasons: dict[str, Annotated[StrictInt, Field(ge=0)]]


class CompartmentMissingWarning(StrictModel):
    run: str | None
    difference_points: float
    fractions: dict[str, float]


class CompartmentMissingSummary(StrictModel):
    """Unresolved-nucleoli policy 1.0.0: values describe the nuclei whose nucleolus was established."""
    policy: Literal["unresolved-as-missing/1.0.0"]
    warning_points: StrictInt
    rows: list[CompartmentMissingRow]
    warnings: list[CompartmentMissingWarning]


NonNegative = Annotated[StrictInt, Field(ge=0)]


class MaskCorrectionField(StrictModel):
    """Recorded hand edits of one measured field's mask (mask-corrections 1.0.0)."""
    field_id: Id
    status: Literal["recorded", "not_recorded"]
    mask_revision_id: Id
    initial_source: str | None
    initial_revision_id: Id | None
    edit_revision_ids: list[Id]
    operations: dict[Literal["add", "replace", "delete", "merge", "split"], NonNegative]
    initial_regions: NonNegative | None
    added_regions: NonNegative
    redrawn_regions: NonNegative
    deleted_regions: NonNegative
    split_regions: NonNegative
    merged_regions: NonNegative
    final_regions: NonNegative


class MaskCorrectionSummary(StrictModel):
    """Initial regions are reconstructed from the measured mask and the recorded edit operations."""
    version: Literal["1.0.0"]
    region_set_id: Id | None
    source: str | None
    source_revision_ids: list[Id]
    fields: list[MaskCorrectionField]
    edited_fields: NonNegative


class _OptionalGate(StrictModel):
    """Omit an absent gate so ungated requests and results keep their historical bytes."""

    @model_serializer(mode="wrap")
    def omit_absent_gate(self, handler):
        value = handler(self)
        if isinstance(value, dict) and getattr(self, "gfp_gate", None) is None:
            value.pop("gfp_gate", None)
        return value


class DescriptivePlot(PlotSpec):
    kind: Literal["distribution"] = "distribution"


class LegacySelection(StrictModel):
    source: Literal["legacy-cell"]
    metric: LegacyMetric


class RegionSelection(_OptionalGate):
    source: Literal["region"]
    region_set_id: Id
    channel_id: Id | None = None
    metric: RegionMetric
    gfp_gate: GfpFilter | None = Field(default=None, json_schema_extra=_omit_default)

    @model_validator(mode="after")
    def channel_for_intensity_only(self):
        if self.metric.startswith("area_"):
            if self.channel_id is not None:
                raise ValueError("descriptive_area_channel_must_be_unset")
        elif self.channel_id is None:
            raise ValueError("descriptive_intensity_channel_required")
        return self


CompartmentSummaryMetric = Literal["log2_nucleoplasm_over_nucleolus", "nucleolar_area_fraction", "nucleolar_count"]


class CompartmentSummarySelection(_OptionalGate):
    """Per-nucleus values from a nucleoplasm revision's compartment-summary.json.

    Separately versioned observation source (compartment-summary selection 1.0.0);
    the descriptive and inferential protocols that consume it are unchanged.
    The log2 ratio is per channel; area fraction and count are channel-neutral.
    """
    source: Literal["compartment-summary"]
    version: Literal["1.0.0"] = "1.0.0"
    region_set_id: Id
    channel_id: Id | None = None
    metric: CompartmentSummaryMetric
    gfp_gate: GfpFilter | None = Field(default=None, json_schema_extra=_omit_default)

    @model_validator(mode="after")
    def channel_for_intensity_ratio_only(self):
        if self.metric == "log2_nucleoplasm_over_nucleolus":
            if self.channel_id is None:
                raise ValueError("compartment_summary_channel_required")
        elif self.channel_id is not None:
            raise ValueError("compartment_summary_channel_must_be_unset")
        return self


class NumericalSelection(StrictModel):
    source: Literal["numerical"]
    metric: Literal["value"] = "value"


FIELD_SUMMARY_VERSION: Literal["1.0.0"] = "1.0.0"
COMPARTMENT_SUMMARY_SELECTION_V11: Literal["1.1.0"] = "1.1.0"

FieldSummaryMetric = Literal["nucleus_count", "nucleus_density_per_mm2", "positive_count", "positive_fraction"]
NucleolarSummaryMetric = Literal["nucleolar_area_px", "nucleolar_area_um2", "nucleolar_eccentricity"]


class FieldSummarySelection(StrictModel):
    """One observation per field: nucleus counts and positivity among adopted nuclei.

    Positivity reuses the recorded nucleus gates (negative-control gfp-gate/2.0.0
    or exploratory gfp-gate/3.0.0) with keep="positive"; the gate channel is the
    channel that is judged, whatever its stain.
    """
    source: Literal["field-summary"]
    version: Literal["1.0.0"] = FIELD_SUMMARY_VERSION
    region_set_id: Id
    metric: FieldSummaryMetric
    positivity: GfpFilter | None = Field(default=None, json_schema_extra=_omit_default)

    @model_validator(mode="after")
    def positivity_for_positive_metrics(self):
        positive = self.metric.startswith("positive_")
        if positive != (self.positivity is not None):
            raise ValueError("field_summary_positivity_mismatch")
        if self.positivity is not None and self.positivity.keep != "positive":
            raise ValueError("field_summary_positivity_keep_positive_required")
        return self


class CompartmentSummarySelectionV11(_OptionalGate):
    """Compartment-summary selection 1.1.0: 1.0.0 metrics plus nucleolar total area and shape.

    Like 1.0.0, values describe nuclei with at least one adopted nucleolus; a
    candidate-free nucleus is missing (no_nucleolus), never zero.
    """
    source: Literal["compartment-summary"]
    version: Literal["1.1.0"]
    region_set_id: Id
    channel_id: Id | None = Field(default=None, json_schema_extra=_omit_default)
    metric: CompartmentSummaryMetric | NucleolarSummaryMetric
    gfp_gate: GfpFilter | None = Field(default=None, json_schema_extra=_omit_default)

    @model_validator(mode="after")
    def channel_for_intensity_ratio_only(self):
        if self.metric == "log2_nucleoplasm_over_nucleolus":
            if self.channel_id is None:
                raise ValueError("compartment_summary_channel_required")
        elif self.channel_id is not None:
            raise ValueError("compartment_summary_channel_must_be_unset")
        return self


def _selection_tag(value):
    get = value.get if isinstance(value, dict) else lambda key, default=None: getattr(value, key, default)
    source = get("source")
    # Historical compartment 1.0.0 selections may omit their defaulted version.
    return f"compartment-summary/{get('version', '1.0.0')}" if source == "compartment-summary" else source


DescriptiveSelection = Annotated[
    Union[Annotated[LegacySelection, Tag("legacy-cell")],
          Annotated[RegionSelection, Tag("region")],
          Annotated[NumericalSelection, Tag("numerical")],
          Annotated[CompartmentSummarySelection, Tag("compartment-summary/1.0.0")],
          Annotated[CompartmentSummarySelectionV11, Tag("compartment-summary/1.1.0")],
          Annotated[FieldSummarySelection, Tag("field-summary")]],
    Discriminator(_selection_tag)]


class DescriptiveRequest(StrictModel):
    mode: Literal["descriptive"]
    selection: DescriptiveSelection
    group_by: Literal["field"] = "field"
    plot: DescriptivePlot = Field(default_factory=DescriptivePlot)


class DescriptiveFigurePolicy(StrictModel):
    version: Literal["2.0.0"]
    layout: Literal["field-pages"]


class PagedDescriptiveRequest(DescriptiveRequest):
    figure_policy: DescriptiveFigurePolicy

    @model_validator(mode="after")
    def supported_page_width(self):
        if self.plot.preset not in ("nature-single", "nature-double", "custom"):
            raise ValueError("descriptive_page_preset_unsupported")
        return self


DescriptiveRequestType = DescriptiveRequest | PagedDescriptiveRequest


def parse_descriptive_request(value: Any) -> DescriptiveRequestType:
    if isinstance(value, (DescriptiveRequest, PagedDescriptiveRequest)):
        value = value.model_dump(mode="json")
    model = PagedDescriptiveRequest if isinstance(value, dict) and "figure_policy" in value else DescriptiveRequest
    return model.model_validate(value)


class DescriptiveResult(StrictModel):
    analysis_kind: Literal["descriptive"] = "descriptive"
    descriptive_version: Literal["1.0.0"] = "1.0.0"
    spec: DescriptiveRequest
    source_kind: Literal["legacy-image-measurements", "region-2d", "measured-numerical-assay"]
    observation_kind: Literal["nuclei", "regions", "observations", "fields"]
    metric: str
    unit: str
    metric_definition: str
    plot_data: list[dict[str, Any]]
    field_summary: list[dict[str, Any]]
    counts: dict[str, Any]
    selection: dict[str, Any]
    missingness: list[dict[str, Any]]
    source_fields: list[dict[str, Any]]
    excluded_failed_fields: list[dict[str, Any]] = Field(default_factory=list)
    warnings: list[str]
    independence_status: Literal["not_assessed_in_descriptive_analysis"] = "not_assessed_in_descriptive_analysis"
    source_review: Literal["automatic_unreviewed"] | None = None
    # Present only for a revision reviewed under the unresolved-nucleoli policy (absent from older results).
    compartment_missing: CompartmentMissingSummary | None = Field(default=None, json_schema_extra=_omit_default)
    # Present for region results created with the mask-correction ledger (absent from older results).
    mask_corrections: MaskCorrectionSummary | None = Field(default=None, json_schema_extra=_omit_default)

    @model_serializer(mode="wrap")
    def omit_absent_review_marker(self, handler):
        result = handler(self)
        if self.source_review is None:
            result.pop("source_review", None)
        if self.compartment_missing is None:
            result.pop("compartment_missing", None)
        if self.mask_corrections is None:
            result.pop("mask_corrections", None)
        return result


class PagedDescriptiveResult(DescriptiveResult):
    spec: PagedDescriptiveRequest


class OutputModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class DescriptivePagePlan(OutputModel):
    page_index: Annotated[StrictInt, Field(ge=1, le=999)]
    field_ids: list[Id] = Field(min_length=1, max_length=8)
    field_numbers: list[Annotated[StrictInt, Field(ge=1)]] = Field(min_length=1, max_length=8)


class DescriptivePageFiles(OutputModel):
    svg: str
    pdf: str
    png: str


class DescriptivePage(OutputModel):
    page_index: Annotated[StrictInt, Field(ge=1, le=999)]
    files: DescriptivePageFiles


class DescriptiveOutputFile(OutputModel):
    sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    bytes: Annotated[StrictInt, Field(ge=0)]


PresentationErrorCode = Literal[
    "figure_labels_overlap", "figure_text_outside_canvas", "japanese_font_not_installed",
    "sans_serif_font_not_installed", "figure_font_glyphs_unavailable",
]


class DescriptiveRenderError(OutputModel):
    code: PresentationErrorCode
    page_index: Annotated[StrictInt, Field(ge=1, le=999)] | None


def _omit_template_default(schema: dict[str, Any]) -> None:
    schema.pop("default", None)


class PagedDescriptiveOutput(OutputModel):
    descriptive_figure_version: Literal["2.0.0"]
    status: Literal["ready", "tables_only"]
    error: DescriptiveRenderError | None
    field_order: list[Id] = Field(min_length=1)
    page_plan: list[DescriptivePagePlan] = Field(min_length=1)
    pages: list[DescriptivePage]
    y_limits: list[FiniteFloat] = Field(min_length=2, max_length=2)
    y_ticks: list[FiniteFloat]
    style: dict[str, Any]
    font_metadata: dict[str, Any] | None
    source_result_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    source_files: list[str]
    files: dict[str, DescriptiveOutputFile]
    methods_template: StatisticalMethodsTemplate | SkipJsonSchema[None] = Field(
        default=None, json_schema_extra=_omit_template_default)

    @model_validator(mode="before")
    @classmethod
    def explicit_template_not_null(cls, value):
        if isinstance(value, dict) and "methods_template" in value and value["methods_template"] is None:
            raise ValueError("statistical_methods_template_invalid")
        return value

    @model_serializer(mode="wrap")
    def retain_historical_shape(self, handler):
        value = handler(self)
        if self.methods_template is None:
            value.pop("methods_template", None)
        return value

    @model_validator(mode="after")
    def internally_consistent(self):
        count = len(self.page_plan)
        if ([page.page_index for page in self.page_plan] != list(range(1, count + 1))
                or len(self.field_order) != len(set(self.field_order))
                or [fid for page in self.page_plan for fid in page.field_ids] != self.field_order
                or [number for page in self.page_plan for number in page.field_numbers]
                != list(range(1, len(self.field_order) + 1))
                or any(len(page.field_ids) != len(page.field_numbers) for page in self.page_plan)
                or not self.y_limits[0] < self.y_limits[1]
                or len(self.source_files) != len(set(self.source_files))
                or set(self.source_files) != set(self.files)):
            raise ValueError("descriptive_output_manifest_mismatch")
        if self.status == "ready":
            if (self.error is not None or self.font_metadata is None
                    or [page.page_index for page in self.pages] != list(range(1, count + 1))):
                raise ValueError("descriptive_output_manifest_mismatch")
        elif self.error is None or self.pages or self.font_metadata is not None:
            raise ValueError("descriptive_output_manifest_mismatch")
        if self.error is not None and self.error.page_index is not None and self.error.page_index > count:
            raise ValueError("descriptive_output_manifest_mismatch")
        for page in self.pages:
            if page.files.model_dump() != {suffix: f"figure-{page.page_index:03d}.{suffix}"
                                           for suffix in ("svg", "pdf", "png")}:
                raise ValueError("descriptive_output_manifest_mismatch")
        return self
