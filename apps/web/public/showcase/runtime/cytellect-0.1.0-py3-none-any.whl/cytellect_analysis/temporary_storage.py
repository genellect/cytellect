"""Durable ownership and nonblocking recovery of private engine scratch trees."""
from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import stat
import sys
import time
import uuid
from collections.abc import Iterator
from contextvars import ContextVar
from pathlib import Path
from typing import TextIO

SCHEMA = "cytellect-owned-scratch/1"
JOURNAL = re.compile(r"\.cytellect-scratch-([a-f0-9]{32})\.json\Z")
NAME = re.compile(r"[a-z][a-z-]{0,24}-[a-f0-9]{8}\Z")
MAX_DEFERRED_BYTES = 1024 ** 3
CREATION_LOCK_WAIT_SECONDS = 2.0
_scope: ContextVar[tuple[Path, int] | None] = ContextVar("engine_scratch_scope", default=None)
# The scope root as given (not resolved): redirections are refused at and below it, not above it,
# so a profile folder moved with a junction (e.g. C:\\Users) does not stop an owned scratch scope.
_boundary: ContextVar[Path | None] = ContextVar("engine_scratch_boundary", default=None)


class ScratchCapacityExceeded(RuntimeError):
    pass


@contextlib.contextmanager
def scratch_ownership_scope(root: Path, *, max_deferred_bytes: int = MAX_DEFERRED_BYTES) -> Iterator[None]:
    if type(max_deferred_bytes) is not int or max_deferred_bytes <= 0:
        raise ValueError("scratch_capacity_invalid")
    _regular(root, boundary=root)
    token = _scope.set((root.resolve(), max_deferred_bytes))
    boundary = _boundary.set(root)
    try:
        yield
    finally:
        _boundary.reset(boundary)
        _scope.reset(token)


def _regular(path: Path, *, boundary: Path | None = None) -> None:
    """Refuse a symlink or junction at the path or an ancestor, up to the scope root (all ancestors outside a scope)."""
    limit = boundary if boundary is not None else _boundary.get()
    parts = [path, *path.parents]
    if limit is not None and path.is_relative_to(limit):
        parts = [part for part in parts if part.is_relative_to(limit)]
    for part in parts:
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("scratch_path_redirected")


def _acquire(handle: TextIO) -> None:
    handle.seek(0)
    if sys.platform == "win32":
        import msvcrt
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


@contextlib.contextmanager
def _lock(handle: TextIO, *, wait_seconds: float = 0.0) -> Iterator[None]:
    """Recovery never waits (``wait_seconds`` 0). The creator of a journal waits a bounded time:
    recovery may hold the lock of the still-empty journal for the instant it takes to read it."""
    deadline = time.monotonic() + wait_seconds
    while True:
        try:
            _acquire(handle)
            break
        except OSError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.01)
    try:
        yield
    finally:
        handle.seek(0)
        if sys.platform == "win32":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def remove_scratch(path: Path) -> None:
    _regular(path)
    if not path.exists():
        return
    # Validate all members before deleting anything. Do not follow junctions.
    for directory, names, files in os.walk(path, followlinks=False):
        for name in names + files:
            _regular(Path(directory) / name)
    shutil.rmtree(path)


def _target(journal: Path, handle: TextIO) -> Path | None:
    match = JOURNAL.fullmatch(journal.name)
    if match is None or journal.stat().st_size > 1024:
        return None
    saved = json.load(handle)
    name = saved.get("name", "")
    if (saved.get("schema") != SCHEMA or saved.get("id") != match[1]
            or not NAME.fullmatch(name) or not name.endswith("-" + match[1][:8])):
        return None
    return journal.parent / name


def _tree_bytes(target: Path) -> int:
    size = 0
    for parent, names, files in os.walk(target, followlinks=False):
        names[:] = [name for name in names if not (Path(parent) / name).is_symlink()
                    and not (Path(parent) / name).is_junction()]
        for name in files:
            try:
                size += (Path(parent) / name).lstat().st_size
            except OSError:
                pass
    return size


def _recover(directory: Path, *, recursive: bool) -> tuple[dict[str, int], int]:
    """One pass over the journals: remove what an unlocked, valid journal owns, and measure what
    could not be removed. A journal whose lock is held has a live owner and is not a backlog."""
    result = {"recovered": 0, "deferred": 0}
    _regular(directory)
    if not directory.is_dir():
        return result, 0
    journals: list[Path]
    if recursive:
        journals = []
        for parent, names, files in os.walk(directory, followlinks=False):
            names[:] = [name for name in names if not (Path(parent) / name).is_symlink()
                        and not (Path(parent) / name).is_junction()]
            journals.extend(Path(parent) / name for name in files if JOURNAL.fullmatch(name))
    else:
        journals = list(directory.glob(".cytellect-scratch-*.json"))
    remaining: list[Path] = []
    for journal in journals:
        target = None
        try:
            _regular(journal)
            with journal.open("r+", encoding="ascii") as handle, _lock(handle):
                target = _target(journal, handle)
                if target is None:
                    continue
                _regular(target)
                remove_scratch(target)
            journal.unlink(missing_ok=True)
            result["recovered"] += 1
        except FileNotFoundError:
            continue  # An outer owned tree may already have removed its nested journal.
        except (OSError, ValueError, TypeError, AttributeError):
            result["deferred"] += 1
            if target is not None:
                remaining.append(target)  # Owned and unlocked, but its removal failed.
    unique = [path for path in remaining if not any(parent in remaining for parent in path.parents)]
    pending = 0
    for target in unique:
        try:
            _regular(target)
            pending += _tree_bytes(target)
        except (OSError, ValueError):
            continue
    return result, pending


def reap_owned_temporaries(directory: Path, *, recursive: bool = False) -> dict[str, int]:
    """Only an unlocked, valid creation journal permits removal; never wait on locks."""
    return _recover(directory, recursive=recursive)[0]


@contextlib.contextmanager
def claimed_scratch(directory: Path, prefix: str) -> Iterator[Path]:
    if not re.fullmatch(r"[a-z][a-z-]{0,24}-", prefix):
        raise ValueError("scratch_prefix_invalid")
    _regular(directory)
    root, limit = _scope.get() or (directory, MAX_DEFERRED_BYTES)
    if not directory.resolve().is_relative_to(root.resolve()):
        raise ValueError("scratch_scope_invalid")
    directory.mkdir(parents=True, exist_ok=True)
    # Recovery and the backlog measurement share one walk of the scope.
    if _recover(root, recursive=True)[1] >= limit:
        raise ScratchCapacityExceeded("fiji_temporary_cleanup_pending")
    identity = uuid.uuid4().hex
    target = directory / (prefix + identity[:8])
    journal = directory / f".cytellect-scratch-{identity}.json"
    if target.exists():
        raise ValueError("scratch_creation_conflict")
    # Record intent before mkdir. An OS lock proves a live owner even after Java exits. The lock is
    # taken before the intent is written, so recovery never sees a written journal without its owner
    # (an empty or unreadable journal is left for later, never removed). Recovery in another process
    # can hold the lock of the still-empty journal for an instant, so the creator waits a bounded time.
    try:
        with journal.open("x+", encoding="ascii") as handle, _lock(handle, wait_seconds=CREATION_LOCK_WAIT_SECONDS):
            handle.write(json.dumps({"schema": SCHEMA, "id": identity, "name": target.name}))
            handle.flush()
            os.fsync(handle.fileno())
            target.mkdir()
            yield target  # The caller applies its cleanup budget while holding this lock.
    finally:
        if not target.exists():
            try:
                journal.unlink(missing_ok=True)
            except OSError:
                pass  # Recovery can remove an unlocked journal with no remaining tree.
