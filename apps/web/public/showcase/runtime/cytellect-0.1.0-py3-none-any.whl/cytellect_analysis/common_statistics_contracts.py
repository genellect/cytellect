"""New opt-in contracts; historical generic comparison v1 remains unchanged."""
from typing import Annotated, Any, Literal

from pydantic import Field, StrictBool, TypeAdapter, field_validator, model_serializer, model_validator

from .contracts import PlotSpec
from .descriptive_contracts import CompartmentMissingSummary, RegionSelection, _omit_default
from .experiment_strata import StratumRecord
from .group_comparison_contracts import ComparisonEstimates, ComparisonSelection
from .region_comparison_contracts import (
    AcquisitionReview,
    ComparisonDesign,
    Condition,
    RegionComparisonRequest,
    RegionComparisonResult,
)
from .region_features import reads_no_stain
from .regions import RegionModel


class FigurePresentation(RegionModel):
    """Presentation of a publication figure (common-statistics figure 2.0.0). Never changes a value.

    An omitted field is chosen from the saved result (docs/drafts/publication-figures/plan.md §4.3).
    """
    version: Literal["1.0.0"]
    # The observation layer under the runs: every point, a density outline or a box behind the points.
    observations: Literal["points", "violin", "box", "none"] | None = None
    color_by: Literal["run", "group"] | None = None
    # Effect and P value as numbers, P value as asterisks, or no annotation (the legend keeps it).
    annotation: Literal["value", "stars", "none"] = "value"
    size: Literal["panel", "single-column", "double-column", "custom"] = "panel"
    # Representative images beside the quantification (panel a), one field per condition.
    composition: Literal["quantification", "images-quantification"] = "quantification"
    # The researcher's field for a condition; an omitted condition uses the rule (closest to the mean of runs).
    image_fields: dict[Annotated[str, Field(min_length=1, max_length=80)],
                       Annotated[str, Field(min_length=1, max_length=100)]] = Field(default_factory=dict, max_length=30)
    outlines: bool = True


def _omit_none(value):
    return value is None


class CommonComparisonPlot(PlotSpec):
    # Opt-in protocol expands this enum without changing the historical PlotSpec schema.
    # "superplot" and "unit-mean-bar" draw the experiment hierarchy (requirements F-01, F-02).
    kind: Literal["distribution", "paired", "histogram", "box", "violin", "superplot",
                  "unit-mean-bar"] = "distribution"  # type: ignore[assignment]
    histogram_bins: Annotated[int, Field(strict=True, ge=3, le=50)] = 10
    presentation: FigurePresentation | None = Field(default=None, exclude_if=_omit_none)


class RegionComparisonRequestV2(RegionComparisonRequest):
    # Pydantic overrides are intentional version discriminators, not substitutable v1 inputs.
    version: Literal["2.0.0"]  # type: ignore[assignment]
    # Additive, separately versioned observation source; region selections are unchanged.
    selection: ComparisonSelection  # type: ignore[assignment]
    # "none": a descriptive comparison (unit values, per-run differences) without any test,
    # p-value or interval, for designs whose run independence is not confirmed (requirements E-05).
    test: Literal["welch-t", "paired-t", "mann-whitney-u", "wilcoxon", "none"]
    omnibus: Literal["welch-anova", "kruskal-wallis"] | None = None
    plot: CommonComparisonPlot = Field(default_factory=CommonComparisonPlot)  # type: ignore[assignment]
    # Opt-in treatment − control estimates (comparison-estimates/1.0.0) for one declared
    # contrast [treatment, control]. Absent from historical requests and their saved bytes.
    estimates: Literal["comparison-estimates/1.0.0"] | None = Field(default=None, json_schema_extra=_omit_default)

    @model_serializer(mode="wrap")
    def omit_absent_estimates(self, handler):
        value = handler(self)
        if isinstance(value, dict) and self.estimates is None:
            value.pop("estimates", None)
        return value

    @model_validator(mode="after")
    def method_matches_design(self):
        if self.estimates is not None and (len(self.conditions) != 2 or len(self.comparison_family.contrasts) != 1):
            raise ValueError("comparison_estimates_single_contrast_required")
        if self.test == "none":
            if self.omnibus is not None:
                raise ValueError("common_statistics_omnibus_design_mismatch")
            return self
        if (self.test in ("paired-t", "wilcoxon")) != (self.design.kind == "paired"):
            raise ValueError("common_statistics_test_design_mismatch")
        if self.omnibus is not None and (self.design.kind != "independent" or len(self.conditions) < 3):
            raise ValueError("common_statistics_omnibus_design_mismatch")
        if len(self.conditions) >= 3 and self.design.kind == "independent" and self.omnibus is None:
            raise ValueError("common_statistics_omnibus_required")
        if self.omnibus == "welch-anova" and self.test != "welch-t":
            raise ValueError("common_statistics_omnibus_contrast_mismatch")
        if self.omnibus == "kruskal-wallis" and self.test != "mann-whitney-u":
            raise ValueError("common_statistics_omnibus_contrast_mismatch")
        return self


class RegionComparisonResultV2(RegionComparisonResult):
    # Preserve the historical result schema; this explicit discriminator selects v2.
    region_comparison_version: Literal["2.0.0"] = "2.0.0"  # type: ignore[assignment]
    spec: RegionComparisonRequestV2
    omnibus: dict[str, Any] | None
    method_settings: dict[str, Any]
    estimates: ComparisonEstimates | None = Field(default=None, json_schema_extra=_omit_default)
    # Present only for a revision reviewed under the unresolved-nucleoli policy (Q-05).
    compartment_missing: CompartmentMissingSummary | None = Field(default=None, json_schema_extra=_omit_default)
    # Present only for a cohort of one declared stratum (experiment design 1.1.0).
    stratum: StratumRecord | None = Field(default=None, json_schema_extra=_omit_default)

    @model_serializer(mode="wrap")
    def omit_absent_estimates(self, handler):
        value = handler(self)
        if isinstance(value, dict) and self.stratum is None:
            value.pop("stratum", None)
        if isinstance(value, dict) and self.estimates is None:
            value.pop("estimates", None)
        if isinstance(value, dict) and self.compartment_missing is None:
            value.pop("compartment_missing", None)
        return value


class AssociationPlot(PlotSpec):
    kind: Literal["scatter"] = "scatter"
    presentation: FigurePresentation | None = Field(default=None, exclude_if=_omit_none)


class RegionAssociationRequest(RegionModel):
    mode: Literal["region-association"]
    version: Literal["1.0.0", "1.1.0"]
    x_selection: RegionSelection
    y_selection: RegionSelection
    design: ComparisonDesign
    conditions: Annotated[list[Condition], Field(min_length=1, max_length=30)]
    acquisition_review: AcquisitionReview
    missingness_confirmed: Literal[True]
    method: Literal["pearson", "spearman"]
    scope: Literal["per-condition", "pooled"] = "per-condition"
    pooling_confirmed: StrictBool = False
    aggregation: Literal["field-median_sample-mean_unit-mean-v1"] = "field-median_sample-mean_unit-mean-v1"
    missingness_policy: Literal["require-matched-unexcluded-units-v1"] = "require-matched-unexcluded-units-v1"
    plot: AssociationPlot = Field(default_factory=AssociationPlot)

    @field_validator("missingness_confirmed", mode="before")
    @classmethod
    def genuine_confirmation(cls, value):
        if type(value) is not bool or value is not True:
            raise ValueError("explicit_confirmation_required")
        return value

    @model_validator(mode="after")
    def explicit_association(self):
        if self.version == "1.0.0" and (self.x_selection.gfp_gate is not None or self.y_selection.gfp_gate is not None):
            raise ValueError("gfp_gate_unsupported_request")
        if self.x_selection.gfp_gate != self.y_selection.gfp_gate:
            raise ValueError("common_statistics_matched_gfp_selection_required")
        if self.version == "1.0.0" and (self.x_selection.channel_gate is not None or self.y_selection.channel_gate is not None):
            raise ValueError("channel_gate_unsupported_request")
        if self.x_selection.channel_gate != self.y_selection.channel_gate:
            raise ValueError("common_statistics_matched_channel_selection_required")
        if self.version == "1.1.0" and not any(reads_no_stain(s.metric) for s in (self.x_selection, self.y_selection)):
            if self.x_selection.metric.endswith("_corrected") != self.y_selection.metric.endswith("_corrected"):
                raise ValueError("common_statistics_matched_intensity_policy_required")
        if self.missingness_confirmed is not True or self.design.kind != "independent":
            raise ValueError("common_statistics_independent_association_required")
        if self.x_selection == self.y_selection:
            raise ValueError("common_statistics_distinct_metrics_required")
        if self.x_selection.region_set_id != self.y_selection.region_set_id:
            raise ValueError("common_statistics_matched_region_set_required")
        if self.scope == "pooled" and not self.pooling_confirmed:
            raise ValueError("common_statistics_pooling_confirmation_required")
        if len(set(self.conditions)) != len(self.conditions):
            raise ValueError("region_comparison_condition_scope_mismatch")
        if any(not value.strip() or any(ord(char) < 32 for char in value)
               for value in [*self.conditions, self.design.unit_definition, *self.acquisition_review.field_batches.values()]):
            raise ValueError("region_comparison_invalid_text")
        if self.plot.group_order and (set(self.plot.group_order) != set(self.conditions)
                                     or len(self.plot.group_order) != len(self.conditions)):
            raise ValueError("group_order_must_match_groups")
        return self


class RegionAssociationResult(RegionModel):
    analysis_kind: Literal["region-association"] = "region-association"
    source_kind: Literal["region-2d"] = "region-2d"
    region_association_version: Literal["1.0.0", "1.1.0"] = "1.0.0"
    inference_version: str
    revision_id: str
    source_fingerprint: str
    spec: RegionAssociationRequest
    x_source: dict[str, Any]
    y_source: dict[str, Any]
    unit_summary: list[dict[str, Any]]
    unit_ledger: list[dict[str, Any]]
    associations: list[dict[str, Any]]
    counts: list[dict[str, Any]]
    missingness: list[dict[str, Any]]
    warnings: list[str]
    # Present only for a cohort of one declared stratum (experiment design 1.1.0).
    stratum: StratumRecord | None = Field(default=None, json_schema_extra=_omit_default)

    @model_serializer(mode="wrap")
    def omit_absent_stratum(self, handler):
        value = handler(self)
        if isinstance(value, dict) and self.stratum is None:
            value.pop("stratum", None)
        return value


CommonStatisticsRequest = Annotated[RegionComparisonRequestV2 | RegionAssociationRequest, Field(discriminator="mode")]
CommonStatisticsResult = Annotated[RegionComparisonResultV2 | RegionAssociationResult, Field(discriminator="analysis_kind")]


def parse_common_statistics_request(value):
    return TypeAdapter(CommonStatisticsRequest).validate_python(value)
