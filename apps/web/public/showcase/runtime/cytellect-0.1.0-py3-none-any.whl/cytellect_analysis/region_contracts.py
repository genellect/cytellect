"""JSON-native transport contracts for the generic 2D region workflow.

These models intentionally use lists at HTTP/database boundaries. The immutable
scientific models in ``regions`` remain strict, with explicit tuple conversion.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Annotated, Literal

from pydantic import (
    AfterValidator,
    Field,
    FiniteFloat,
    StrictInt,
    TypeAdapter,
    field_validator,
    model_serializer,
    model_validator,
)

from .cellpose_engine import CellposeDetectorSpec
from .compartment_engine import NucleolarDetector, NucleolarDetectorSpec
from .plan_adoption import PlanResolution
from .region_measurement_v2 import (
    RegionMeasurementPolicy,
    RegionMeasurementSpecType,
    RegionMeasurementSpecV2,
    RegionMeasurementSpecV3,
    RegionMeasurementSpecV4,
    RegionMeasurementTableV2,
    RegionMeasurementTableV3,
    RegionMeasurementTableV4,
    validate_area_backgrounds,
)
from .region_policy import (
    MEASUREMENT_POLICY,
    MODE_BY_PROTOCOL,
    AutomaticBackgroundPolicy,
    MeasurementPolicy,
    RawIntensityPolicy,
)
from .regions import (
    BackgroundSpec,
    Calibration2D,
    ChannelSpec,
    ChannelSpecType,
    Id,
    Label,
    RegionMeasurementSpec,
    RegionMeasurementTable,
    RegionModel,
    RegionSetSpec,
)
from .signal_engine import SignalDetectorSpec

Point = Annotated[list[FiniteFloat], Field(min_length=2, max_length=2)]
Digest = Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
OptionalText = Annotated[str, Field(min_length=1, max_length=80)]


def _display_name(value: str) -> str:
    if value != value.strip() or any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError("region_display_name_invalid")
    return value


# The researcher-visible field name, used only as a label. It is never a path,
# an identity or experimental metadata, and nothing is inferred from it.
DisplayName = Annotated[str, Field(min_length=1, max_length=120), AfterValidator(_display_name)]
DISPLAY_NAME: TypeAdapter[str] = TypeAdapter(DisplayName)


class RegionFieldMetadata(RegionModel):
    condition: OptionalText | None = None
    experimental_unit: OptionalText | None = None
    sample: OptionalText | None = None
    acquisition_date: OptionalText | None = None
    pair: OptionalText | None = None
    repeat_length: Annotated[FiniteFloat, Field(ge=0)] | None = None

    @field_validator("condition", "experimental_unit", "sample", "acquisition_date", "pair")
    @classmethod
    def nonblank_metadata(cls, value):
        if value is not None and (not value.strip() or any(ord(char) < 32 for char in value)):
            raise ValueError("region_metadata_invalid")
        return value


class RegionMetadataEdit(RegionModel):
    version: Literal["1.0.0"] = "1.0.0"
    fields: Annotated[dict[Id, RegionFieldMetadata], Field(min_length=1, max_length=100)]


class RegionMetadataChange(RegionMetadataEdit):
    source_revision_id: Id


class RegionFieldInput(RegionModel):
    input_mode: Literal["native", "display-rgb"] = "native"
    version: Literal["1.0.0", "1.1.0"] = "1.0.0"
    client_upload_id: Annotated[str, Field(
        pattern=r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
    )] | None = None
    channels: Annotated[list[ChannelSpecType], Field(min_length=1, max_length=4)]
    metadata: RegionFieldMetadata = Field(default_factory=RegionFieldMetadata)
    calibration: Calibration2D | None = None
    display_name: DisplayName | None = None

    @model_serializer(mode="wrap")
    def omit_absent_display_name(self, handler):
        # Uploads without a name keep their historical specification bytes and fingerprint.
        value = handler(self)
        if isinstance(value, dict) and self.display_name is None:
            value.pop("display_name", None)
        return value

    @model_validator(mode="after")
    def unique_channels(self):
        if self.version == "1.0.0" and any(not isinstance(c, ChannelSpec) for c in self.channels):
            raise ValueError("observed_channels_require_input_version_1_1")
        ids = [channel.channel_id for channel in self.channels]
        if len(ids) != len({cid.casefold() for cid in ids}):
            raise ValueError("duplicate_region_channel_ids")
        return self


class RegionStoredFile(RegionModel):
    sha256: Digest
    bytes: Annotated[int, Field(gt=0)]


class RegionImageInfo(RegionModel):
    input_mode: Literal["native", "display-rgb"] = "native"
    kind: Literal["region-2d"] = "region-2d"
    shape: Annotated[list[Annotated[int, Field(ge=1, le=4096)]], Field(min_length=2, max_length=2)]
    axes: Literal["YX"] = "YX"
    channels: Annotated[list[ChannelSpecType], Field(min_length=1, max_length=4)]
    inputs: dict[Id, RegionStoredFile]
    channel_arrays: dict[Id, RegionStoredFile]
    labels_array: RegionStoredFile | None = None
    calibration: Calibration2D | None = None

    @model_validator(mode="after")
    def stored_channel_mapping(self):
        ids = [channel.channel_id for channel in self.channels]
        if len(ids) != len({cid.casefold() for cid in ids}) or set(ids) != set(self.channel_arrays):
            raise ValueError("region_stored_channel_mapping_invalid")
        slots = {f"ch{index}" for index in range(len(ids))}
        if self.labels_array is not None:
            slots.add("labels")
        if set(self.inputs) != slots and not (set(self.inputs) == {"ome"} and self.labels_array is None and self.input_mode == "native"):
            raise ValueError("region_stored_input_slots_invalid")
        return self


class RegionRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.0.0"] = "1.0.0"
    region_set_id: Id
    label: Label
    source: Literal["manual", "imported"]
    defining_channel_id: Id | None = None

    @field_validator("label")
    @classmethod
    def nonblank_label(cls, value):
        if not value.strip() or any(ord(char) < 32 for char in value):
            raise ValueError("region_label_invalid")
        return value


class NuclearDetectorSpec(RegionModel):
    """Allowlisted, offline nucleus model; never an arbitrary image classifier."""
    engine: Literal["fiji-stardist-2d"] = "fiji-stardist-2d"
    model: Literal["Versatile (fluorescent nuclei)"] = "Versatile (fluorescent nuclei)"
    probability: Annotated[FiniteFloat, Field(gt=0, lt=1)] = 0.5
    nms: Annotated[FiniteFloat, Field(gt=0, lt=1)] = 0.3
    percentile_low: Annotated[FiniteFloat, Field(ge=0, lt=100)] = 1.0
    percentile_high: Annotated[FiniteFloat, Field(gt=0, le=100)] = 99.8

    @model_validator(mode="after")
    def normalization_interval(self):
        if self.percentile_low >= self.percentile_high:
            raise ValueError("nuclear_normalization_interval_invalid")
        return self


class RegionNuclearRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.1.0"] = "1.1.0"
    region_set_id: Id
    label: Label
    source: Literal["stardist_nuclear"] = "stardist_nuclear"
    defining_channel_id: Id
    nuclear_stain_confirmed: Literal[True]
    detector: NuclearDetectorSpec = Field(default_factory=NuclearDetectorSpec)

    @field_validator("nuclear_stain_confirmed", mode="before")
    @classmethod
    def actual_confirmation(cls, value):
        if type(value) is not bool or value is not True:
            raise ValueError("nuclear_stain_confirmation_required")
        return value

    @field_validator("label")
    @classmethod
    def nonblank_label(cls, value):
        if not value.strip() or any(ord(char) < 32 for char in value):
            raise ValueError("region_label_invalid")
        return value


class AdoptedNuclearRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.2.0"] = "1.2.0"
    region_set_id: Id
    label: Label
    source: Literal["stardist_nuclear"] = "stardist_nuclear"
    defining_channel_id: Id
    nuclear_role_source: Literal["recorded_stain", "user_selected_role"]
    detector: NuclearDetectorSpec = Field(default_factory=NuclearDetectorSpec)


class ScaledNuclearRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.5.0"] = "1.5.0"
    region_set_id: Id
    label: Label
    source: Literal["stardist_nuclear"] = "stardist_nuclear"
    defining_channel_id: Id
    nuclear_role_source: Literal["recorded_stain", "user_selected_role"]
    detection_max_side_px: Annotated[StrictInt, Field(ge=64, le=2048)]
    detector: NuclearDetectorSpec = Field(default_factory=NuclearDetectorSpec)


class AutoScaledNuclearRecipe(RegionModel):
    """Nuclei with a detection copy sized from the estimated nucleus diameter (nuclear-size/1.0.0)."""
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.7.0"] = "1.7.0"
    region_set_id: Id
    label: Label
    source: Literal["stardist_nuclear"] = "stardist_nuclear"
    defining_channel_id: Id
    nuclear_role_source: Literal["recorded_stain", "user_selected_role"]
    detection_scale: Literal["nuclear-size/1.0.0"] = "nuclear-size/1.0.0"
    detector: NuclearDetectorSpec = Field(default_factory=NuclearDetectorSpec)


class RegionSignalRecipe(RegionModel):
    """Exploratory signal-positive areas; never implicitly nuclei or nucleoli."""
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.3.0"] = "1.3.0"
    region_set_id: Id
    label: Label
    source: Literal["fiji_positive_regions"] = "fiji_positive_regions"
    defining_channel_id: Id
    detector: SignalDetectorSpec = Field(default_factory=lambda: SignalDetectorSpec(threshold_method="otsu"))

    @field_validator("label")
    @classmethod
    def nonblank_label(cls, value):
        if not value.strip() or any(ord(char) < 32 for char in value):
            raise ValueError("region_label_invalid")
        return value


class RegionCompartmentRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.4.0"] = "1.4.0"
    region_set_id: Id
    label: Label
    source: Literal["fiji_nuclear_compartment"] = "fiji_nuclear_compartment"
    compartment: Literal["nucleoli", "nucleoplasm"]
    nuclear_revision_id: Id
    nuclear_channel_id: Id
    defining_channel_id: Id
    detector: NucleolarDetector = Field(default_factory=NucleolarDetectorSpec)
    # Nucleoplasm from the adopted (possibly edited) nucleoli revision instead of
    # re-running the detector. Absent in historical revisions, which keep their meaning.
    nucleolar_revision_id: Id | None = None

    @field_validator("detector", mode="before")
    @classmethod
    def historical_detector_default(cls, value):
        if isinstance(value, dict) and "protocol_version" not in value:
            return {"protocol_version": "1.0.0", **value}
        return value

    @model_validator(mode="after")
    def distinct_channels(self):
        dapi_poor = getattr(self.detector, "source", None) == "dapi_poor"
        # DNA-poor nucleoli are defined by the nuclear stain itself; other sources need another channel.
        if dapi_poor != (self.nuclear_channel_id == self.defining_channel_id):
            raise ValueError("compartment_requires_distinct_channels" if not dapi_poor
                             else "dapi_poor_nucleoli_use_the_nuclear_channel")
        if self.nucleolar_revision_id is not None and self.compartment != "nucleoplasm":
            raise ValueError("nucleolar_revision_only_for_nucleoplasm")
        if not self.label.strip() or any(ord(c) < 32 for c in self.label):
            raise ValueError("region_label_invalid")
        return self


class RegionCellposeRecipe(RegionModel):
    id: Literal["region-2d"] = "region-2d"
    version: Literal["1.8.0"] = "1.8.0"
    region_set_id: Literal["cell"] = "cell"
    label: Label = "細胞"
    source: Literal["cellpose_cell"] = "cellpose_cell"
    defining_channel_id: Id
    detector: CellposeDetectorSpec = Field(default_factory=CellposeDetectorSpec)
    nuclear_revision_id: Id | None = None
    nuclear_channel_id: Id | None = None

    @model_validator(mode="after")
    def nuclear_binding(self):
        if (self.nuclear_revision_id is None) != (self.nuclear_channel_id is None):
            raise ValueError("cellpose_nuclear_binding_incomplete")
        return self


RegionRecipeType = Annotated[RegionRecipe | RegionNuclearRecipe | AdoptedNuclearRecipe | ScaledNuclearRecipe | AutoScaledNuclearRecipe | RegionSignalRecipe | RegionCompartmentRecipe | RegionCellposeRecipe, Field(discriminator="version")]


RECORDED_NUCLEAR_STAINS = frozenset({"dapi", "hoechst", "hoechst33258", "hoechst33342", "draq", "draq5", "draq7"})


def validate_nuclear_role_evidence(recipe: RegionRecipeType, image_info: RegionImageInfo) -> None:
    """Bind recorded evidence to the acquired channel; never infer it from labels.

    A user-selected role remains an explicit choice, distinct from recorded stain
    evidence. This guard is shared by admission, worker and saved-mask replay.
    """
    if not isinstance(recipe, (AdoptedNuclearRecipe, ScaledNuclearRecipe, AutoScaledNuclearRecipe)):
        return
    channel = next((item for item in image_info.channels if item.channel_id == recipe.defining_channel_id), None)
    if channel is None:
        raise ValueError("unknown_defining_channel")
    if recipe.nuclear_role_source == "recorded_stain":
        normalized = "".join(character for character in (channel.stain or "").casefold() if character.isalnum())
        if normalized not in RECORDED_NUCLEAR_STAINS:
            raise ValueError("nuclear_recorded_stain_required")


class RegionBackground(RegionModel):
    polygon: Annotated[list[Point], Field(min_length=3, max_length=1000)]
    confirmed: Literal[True]


class RegionExclusion(RegionModel):
    field_id: Id
    region_id: Annotated[int, Field(ge=1, le=4294967295)] | None = None
    reason: Annotated[str, Field(min_length=1, max_length=200)]

    @field_validator("reason")
    @classmethod
    def nonblank_reason(cls, value):
        if not value.strip() or any(ord(char) < 32 for char in value):
            raise ValueError("region_exclusion_reason_invalid")
        return value


class RegionAnalysisRequest(RegionModel):
    field_ids: Annotated[list[Id], Field(min_length=1, max_length=100)] | None = None
    reuse_revision: Id | None = None
    plan_resolution: PlanResolution | None = None
    measurement: MeasurementPolicy | None = None
    recipe: RegionRecipeType
    backgrounds: dict[Id, dict[Id, RegionBackground]] = Field(default_factory=dict)
    confirmed_channel_ids: Annotated[list[Id], Field(max_length=6)] = Field(default_factory=list)
    exclusions: Annotated[list[RegionExclusion], Field(max_length=10000)] = Field(default_factory=list)

    @field_validator("recipe", mode="before")
    @classmethod
    def historical_recipe_default(cls, value):
        # Original HTTP callers could omit the v1.0 version. Its persisted JSON
        # stays identical; automatic recipes must explicitly select v1.1.
        if isinstance(value, dict) and "version" not in value:
            return {**value, "version": "1.0.0"}
        return value

    @model_validator(mode="after")
    def unique_field_and_exclusion_ids(self):
        if len(set(self.confirmed_channel_ids)) != len(self.confirmed_channel_ids):
            raise ValueError("duplicate_confirmed_channel")
        if self.confirmed_channel_ids and self.measurement is not None:
            raise ValueError("confirmed_channels_require_roi_measurement")
        validate_area_backgrounds(self.measurement, self.backgrounds)
        if self.field_ids is not None and len(self.field_ids) != len(set(self.field_ids)):
            raise ValueError("duplicate_region_fields")
        exclusions = [(item.field_id, item.region_id) for item in self.exclusions]
        if len(exclusions) != len(set(exclusions)):
            raise ValueError("duplicate_region_exclusions")
        return self


def region_request_config(request: RegionAnalysisRequest) -> dict:
    """Preserve historical config bytes: only the new absent policy is omitted."""
    value = request.model_dump(mode="json")
    if request.measurement is None:
        value.pop("measurement")
    if not request.confirmed_channel_ids:
        value.pop("confirmed_channel_ids")
    return value


class RegionMaskEdit(RegionModel):
    field_id: Id
    region_set_id: Id
    operation: Literal["add", "replace", "delete", "merge", "split"]
    ids: Annotated[list[Annotated[int, Field(ge=1, le=4294967295)]], Field(max_length=1000)] = Field(default_factory=list)
    polygon: Annotated[list[Point], Field(max_length=10000)] = Field(default_factory=list)
    expected_mask_revision_id: Id | None = None

    @model_validator(mode="after")
    def explicit_edit_target(self):
        if len(self.ids) != len(set(self.ids)):
            raise ValueError("duplicate_region_edit_ids")
        if self.operation == "add" and self.ids:
            raise ValueError("add_does_not_take_region_ids")
        if self.operation in ("replace", "split") and len(self.ids) != 1:
            raise ValueError("region_edit_requires_one_id")
        if self.operation == "merge" and len(self.ids) < 2:
            raise ValueError("region_merge_requires_multiple_ids")
        if self.operation == "delete" and not self.ids:
            raise ValueError("region_delete_requires_ids")
        if self.operation in ("add", "replace", "split") and len(self.polygon) < 3:
            raise ValueError("region_edit_requires_polygon")
        if self.operation in ("delete", "merge") and self.polygon:
            raise ValueError("region_edit_unused_polygon")
        return self


def scientific_specification(*, field_id: str, revision_id: str, mask_revision_id: str,
                             recipe: RegionRecipeType, image_info: RegionImageInfo,
                             measurement: MeasurementPolicy | None = None) -> RegionMeasurementSpecType:
    """Explicit JSON-list → immutable science-tuple boundary, shared with replay."""
    validate_nuclear_role_evidence(recipe, image_info)
    region_set = RegionSetSpec(
        region_set_id=recipe.region_set_id, label=recipe.label,
        mask_revision_id=mask_revision_id, source=recipe.source,
        defining_channel_id=recipe.defining_channel_id,
    )
    if measurement is not None:
        specification_type = {"area_only": RegionMeasurementSpecV2, "raw_intensity": RegionMeasurementSpecV3,
                              "automatic_background": RegionMeasurementSpecV4}[measurement.mode]
        return specification_type(
            measurement=measurement, field_id=field_id, analysis_revision_id=revision_id,  # type: ignore[arg-type]
            region_set=region_set, channels=tuple(image_info.channels), calibration=image_info.calibration,
        )
    if any(not isinstance(c, ChannelSpec) for c in image_info.channels):
        raise ValueError("confirmed_channels_required_for_corrected_protocol")
    return RegionMeasurementSpec(
        field_id=field_id, analysis_revision_id=revision_id,
        region_set=region_set,
        channels=tuple(c for c in image_info.channels if isinstance(c, ChannelSpec)), calibration=image_info.calibration,
        backgrounds=tuple(BackgroundSpec(channel_id=channel.channel_id, roi_revision_id=revision_id, confirmed=True)
                          for channel in image_info.channels),
    )


class RegionFieldMask(RegionModel):
    mask_revision_id: Id
    mask_sha256: Digest
    region_set_id: Id
    source: Literal["manual", "imported", "stardist_nuclear", "fiji_positive_regions", "fiji_nuclear_compartment", "cellpose_cell"]
    shape: Annotated[list[Annotated[int, Field(ge=1, le=4096)]], Field(min_length=2, max_length=2)]
    file: RegionStoredFile


class RegionFieldFailure(RegionModel):
    field_id: Id
    reason: Annotated[str, Field(pattern=r"^[a-z0-9_]+$")]


class RegionExcludedFailure(RegionModel):
    field_id: Id
    reason: Annotated[str, Field(min_length=1, max_length=200)]
    error: Annotated[str, Field(pattern=r"^[a-z0-9_]+$")]


class RegionReport(RegionModel):
    """Validate persisted JSON with model_validate_json, preserving strict tuples.

    FastAPI should return that validated instance, rather than asking its Python
    response validator to reinterpret tuple-valued science fields from JSON lists.
    """
    analysis_kind: Literal["region-2d"] = "region-2d"
    protocol_version: Literal["1.0.0"] = "1.0.0"
    revision_id: Id
    recipe: RegionRecipeType
    field_tables: dict[Id, RegionMeasurementTable]
    field_masks: dict[Id, RegionFieldMask]
    field_outcomes: dict[Id, Literal["measured", "no_regions", "failed", "excluded_failed"]]
    field_failures: list[RegionFieldFailure]
    excluded_failed_fields: list[RegionExcludedFailure]
    exclusions: list[RegionExclusion]

    @model_validator(mode="after")
    def complete_outcomes(self):
        _validate_report_outcomes(self)
        return self


class RegionReportV2(RegionModel):
    """Explicit area-only report; v1 persisted data retains its original model."""
    analysis_kind: Literal["region-2d"] = "region-2d"
    protocol_version: Literal["2.0.0"] = "2.0.0"
    measurement: RegionMeasurementPolicy
    revision_id: Id
    recipe: RegionRecipeType
    field_tables: dict[Id, RegionMeasurementTableV2]
    field_masks: dict[Id, RegionFieldMask]
    field_outcomes: dict[Id, Literal["measured", "no_regions", "failed", "excluded_failed"]]
    field_failures: list[RegionFieldFailure]
    excluded_failed_fields: list[RegionExcludedFailure]
    exclusions: list[RegionExclusion]

    @model_validator(mode="after")
    def complete_outcomes(self):
        _validate_report_outcomes(self)
        if self.measurement.mode != MODE_BY_PROTOCOL[self.protocol_version]:
            raise ValueError("region_measurement_protocol_mismatch")
        if any(table.measurement != self.measurement for table in self.field_tables.values()):
            raise ValueError("region_measurement_protocol_mismatch")
        return self


class RegionReportV3(RegionReportV2):
    measurement: RawIntensityPolicy  # type: ignore[assignment]
    protocol_version: Literal["3.0.0"] = "3.0.0"  # type: ignore[assignment]
    field_tables: dict[Id, RegionMeasurementTableV3]  # type: ignore[assignment]


class RegionReportV4(RegionReportV2):
    """Raw values plus corrections from automatic, unconfirmed background candidates."""
    measurement: AutomaticBackgroundPolicy  # type: ignore[assignment]
    protocol_version: Literal["4.0.0"] = "4.0.0"  # type: ignore[assignment]
    field_tables: dict[Id, RegionMeasurementTableV4]  # type: ignore[assignment]


_ReportUnion = RegionReport | RegionReportV2 | RegionReportV3 | RegionReportV4
RegionReportType = Annotated[_ReportUnion, Field(discriminator="protocol_version")]
_REPORT: TypeAdapter[_ReportUnion] = TypeAdapter(RegionReportType)


def region_report_from_json(value: str) -> RegionReportType:
    return _REPORT.validate_json(value, strict=True)


def validate_region_report_policy(report: RegionReportType, config: Mapping) -> None:
    """Bind a strictly parsed report to its saved measurement policy."""
    raw_policy = config.get("measurement")
    try:
        policy = None if raw_policy is None else MEASUREMENT_POLICY.validate_python(raw_policy, strict=True)
    except ValueError as exc:
        raise ValueError("region_measurement_protocol_mismatch") from exc
    if isinstance(report, RegionReportV2):
        if policy != report.measurement:
            raise ValueError("region_measurement_protocol_mismatch")
    elif policy is not None:
        raise ValueError("region_measurement_protocol_mismatch")


def _validate_report_outcomes(report: RegionReport | RegionReportV2) -> None:
    failed = [item.field_id for item in report.field_failures]
    excluded = [item.field_id for item in report.excluded_failed_fields]
    if len(failed) != len(set(failed)) or len(excluded) != len(set(excluded)):
        raise ValueError("region_report_duplicate_failure")
    expected: dict[str, str] = {fid: table.status for fid, table in report.field_tables.items()}
    if set(expected) & (set(failed) | set(excluded)) or set(failed) & set(excluded):
        raise ValueError("region_report_conflicting_outcome")
    expected.update(dict.fromkeys(failed, "failed"))
    expected.update(dict.fromkeys(excluded, "excluded_failed"))
    if (expected != report.field_outcomes or not expected
            or not set(report.field_masks).issubset(expected)
            or any(item.field_id not in expected for item in report.exclusions)):
        raise ValueError("region_report_field_coverage_invalid")
    if any(mask.region_set_id != report.recipe.region_set_id or mask.source != report.recipe.source
           for mask in report.field_masks.values()):
        raise ValueError("region_report_mask_definition_mismatch")
    for fid, table in report.field_tables.items():
        mask = report.field_masks.get(fid)
        if (mask is None or table.field_id != fid or table.analysis_revision_id != report.revision_id
                or table.region_set.region_set_id != report.recipe.region_set_id
                or table.region_set.label != report.recipe.label
                or table.region_set.source != report.recipe.source
                or table.region_set.defining_channel_id != report.recipe.defining_channel_id
                or table.region_set.mask_revision_id != mask.mask_revision_id
                or table.mask_sha256 != mask.mask_sha256 or list(table.shape_yx) != mask.shape):
            raise ValueError("region_report_table_mask_mismatch")
