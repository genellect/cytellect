"""Additive, owned generic-region endpoints sharing the existing job lifecycle."""

import hashlib
import io
import json
import shutil
from typing import Annotated, Literal

import numpy as np
import tifffile
from cytellect_analysis.display_contracts import (
    PREVIEW_DISPLAY_HEADER,
    REGION_PREVIEW_PNG_RESPONSE,
    OriginalRgbPreviewMetadata,
    RegionPreviewDisplayMetadata,
)
from cytellect_analysis.gfp_gate import (
    apply_control_gate,
    apply_exploratory_gate,
    control_thresholds,
    exploratory_thresholds,
)
from cytellect_analysis.images import read_tiff, render_preview_with_display, sha256
from cytellect_analysis.masks import contours
from cytellect_analysis.region_contracts import (
    RegionAnalysisRequest,
    RegionFieldInput,
    RegionFieldMetadata,
    RegionImageInfo,
    RegionMaskEdit,
    RegionMetadataEdit,
    RegionReportType,
    region_report_from_json,
    region_request_config,
    validate_region_report_policy,
)
from cytellect_analysis.region_metadata import region_metadata_child_config
from fastapi import Depends, File, Form, HTTPException, Response, UploadFile
from PIL import Image
from pydantic import BaseModel, Field, FiniteFloat, ValidationError, model_validator
from sqlalchemy import func, select, update

from .db import fields, uid, workspaces
from .openapi import register_contract_schemas
from .planning import bind_revision_plan, inherit_plan_resolution
from .public_uploads import require_registered
from .region_enqueue import enqueue_region, validate_region_request
from .region_inputs import read_label_tiff
from .region_ome import register_region_ome_routes
from .storage import read_json


class RegionFieldView(BaseModel):
    id: str
    workspace_id: str
    metadata: RegionFieldMetadata
    image_info: RegionImageInfo
    synthetic: bool
    display_name: str | None = None


def is_region(value):
    return value.get("config", value.get("image_info", {})).get("analysis_kind",
           value.get("image_info", {}).get("kind")) == "region-2d"


def require_compartment_revision(rev):
    """A compartment-summary selection needs nucleoplasm derived from adopted nucleoli."""
    from cytellect_analysis.compartment_observations import require_compartment_source

    try:
        require_compartment_source(rev["config"].get("recipe"))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None


def require_gfp_gate_source(rev, selection):
    """A GFP nucleus filter needs adopted nuclear identity, known controls and the GFP channel.

    The worker repeats the full binding against the saved nuclear rows; these are
    the immediate request-level refusals.
    """
    gate = getattr(selection, "gfp_gate", None)
    if gate is None:
        return
    from cytellect_analysis.gfp_selection import binding_kind

    try:
        binding_kind(rev["config"].get("recipe"))
        recipe = rev["config"].get("recipe", {})
        if (recipe.get("source") == "manual" and recipe.get("region_set_id") == "cell") != (getattr(gate, "unit", "nucleus") == "cell_roi"):
            raise ValueError("gfp_gate_nuclear_source_invalid")
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    snapshot = rev["config"].get("field_snapshot", {})
    if set(gate.control_field_ids) - set(snapshot):
        raise HTTPException(422, "gfp_gate_unknown_control_field")
    if any(all(channel.get("channel_id") != gate.gfp_channel_id for channel in field["image_info"].get("channels", []))
           for field in snapshot.values()):
        raise HTTPException(422, "gfp_gate_channel_unknown")


class GfpGateField(BaseModel):
    field_id: Annotated[str, Field(min_length=1, max_length=100)]
    revision_id: Annotated[str, Field(min_length=1, max_length=100)]
    control: bool = False


class GfpGateRequest(BaseModel):
    gfp_channel_id: Annotated[str, Field(min_length=1, max_length=100)]
    percentile: Annotated[float, Field(ge=50, lt=100)] = 99.0
    fields: Annotated[list[GfpGateField], Field(min_length=1, max_length=100)]
    method: Literal["negative_control", "manual", "batch_otsu"] = "negative_control"
    threshold: FiniteFloat | None = None
    values: Literal["raw", "corrected"] = "raw"
    unit: Literal["nucleus", "cell_roi"] = "nucleus"

    @model_validator(mode="after")
    def valid_gate(self):
        if self.unit == "cell_roi" and self.method == "negative_control":
            raise ValueError("cell_roi_requires_exploratory_gate")
        if len({item.field_id for item in self.fields}) != len(self.fields):
            raise ValueError("gfp_gate_duplicate_field")
        if (self.method == "manual") != (self.threshold is not None):
            raise ValueError("gfp_exploratory_threshold_invalid")
        if self.method == "negative_control" and self.values != "raw":
            raise ValueError("gfp_control_gate_requires_raw_values")
        if self.method != "negative_control" and any(item.control for item in self.fields):
            raise ValueError("gfp_exploratory_gate_has_no_control_fields")
        return self


def register_region_routes(api, store, settings, owner, workspace, revision,
                           field_record, result_root, queue, touch, child_revision):
    Owner = Annotated[str, Depends(owner)]
    register_contract_schemas(api, RegionPreviewDisplayMetadata)
    register_region_ome_routes(api, store, settings, owner, workspace, touch, RegionFieldView, is_region)

    def region_revision(rid, who):
        rev = revision(rid, who)
        if not is_region(rev):
            raise HTTPException(409, "region_analysis_required")
        return rev

    def validate_request(body, selected, reused_masks=()):
        return validate_region_request(store, body, selected, reused_masks)

    @api.get("/v1/workspaces/{wid}/region-fields", response_model=list[RegionFieldView])
    def list_region_fields(wid: str, who: Owner):
        workspace(wid, who)
        return [dict(f) for f in store.rows(fields, workspace_id=wid) if is_region(f)]

    @api.post("/v1/workspaces/{wid}/region-fields", status_code=201, response_model=RegionFieldView)
    async def upload_region_field(wid: str, who: Owner, specification: str = Form(...),
                                  ch0: UploadFile = File(...), ch1: UploadFile | None = File(None),
                                  ch2: UploadFile | None = File(None), ch3: UploadFile | None = File(None),
                                  labels: UploadFile | None = File(None)):
        workspace(wid, who)
        try:
            spec = RegionFieldInput.model_validate_json(specification)
        except ValidationError:
            raise HTTPException(422, "invalid_region_field_specification") from None
        channel_files = [ch0, ch1, ch2, ch3]
        if any((file is not None) != (i < len(spec.channels)) for i, file in enumerate(channel_files)):
            raise HTTPException(422, "region_channel_file_count_mismatch")
        fid = uid()
        folder = store.safe_path("workspaces", wid, "fields", fid)
        folder.mkdir(parents=True)
        uploads = {f"ch{i}": f for i, f in enumerate(channel_files) if f is not None}
        if labels is not None:
            uploads["labels"] = labels
        total = 0
        keep_folder = False
        fingerprint = None

        def existing_upload(conn):
            if spec.client_upload_id is None:
                return None
            existing = conn.execute(select(fields).where(
                fields.c.workspace_id == wid,
                fields.c.client_upload_id == spec.client_upload_id,
            )).mappings().first()
            if existing is not None:
                if existing["upload_fingerprint"] != fingerprint:
                    raise HTTPException(409, "region_upload_id_conflict")
                return dict(existing)
            # Identical bytes under a new client key are a separate field: two
            # fields may genuinely share content. The browser shows a duplicate
            # warning; the researcher decides whether to exclude one.
            # Selecting a detector role can change only the evidence-source tag.
            # It must not duplicate unchanged images or rewrite saved provenance.
            requested_channels = [{key: value for key, value in channel.model_dump(mode="json").items()
                                   if key != "identity_source"} for channel in spec.channels]
            for candidate in conn.execute(select(fields).where(fields.c.workspace_id == wid).order_by(fields.c.id)).mappings():
                info = candidate["image_info"]
                if (not is_region(candidate) or info.get("inputs") != inputs
                        or candidate["display_name"] != spec.display_name
                        or info.get("input_mode", "native") != spec.input_mode
                        or info.get("calibration") != (spec.calibration.model_dump(mode="json") if spec.calibration else None)
                        or candidate["metadata"] != spec.metadata.model_dump(mode="json")):
                    continue
                channels = [{key: value for key, value in channel.items() if key != "identity_source"}
                             for channel in info["channels"]]
                sources = [channel.get("identity_source") for channel in info["channels"]]
                requested_sources = [getattr(channel, "identity_source", None) for channel in spec.channels]
                # Only a changed role-evidence tag identifies a resend of the same field.
                if channels == requested_channels and sources != requested_sources:
                    return dict(candidate)
            return None

        try:
            inputs = {}
            for slot, file in uploads.items():
                path = folder / f"{slot}.tif"
                with path.open("wb") as stream:
                    while chunk := await file.read(1024 * 1024):
                        total += len(chunk)
                        if total > 256 * 1024**2:
                            raise HTTPException(413, "field_upload_limit")
                        stream.write(chunk)
                inputs[slot] = {"sha256": sha256(path), "bytes": path.stat().st_size}
            require_registered(settings.upload_allowlist, *(value["sha256"] for value in inputs.values()))
            if spec.client_upload_id is not None:
                canonical = json.dumps({
                    "specification": spec.model_dump(mode="json", exclude={"client_upload_id"}),
                    "inputs": inputs,
                }, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
                fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                # A known key is resolved before decoding and quota checks. A
                # changed/corrupt resend must not replace the accepted input.
                with store.transaction() as conn:
                    touch(conn, wid)
                    existing = existing_upload(conn)
                    if existing is not None:
                        return existing
            shape = None
            arrays = {}
            for i, channel in enumerate(spec.channels):
                pixels = read_tiff(folder / f"ch{i}.tif", legacy=spec.input_mode == "display-rgb")
                if shape is not None and pixels.shape != shape:
                    raise ValueError("channel_dimensions_mismatch")
                shape = pixels.shape
                path = folder / f"channel-{channel.channel_id}.npy"
                np.save(path, pixels, allow_pickle=False)
                arrays[channel.channel_id] = {"sha256": sha256(path), "bytes": path.stat().st_size}
            label_info = None
            if labels is not None:
                plane = read_label_tiff(folder / "labels.tif", shape)
                path = folder / "labels.npy"
                np.save(path, plane, allow_pickle=False)
                label_info = {"sha256": sha256(path), "bytes": path.stat().st_size}
            if shape is None:
                raise ValueError("region_channels_required")
            info = RegionImageInfo.model_validate({"shape": list(shape), "channels": spec.channels,
                                   "inputs": inputs, "channel_arrays": arrays, "labels_array": label_info,
                                   "calibration": spec.calibration, "input_mode": spec.input_mode})
            with store.transaction() as conn:
                touch(conn, wid)
                # Decode outside the write lock, then recheck within the same
                # transaction as quota accounting and insert for racing sends.
                existing = existing_upload(conn)
                if existing is not None:
                    return existing
                w = conn.execute(select(workspaces).where(workspaces.c.id == wid)).mappings().one()
                count = conn.execute(select(func.count()).select_from(fields).where(fields.c.workspace_id == wid)).scalar_one()
                if count >= settings.max_fields or w["bytes"] + total > settings.max_upload_bytes:
                    raise HTTPException(413, "workspace_limit")
                existing_rows = conn.execute(select(fields).where(fields.c.workspace_id == wid)).mappings().all()
                for existing in existing_rows:
                    if not is_region(existing):
                        raise HTTPException(409, "workflow_kind_mismatch")
                # Channel IDs are local acquisition slots. Newly imported fields retain
                # their own metadata and receive no existing role assignment implicitly.
                conn.execute(fields.insert().values(id=fid, workspace_id=wid,
                             metadata=spec.metadata.model_dump(mode="json"),
                             image_info=info.model_dump(mode="json"), synthetic=False,
                             client_upload_id=spec.client_upload_id, upload_fingerprint=fingerprint,
                             display_name=spec.display_name))
                conn.execute(update(workspaces).where(workspaces.c.id == wid).values(bytes=w["bytes"] + total))
                result = dict(conn.execute(select(fields).where(fields.c.id == fid)).mappings().one())
            keep_folder = True
            return result
        except HTTPException:
            raise
        except Exception:
            raise HTTPException(422, "unsupported_or_invalid_region_image") from None
        finally:
            if not keep_folder:
                shutil.rmtree(folder)
            for file in uploads.values():
                await file.close()

    @api.get("/v1/region-fields/{fid}/preview", response_class=Response, responses=REGION_PREVIEW_PNG_RESPONSE)
    def preview(fid: str, channel_id: str, who: Owner, low: float = 0, high: float = 100, gain: float = 1):
        f = field_record(fid, who)
        if not is_region(f):
            raise HTTPException(404, "field_not_found")
        info = RegionImageInfo.model_validate(f["image_info"])
        if (channel_id not in info.channel_arrays or not 0 <= low < high <= 100 or not 0.1 <= gain <= 10):
            raise HTTPException(422, "invalid_display_settings")
        if info.input_mode == "display-rgb":
            slot = next(i for i, channel in enumerate(info.channels) if channel.channel_id == channel_id)
            original = store.safe_path("workspaces", f["workspace_id"], "fields", fid, f"ch{slot}.tif")
            recorded = info.inputs[f"ch{slot}"]
            if (not original.is_file() or original.stat().st_size != recorded.bytes
                    or sha256(original) != recorded.sha256):
                raise HTTPException(409, "region_original_image_mismatch")
            with tifffile.TiffFile(original, _multifile=False) as tif:
                series = tif.series[0]
                if series.axes in ("YXS", "SYX"):
                    if (len(tif.series) != 1 or series.dtype != np.uint8 or len(series.shape) != 3
                            or series.shape[series.axes.index("S")] not in (3, 4)):
                        raise HTTPException(422, "unsupported_original_rgb_preview")
                    shape = tuple(series.shape[series.axes.index(axis)] for axis in "YX")
                    if shape != tuple(info.shape):
                        raise HTTPException(409, "region_original_image_mismatch")
                    if (low, high, gain) != (0, 100, 1):
                        raise HTTPException(422, "original_rgb_preview_has_no_contrast_adjustment")
                    if series.shape[series.axes.index("S")] == 4 and tuple(getattr(tif.pages[0], "extrasamples", ())) != (2,):
                        # Premultiplied/unspecified alpha cannot be represented as
                        # unchanged straight-alpha PNG samples without guessing.
                        raise HTTPException(422, "unsupported_original_rgb_alpha")
                    rgb = np.moveaxis(series.asarray(), series.axes.index("S"), -1)
                    output = io.BytesIO()
                    Image.fromarray(rgb).save(output, format="PNG")
                    original_display = OriginalRgbPreviewMetadata(
                        field_id=fid, requested_channel=channel_id,
                        source_axes="YXS" if series.axes == "YXS" else "SYX", source_shape=series.shape,
                        rendered_shape=rgb.shape, color_mode="RGBA" if rgb.shape[2] == 4 else "RGB",
                        alpha_preserved=rgb.shape[2] == 4, source_file_sha256=recorded.sha256,
                    )
                    return Response(output.getvalue(), media_type="image/png", headers={
                        PREVIEW_DISPLAY_HEADER: original_display.model_dump_json(),
                    })
        path = store.safe_path("workspaces", f["workspace_id"], "fields", fid, f"channel-{channel_id}.npy")
        pixels = np.load(path, allow_pickle=False)
        png, display = render_preview_with_display(
            {channel_id: pixels}, channel_id, low, high, gain, field_id=fid, composite=False,
        )
        return Response(png, media_type="image/png", headers={
            PREVIEW_DISPLAY_HEADER: json.dumps(display.model_dump(), ensure_ascii=True, separators=(",", ":")),
        })

    @api.post("/v1/workspaces/{wid}/region-analyses", status_code=202)
    def start(wid: str, body: RegionAnalysisRequest, who: Owner):
        workspace(wid, who)
        return enqueue_region(store, settings, wid, body)

    @api.get("/v1/revisions/{rid}/region-compartment-status")
    def compartment_status(rid: str, who: Owner):
        rev = region_revision(rid, who)
        root = result_root(rev)
        if rev["config"].get("recipe", {}).get("source") != "fiji_nuclear_compartment":
            raise HTTPException(409, "compartment_revision_required")
        provenance = read_json(root / "provenance.json")
        return {"revision_id": rid, "fields": {
            fid: {"nuclear_source": value.get("nuclear_source"),
                  **{key: value.get("detector", {}).get("engine", {}).get(key) for key in (
                      "nucleolar_states", "parent_ids", "eligible_nucleus_ids", "excluded_nucleus_ids",
                      "missing_parent_count", "missing_parent_reasons", "nucleoplasm_missing_reasons", "compartment_missing_parent_count")}}
            for fid, value in provenance.get("fields", {}).items()}}

    @api.post("/v1/workspaces/{wid}/gfp-gate")
    def gfp_gate(wid: str, body: GfpGateRequest, who: Owner):
        """Classify saved nuclei by mean GFP intensity; no new pixel masks are created."""
        workspace(wid, who)
        rows = []
        for item in body.fields:
            rev = region_revision(item.revision_id, who)
            recipe = rev["config"].get("recipe", {})
            expected_source = (recipe.get("source") in ("manual", "cellpose_cell") and recipe.get("region_set_id") == "cell") if body.unit == "cell_roi" else recipe.get("source") == "stardist_nuclear"
            if rev["workspace_id"] != wid or not expected_source or item.field_id not in rev["config"]["field_ids"]:
                raise HTTPException(409, "gfp_gate_requires_nuclear_revision")
            report = read_json(result_root(rev) / "measurements.json")
            table = report.get("field_tables", {}).get(item.field_id)
            if table is None:
                raise HTTPException(409, "field_failed")
            excluded = {e["region_id"] for e in report.get("exclusions", []) if e["field_id"] == item.field_id}
            if None in excluded:
                continue
            record = field_record(item.field_id, who)
            if body.gfp_channel_id not in {channel["channel_id"] for channel in record["image_info"].get("channels", [])}:
                raise HTTPException(422, "gfp_gate_channel_unknown")
            # New exploratory gates bind dates to the measured snapshot, matching formal statistics.
            metadata = (record["metadata"] or {}) if body.method == "negative_control" else rev["config"].get("field_snapshot", {}).get(item.field_id, {}).get("metadata", {})
            for row in table["rows"]:
                if row["channel_id"] == body.gfp_channel_id and row["region_id"] not in excluded:
                    rows.append({"field_id": item.field_id, "region_id": row["region_id"], "gfp_mean": row.get("mean_corrected" if body.values == "corrected" else "mean"),
                                 "acquisition_date": metadata.get("acquisition_date"), "control": item.control})
        if body.method == "negative_control" and not any(row["control"] for row in rows):
            raise HTTPException(422, "gfp_gate_requires_control_fields")
        if body.method == "negative_control":
            thresholds = control_thresholds(rows, body.percentile)
            gated = apply_control_gate(rows, thresholds)
        else:
            thresholds = exploratory_thresholds(rows, body.method, body.threshold)
            gated = apply_exploratory_gate(rows, thresholds)
        counts: dict[str, dict[str, int]] = {}
        for row in gated:
            value = counts.setdefault(row["field_id"], {"positive": 0, "negative": 0, "control": 0, "unselected": 0})
            key = "control" if row["control"] else "positive" if row["gfp_positive"] else "negative" if row["gfp_gate_reason"] in ("within_control_range", "at_or_below_exploratory_threshold") else "unselected"
            value[key] += 1
        objects = [{key: row[key] for key in ("field_id", "region_id", "gfp_mean", "gfp_positive", "gfp_gate_reason")} for row in gated]
        return {**thresholds, "gfp_channel_id": body.gfp_channel_id, "values": body.values, "unit": body.unit,
                "field_counts": counts, "objects": objects, "nuclei": objects if body.unit == "nucleus" else []}

    @api.get("/v1/revisions/{rid}/compartment-summary")
    def compartment_summary(rid: str, field_id: str, who: Owner):
        """Per-nucleus nucleolar/nucleoplasmic summary computed by the worker (never in the browser)."""
        rev = region_revision(rid, who)
        if field_id not in rev["config"]["field_ids"]:
            raise HTTPException(404, "field_not_found")
        path = result_root(rev) / field_id / "compartment-summary.json"
        if not path.is_file():
            raise HTTPException(409, "compartment_summary_unavailable")
        return read_json(path)

    @api.get("/v1/revisions/{rid}/region-measurements", response_model=RegionReportType)
    def measurements(rid: str, who: Owner):
        rev = region_revision(rid, who)
        report = read_json(result_root(rev) / "measurements.json")
        typed = region_report_from_json(json.dumps(report))
        validate_region_report_policy(typed, rev["config"])
        return typed

    @api.get("/v1/revisions/{rid}/region-masks")
    def masks(rid: str, field_id: str, who: Owner):
        rev = region_revision(rid, who)
        if field_id not in rev["config"]["field_ids"]:
            raise HTTPException(404, "field_not_found")
        root = result_root(rev)
        path = root / field_id / "labels.npy"
        if not path.is_file():
            raise HTTPException(409, "field_failed")
        report = read_json(root / "measurements.json")
        return {"regions": contours(np.load(path, allow_pickle=False)),
                "metadata": report.get("field_masks", {}).get(field_id)}

    @api.post("/v1/revisions/{rid}/region-edits", status_code=202)
    def edit(rid: str, body: RegionMaskEdit, who: Owner):
        parent = region_revision(rid, who)
        root = result_root(parent)
        if body.field_id not in parent["config"]["field_ids"]:
            raise HTTPException(404, "field_not_found")
        if body.region_set_id != parent["config"]["recipe"]["region_set_id"]:
            raise HTTPException(422, "region_set_mismatch")
        if not (root / body.field_id / "labels.npy").is_file():
            raise HTTPException(409, "field_failed")
        if body.expected_mask_revision_id is not None:
            metadata = read_json(root / "measurements.json").get("field_masks", {}).get(body.field_id, {})
            if metadata.get("mask_revision_id") != body.expected_mask_revision_id:
                raise HTTPException(409, "stale_region_mask")
        config = {k: v for k, v in parent["config"].items() if k not in ("region_edit", "region_metadata_edit", "channel_annotation_edit")}
        config.update(reuse_revision=rid, region_edit=body.model_dump(mode="json"))
        return child_revision(parent, config)

    @api.post("/v1/revisions/{rid}/region-reconfigure", status_code=202)
    def reconfigure(rid: str, body: RegionAnalysisRequest, who: Owner):
        parent = region_revision(rid, who)
        root = result_root(parent)
        if body.recipe.model_dump(mode="json") != parent["config"]["recipe"]:
            raise HTTPException(409, "region_definition_requires_new_analysis")
        if body.field_ids is not None and set(body.field_ids) != set(parent["config"]["field_ids"]):
            raise HTTPException(409, "field_selection_requires_new_analysis")
        selected = list(parent["config"]["field_snapshot"].values())
        validate_request(body, selected, read_json(root / "measurements.json").get("field_masks", {}))
        config = {k: v for k, v in parent["config"].items() if k not in ("region_edit", "region_metadata_edit", "channel_annotation_edit")}
        # Returning to v1 removes the v2 policy instead of retaining it through
        # an update of the old revision dictionary. Other v1 defaults stay exact.
        config.pop("measurement", None)
        request_config = region_request_config(body)
        request_config.pop("field_ids", None)
        config.update(request_config, reuse_revision=rid)
        if "plan_resolution" not in body.model_fields_set:
            inherit_plan_resolution(config, parent["config"])
        bind_revision_plan(config, workspace(parent["workspace_id"], who).get("analysis_plan"),
                           parent_config=parent["config"])
        return child_revision(parent, config)

    @api.post("/v1/revisions/{rid}/region-metadata", status_code=202)
    def metadata(rid: str, body: RegionMetadataEdit, who: Owner):
        parent = region_revision(rid, who)
        result_root(parent)
        try:
            config = region_metadata_child_config(parent, body)
        except ValueError:
            raise HTTPException(422, "unknown_region_metadata_field") from None
        return child_revision(parent, config)
