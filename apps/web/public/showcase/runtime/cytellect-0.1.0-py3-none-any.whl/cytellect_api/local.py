"""Explicit single-user loopback mode; the cloud API never mounts these routes."""
from __future__ import annotations

import argparse
import contextlib
import errno
import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from pathlib import Path

import psutil
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from sqlalchemy import update
from starlette.staticfiles import StaticFiles

from .config import Settings, configure_private_tmp
from .db import digest, recorded_retention_mode, sessions
from .process_owner import Identity, process_alive, redirector_owner
from .views import LocalSetupView, SessionView


def installed_source_revision(root: Path | None = None) -> str | None:
    """A release label only when installed source matches its complete manifest.

    The manifest is not a code signature. Exported per-file/aggregate source
    hashes remain the identity of executed scientific code.
    """
    # Preserve the lexical wheel location so resolving a redirected package
    # cannot turn wheel verification into source-only manifest inspection.
    execution_file = Path(__file__).absolute()
    root = root or execution_file.parents[4]
    site_packages = root / ".venv/Lib/site-packages"
    wheel_execution = execution_file == (site_packages / "cytellect_api/local.py").absolute()
    manifest = root / "local-release.json"
    if not manifest.is_file():
        return None
    try:
        release = json.loads(manifest.read_text(encoding="utf-8"))
        revision = release["source_commit"]
        if release["schema"] != "cytellect-local-release/1" or not re.fullmatch("[a-f0-9]{40}", revision):
            return None
        entries = {}
        for item in release["files"]:
            name = item["path"]
            if (not isinstance(name, str) or name in entries or "\\" in name or ":" in name
                    or name.startswith("/") or any(part in {"", ".", ".."} for part in name.split("/"))):
                return None
            file = root / name
            if (not file.resolve().is_relative_to(root.resolve()) or not file.is_file()
                    or file.stat().st_size != item["size"]
                    or hashlib.sha256(file.read_bytes()).hexdigest() != item["sha256"]):
                return None
            entries[name] = item
        for relative in ("packages/analysis/src/cytellect_analysis", "services/api/src/cytellect_api",
                         "services/worker/src/cytellect_worker"):
            directory = root / relative
            if not (directory / "__init__.py").is_file():
                return None
            for file in directory.rglob("*.py"):
                if file.relative_to(root).as_posix() not in entries:
                    return None
            if wheel_execution:
                # A normal wheel executes its site-packages copies. Identical
                # source files elsewhere in the release are not sufficient.
                installed = site_packages / directory.name
                if installed.resolve() != installed.absolute():
                    return None
                expected = {name[len(relative) + 1:]: entry for name, entry in entries.items()
                            if name.startswith(relative + "/") and name.endswith(".py")}
                paths = list(installed.rglob("*"))
                # Check directories too: rglob need not descend into a linked
                # directory that could still supply an unrecorded Python module.
                if any(file.resolve() != file.absolute() for file in paths):
                    return None
                actual = {file.relative_to(installed).as_posix(): file for file in paths
                          if file.suffix.lower() == ".py"}
                if actual.keys() != expected.keys():
                    return None
                for name, file in actual.items():
                    if file.resolve() != file.absolute() or not file.is_file():
                        return None
                    content = file.read_bytes()
                    if (len(content) != expected[name]["size"]
                            or hashlib.sha256(content).hexdigest() != expected[name]["sha256"]):
                        return None
        return revision
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _local_owner(root: Path) -> str:
    """An ownership identifier, never an authentication token. Runtime is OS-user private."""
    path = root / "local-owner"
    if path.is_symlink() or path.resolve().parent != root.resolve():
        raise ValueError("local_owner_path_invalid")
    try:
        with path.open("x", encoding="ascii") as stream:
            if os.name != "nt":
                path.chmod(0o600)
            stream.write(str(uuid.uuid4()))
    except FileExistsError:
        pass
    return str(uuid.UUID(path.read_text(encoding="ascii").strip()))


def create_local_app(settings: Settings, web_dir: Path, port: int):
    origin = f"http://127.0.0.1:{port}"
    if settings.app_origin != origin or settings.secure_cookies or not 1 <= port <= 65535:
        raise ValueError("local_settings_invalid")
    web_dir = web_dir.resolve()
    if not (web_dir / "index.html").is_file():
        raise ValueError("local_static_build_missing")
    configure_private_tmp(settings)
    if os.name != "nt":
        settings.data_dir.chmod(0o700)
    owner = _local_owner(settings.data_dir)
    from .app import create_app

    app = create_app(settings)
    store = app.state.store

    @app.middleware("http")
    async def loopback_security(request: Request, call_next):
        host_values = request.headers.getlist("host")
        peer = request.client.host if request.client else ""
        site = request.headers.get("sec-fetch-site")
        request_origin = request.headers.get("origin")
        forwarded = any(key.lower().startswith("x-forwarded-") or key.lower() == "forwarded"
                        for key in request.headers)
        if (peer != "127.0.0.1" or host_values != [f"127.0.0.1:{port}"] or forwarded
                or (request_origin is not None and request_origin != origin)
                or site not in (None, "none", "same-origin")):
            return JSONResponse({"detail": "local_origin_required"}, status_code=403,
                                headers={"Cache-Control": "no-store"})
        response = await call_next(request)
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
            "connect-src 'self'; img-src 'self' blob: data:; font-src 'self'; "
            "form-action 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'"
        )
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        return response

    @app.get("/v1/local/setup", response_model=LocalSetupView)
    def setup():
        return {"mode": "local", "ready": True, "fiji_configured": bool(settings.fiji_executable),
                **settings.retention_policy}

    @app.post("/v1/local/session", response_model=SessionView)
    def bootstrap(request: Request, response: Response):
        # The existing API middleware also requires exact Origin and the custom
        # CSRF header. Cross-origin forms, scripts and DNS rebinding cannot mint
        # this cookie. Local processes/other accounts on this PC are trusted.
        if request.headers.get("sec-fetch-site") not in (None, "same-origin"):
            return JSONResponse({"detail": "local_origin_required"}, status_code=403)
        now = time.time()
        existing = request.cookies.get(settings.cookie_name)
        current = store.one(sessions, digest=digest(existing)) if existing else None
        if not (current and current["owner"] == owner and not current["revoked"] and current["expires"] > now):
            token = secrets.token_urlsafe(32)
            with store.transaction() as conn:
                conn.execute(sessions.insert().values(digest=digest(token), owner=owner,
                                                     expires=now + 7 * 86400, revoked=False))
            response.set_cookie(settings.cookie_name, token, httponly=True, secure=False,
                                samesite="strict", max_age=7 * 86400, path="/")
        return {"authenticated": True, "mode": "local", **settings.retention_policy, "demo": settings.demo}

    app.mount("/", StaticFiles(directory=web_dir, html=True, follow_symlink=False), name="local-ui")
    return app


@contextlib.contextmanager
def runtime_lock(root: Path):
    """OS-released lock prevents two launchers sharing SQLite/worker ownership."""
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = root / "local-launcher.lock"
    if path.is_symlink():
        raise ValueError("local_lock_path_invalid")
    stream = path.open("a+b")
    try:
        try:
            stream.seek(0)
            if sys.platform == "win32":
                import msvcrt

                if path.stat().st_size == 0:
                    stream.write(b"0")
                    stream.flush()
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise ValueError("local_runtime_already_in_use") from exc
        yield
    finally:
        stream.close()


def bind_loopback(port: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # Windows otherwise permits a second binding under SO_REUSEADDR.
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        sock.bind(("127.0.0.1", port))
        sock.listen(128)
        return sock
    except BaseException:
        sock.close()
        raise


def local_cellpose_remote_environment(data_dir: Path) -> dict[str, str]:
    """Load the configured GPU inference service; images go there only for Cellpose."""
    path = data_dir.resolve().parent / "settings" / "cellpose-remote.json"
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 16_384:
            return {}
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if (not isinstance(value, dict) or value.get("schema") != "cytellect-cellpose-remote/1"
                or not set(value) <= {"schema", "url", "token"} or not isinstance(value.get("url"), str)
                or not isinstance(value.get("token", ""), str)):
            return {}
        environment = {"CYTELLECT_CELLPOSE_REMOTE_URL": value["url"]}
        if value.get("token"):
            environment["CYTELLECT_CELLPOSE_REMOTE_TOKEN"] = value["token"]
        return environment
    except (OSError, ValueError, TypeError):
        # A damaged optional setting must not disable Fiji or the whole workspace.
        return {}


def local_retention_mode(data_dir: Path) -> str:
    """Setup's explicit per-installation choice; a recorded manual policy never reverts."""
    if recorded_retention_mode(data_dir) == "manual":
        return "manual"
    path = data_dir.resolve().parent / "settings" / "retention.json"
    try:
        if path.is_file() and not path.is_symlink() and path.stat().st_size <= 4096 and json.loads(
                path.read_text(encoding="utf-8-sig")) == {"schema": "cytellect-local-retention/1", "mode": "manual"}:
            return "manual"
    except (OSError, ValueError):
        pass
    return "ttl"


def local_cellpose_environment(data_dir: Path) -> dict[str, str]:
    """Load an explicit local setup receipt without executing setup or downloading."""
    root = data_dir.resolve().parent
    path = root / "settings" / "cellpose.json"
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 16_384:
            return {}
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if (not isinstance(value, dict) or set(value) != {"schema", "python", "model_dir"}
                or value["schema"] != "cytellect-cellpose-local/1"):
            return {}
        python, models = Path(value["python"]), Path(value["model_dir"])
        if (not python.is_absolute() or not models.is_absolute()
                or not python.resolve().is_relative_to(root) or not models.resolve().is_relative_to(root)
                or not python.is_file() or not models.is_dir()):
            return {}
        return {"CYTELLECT_CELLPOSE_PYTHON": str(python), "CYTELLECT_CELLPOSE_MODEL_DIR": str(models)}
    except (OSError, ValueError, TypeError):
        # A damaged optional setup must not disable Fiji or the whole workspace.
        return {}


class WorkerSupervisor:
    def __init__(self, settings: Settings, stop_server):
        self.settings = settings
        self.stop_server = stop_server
        self.stopping = threading.Event()
        self.process: subprocess.Popen | None = None
        self.thread: threading.Thread | None = None
        self.failure: str | None = None
        self.worker_identity: Identity | None = None

    def _spawn(self):
        env = os.environ.copy()
        for key, value in {**local_cellpose_environment(self.settings.data_dir),
                           **local_cellpose_remote_environment(self.settings.data_dir)}.items():
            env.setdefault(key, value)
        if sys.dont_write_bytecode:
            env["PYTHONDONTWRITEBYTECODE"] = "1"
        env.update(CYTELLECT_DATA_DIR=str(self.settings.data_dir),
                   CYTELLECT_APP_ORIGIN=self.settings.app_origin, CYTELLECT_SECURE_COOKIES="false",
                   CYTELLECT_DEMO=str(self.settings.demo).lower(),
                   CYTELLECT_FIJI_EXECUTABLE=self.settings.fiji_executable,
                   CYTELLECT_WORKER_MEMORY_MB=str(self.settings.worker_memory_mb),
                   CYTELLECT_JOB_TIMEOUT_SECONDS=str(self.settings.job_timeout_seconds),
                   CYTELLECT_RETENTION_SECONDS=str(self.settings.retention_seconds),
                   CYTELLECT_WORKSPACE_RETENTION_MODE=self.settings.workspace_retention_mode)
        parent = psutil.Process()
        process = subprocess.Popen(
            [sys.executable, "-m", "cytellect_api.local_worker", str(parent.pid), str(parent.create_time())],
            env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
            start_new_session=os.name != "nt",
        )
        ready = threading.Event()
        identity_line: list[bytes] = []

        def read_identity():
            assert process.stdout is not None
            identity_line.append(process.stdout.readline(100))
            ready.set()

        threading.Thread(target=read_identity, daemon=True).start()
        try:
            deadline = time.monotonic() + 15
            while not ready.wait(0.1):
                if self.stopping.is_set() or time.monotonic() >= deadline:
                    raise RuntimeError("local_worker_start_failed")
            if self.stopping.is_set() or not identity_line:
                raise RuntimeError("local_worker_start_failed")
            pid, created = identity_line[0].decode("ascii").split()
            identity = (int(pid), float(created))
            worker = psutil.Process(identity[0])
            # Pipe contents are accepted only from this exact spawned tree.
            if (not process_alive(identity) or (identity[0] != process.pid
                    and process.pid not in [ancestor.pid for ancestor in worker.parents()])):
                raise RuntimeError("local_worker_start_failed")
            self.worker_identity = identity
            self.process = process
        except Exception:
            from cytellect_worker.supervision import terminate_tree

            terminate_tree(process.pid)
            process.wait(timeout=10)
            raise RuntimeError("local_worker_start_failed") from None
        finally:
            if ready.is_set() and process.stdout:
                process.stdout.close()

    def _stop_process(self):
        from cytellect_worker.supervision import terminate_tree

        # Stop the real interpreter first: a dead Windows shim no longer has a
        # traversable child tree. PID creation time prevents killing a reused PID.
        if self.worker_identity is not None and process_alive(self.worker_identity):
            terminate_tree(self.worker_identity[0])
        self.worker_identity = None
        if self.process is not None:
            terminate_tree(self.process.pid)
            self.process.wait(timeout=10)

    def start(self):
        self._spawn()

        def monitor():
            restarts = 0
            while not self.stopping.wait(0.25):
                if self.process is not None and self.process.poll() is not None:
                    self._stop_process()
                    if restarts >= 2:
                        self.failure = "local_worker_stopped"
                        self.stop_server()
                        return
                    restarts += 1
                    try:
                        self._spawn()
                    except Exception:
                        if self.stopping.is_set():
                            return
                        self.failure = "local_worker_start_failed"
                        self.stop_server()
                        return

        self.thread = threading.Thread(target=monitor, daemon=True)
        self.thread.start()

    def stop(self):
        self.stopping.set()
        if self.thread:
            # A restart may be midway through its identity handshake. It sees
            # stopping within100ms, kills that pending tree and returns before
            # we clean up the last adopted worker; never publish a late restart.
            self.thread.join(timeout=15)
        if self.process is not None:
            self._stop_process()


def _gui(server, url: str, run_server, open_browser: bool):
    import tkinter as tk
    from tkinter import ttk

    window = tk.Tk()
    window.title("Cytellect")
    window.geometry("460x205")
    window.resizable(False, False)
    window.option_add("*Font", "{Segoe UI} 10")
    body = ttk.Frame(window, padding=(24, 16))
    body.pack(fill="both", expand=True)
    status = tk.StringVar(value="起動中…")
    ttk.Label(body, text="Cytellect", font=("Segoe UI", 18)).pack(anchor="w", pady=(0, 8))
    ttk.Label(body, textvariable=status).pack(anchor="w")
    ttk.Label(body, text="この画面を閉じると、実行中の解析も停止します。", wraplength=410).pack(
        anchor="w", pady=(10, 16))

    def stop():
        server.should_exit = True
        status.set("停止中…")
        browser_button.configure(state="disabled")

    def open_current_browser():
        if server.started and not server.should_exit:
            webbrowser.open(url)

    controls = ttk.Frame(body)
    controls.pack(fill="x")
    browser_button = ttk.Button(controls, text="ブラウザで開く", command=open_current_browser, state="disabled")
    browser_button.pack(side="left")
    ttk.Button(controls, text="停止して閉じる", command=stop).pack(side="right")
    window.protocol("WM_DELETE_WINDOW", stop)
    thread = threading.Thread(target=run_server, daemon=False)
    thread.start()
    opened = False

    def tick():
        nonlocal opened
        running = server.started and not server.should_exit and thread.is_alive()
        browser_button.configure(state="normal" if running else "disabled")
        if running and not opened:
            opened = True
            status.set("稼働中 · " + url)
            if open_browser:
                webbrowser.open(url)
        if not thread.is_alive():
            window.destroy()
        else:
            window.after(150, tick)

    window.after(150, tick)
    try:
        window.mainloop()
    finally:
        server.should_exit = True
        thread.join()


def run_local(settings: Settings, web_dir: Path, port: int = 8765, *, open_browser=True, gui=False):
    import uvicorn

    redirector = redirector_owner()
    configure_private_tmp(settings)
    with runtime_lock(settings.data_dir), bind_loopback(port) as sock:
        app = create_local_app(settings, web_dir, port)
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, access_log=False,
                                               proxy_headers=False, log_level="error",
                                               timeout_graceful_shutdown=5))
        supervisor = WorkerSupervisor(settings, lambda: setattr(server, "should_exit", True))
        supervisor.start()
        owner_watch_stopped = threading.Event()

        def watch_redirector():
            while not owner_watch_stopped.wait(0.25):
                if redirector is not None and not process_alive(redirector):
                    server.should_exit = True
                    return

        if redirector is not None:
            threading.Thread(target=watch_redirector, daemon=True).start()
        try:
            if gui:
                _gui(server, settings.app_origin, lambda: server.run(sockets=[sock]), open_browser)
            else:
                if open_browser:
                    def open_when_ready():
                        while not server.started and not server.should_exit:
                            time.sleep(0.1)
                        if server.started and not server.should_exit:
                            webbrowser.open(settings.app_origin)
                    threading.Thread(target=open_when_ready, daemon=True).start()
                print("Cytellect local: " + settings.app_origin + " (Ctrl+C to stop)", flush=True)
                server.run(sockets=[sock])
        finally:
            owner_watch_stopped.set()
            supervisor.stop()
            # Sessions stop granting access across launcher shutdown. A later
            # same-origin bootstrap resumes the stable local owner's work.
            with app.state.store.transaction() as conn:
                conn.execute(update(sessions).where(sessions.c.owner == _local_owner(settings.data_dir))
                             .values(revoked=True))
        if supervisor.failure:
            raise RuntimeError(supervisor.failure)


def _report_startup_error(message: str, gui: bool):
    if gui and sys.platform == "win32":
        # A broken/missing Tcl installation must not make pythonw fail silently.
        import ctypes

        ctypes.windll.user32.MessageBoxW(None, message, "Cytellect", 0x10)
    elif gui:
        try:
            from tkinter import messagebox
            messagebox.showerror("Cytellect", message)
        except Exception:
            if sys.stderr:
                print(message, file=sys.stderr)
    elif sys.stderr:
        print(message, file=sys.stderr)


def _gui_failure_message(error: Exception) -> str:
    """Fixed user actions only; never expose exception text or filesystem paths."""
    if isinstance(error, ValueError) and error.args == ("local_runtime_already_in_use",):
        return "Cytellectは既に起動しています。開いているCytellectの画面をご利用ください。"
    if isinstance(error, OSError) and (error.errno == errno.EADDRINUSE
                                     or getattr(error, "winerror", None) == 10048):
        return "接続先が使用中のため起動できません。起動済みのCytellectを確認し、見当たらない場合はPCの管理者にご相談ください。"
    return "Cytellectを起動できないか、実行が停止しました。開き直しても続く場合は、セットアップを再実行してください。"


def main(argv=None):
    parser = argparse.ArgumentParser(prog="cytellect local")
    parser.add_argument("--data-dir", type=Path, default=os.environ.get("CYTELLECT_DATA_DIR"))
    parser.add_argument("--web-dir", type=Path, default=os.environ.get("CYTELLECT_WEB_DIR"))
    parser.add_argument("--fiji", default=os.environ.get("CYTELLECT_FIJI_EXECUTABLE", ""))
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--gui", action="store_true")
    args = parser.parse_args(argv)
    if (not args.data_dir or not args.web_dir or not args.fiji or not 1 <= args.port <= 65535
            or not Path(args.fiji).exists()):
        message = ("Cytellectの準備が完了していません。セットアップを再実行してください。" if args.gui else
                   "Cytellect installation is incomplete. Run the setup program again.")
        _report_startup_error(message, args.gui)
        raise SystemExit(2)
    settings = Settings(args.data_dir.resolve(), app_origin=f"http://127.0.0.1:{args.port}",
                        workspace_retention_mode=local_retention_mode(args.data_dir.resolve()),
                        secure_cookies=False, fiji_executable=args.fiji)
    os.environ.pop("CYTELLECT_CODE_REVISION", None)
    revision = installed_source_revision()
    if revision:
        os.environ["CYTELLECT_CODE_REVISION"] = revision
    try:
        from .local_storage import installed_usage_lock
        with installed_usage_lock():
            run_local(settings, args.web_dir, args.port, open_browser=not args.no_browser, gui=args.gui)
    except Exception as exc:
        message = (_gui_failure_message(exc) if args.gui else
                   "Cytellect could not start or stopped. Check the local port, installation and runtime directory.")
        _report_startup_error(message, args.gui)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
