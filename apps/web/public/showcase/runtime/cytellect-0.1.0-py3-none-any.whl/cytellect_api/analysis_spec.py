"""Persistent editable analysis intent; saving a draft never executes or adopts results."""
import time
from typing import Annotated, Literal, get_args

from cytellect_analysis.channel_gate_contracts import ChannelGateFilter
from cytellect_analysis.common_statistics_contracts import AssociationPlot, CommonComparisonPlot
from cytellect_analysis.descriptive_contracts import GfpFilter, LegacyMetric, RegionMetric
from cytellect_analysis.experiment_design import AnyExperimentDesign
from cytellect_analysis.group_comparison_contracts import FieldSummaryMetric, NucleolarSummaryMetric
from cytellect_analysis.proposal_contracts import (
    DraftCellProcessing,
    DraftFigure,
    DraftFigurePresentation,
    DraftMetric,
    DraftNuclearProcessing,
    DraftNucleolarProcessing,
    DraftSignalProcessing,
    DraftStatistics,
    MetricId,
)
from cytellect_analysis.region_contracts import RegionBackground, RegionFieldMetadata
from cytellect_analysis.region_policy import AutomaticBackgroundPolicy, RawIntensityPolicy
from cytellect_analysis.regions import Id, Label, RegionModel
from fastapi import Depends, HTTPException
from pydantic import Field, FiniteFloat, model_validator
from sqlalchemy import select

from .channel_assignments import assignments_at
from .db import fields, workspace_analysis_specs


class NucleolarDefinitionDraft(RegionModel):
    source: Literal["dapi_poor", "marker", "ncl"] = "dapi_poor"
    marker: Annotated[str, Field(max_length=80, pattern=r"^[A-Za-z0-9_-]*$")] = ""
    pixelUm: Annotated[FiniteFloat, Field(gt=0)] | None = None
    relative: Annotated[FiniteFloat, Field(gt=0, lt=1)] = 0.7
    algorithm: Literal["cellpose", "objects", "legacy"] | None = None


class CellDefinitionDraft(RegionModel):
    source: Literal["manual", "cellpose"] = "manual"
    channel: Annotated[str, Field(max_length=80, pattern=r"^[A-Za-z0-9_-]*$")] = ""


class RuntimeSettingsDraft(RegionModel):
    """Names deliberately match the workspace runtime; null keeps versioned detector defaults."""
    nuclearMaxSide: Annotated[int, Field(ge=64, le=2048)] | None = None
    nuclearProbability: Annotated[FiniteFloat, Field(ge=0, le=1)] = 0.5
    nuclearNms: Annotated[FiniteFloat, Field(ge=0, le=1)] = 0.3
    nucleolarDefinition: NucleolarDefinitionDraft = Field(default_factory=NucleolarDefinitionDraft)
    cellDefinition: CellDefinitionDraft = Field(default_factory=CellDefinitionDraft)
    nucleolarSigma: Annotated[FiniteFloat, Field(ge=0, le=20)] | None = None
    nucleolarRim: Annotated[int, Field(ge=0, le=100)] | None = None
    nucleolarMinimumArea: Annotated[int, Field(ge=1, le=100000)] | None = None
    nucleolarMaximumArea: Annotated[int, Field(ge=1, le=16777216)] | None = None
    background: Literal["raw", "automatic", "confirmed_roi"] = "raw"

    @model_validator(mode="after")
    def ordered_area(self):
        if (self.nucleolarDefinition.source == "ncl" and self.nucleolarSigma is not None
                and self.nucleolarSigma > 10):
            raise ValueError("analysis_spec_ncl_sigma_out_of_range")
        if (self.nucleolarMinimumArea is not None and self.nucleolarMaximumArea is not None
                and self.nucleolarMaximumArea < self.nucleolarMinimumArea):
            raise ValueError("analysis_spec_area_range_invalid")
        return self


class AnalysisSelectionDraft(RegionModel):
    field_ids: list[Id] = Field(default_factory=list, max_length=100)
    gfp: GfpFilter | None = None
    channel_gate: ChannelGateFilter | None = Field(default=None, exclude_if=lambda value: value is None)

    @model_validator(mode="after")
    def unique_fields(self):
        if len(self.field_ids) != len(set(self.field_ids)):
            raise ValueError("analysis_spec_duplicate_field")
        if self.gfp is not None and self.channel_gate is not None:
            raise ValueError("channel_gate_conflicting_filters")
        return self


class SavedDraftMetric(DraftMetric):
    # Saved editable metrics intentionally include the manual measurement vocabulary.
    metric: MetricId | RegionMetric | LegacyMetric  # type: ignore[assignment]
    channel: Id | None


class SavedDraftStatistics(DraftStatistics):
    x: SavedDraftMetric | None = None
    y: SavedDraftMetric | None = None


class SavedDraftFigure(DraftFigure):
    channel: Id | None


# Saved drafts name every metric the comparison accepts, including the field-summary and
# compartment-summary 1.1.0 metrics of the group-comparison workflow.
DraftOutcome = RegionMetric | LegacyMetric | FieldSummaryMetric | NucleolarSummaryMetric


class StatisticsDraft(RegionModel):
    method: SavedDraftStatistics | None = None
    metric: DraftOutcome = "area_px"
    channel_id: Id | None = None
    x_metric: RegionMetric | None = None
    x_channel_id: Id | None = None
    design: Literal["independent", "paired"] | None = None
    unit_definition: str = Field(default="", max_length=200)
    pairing_basis: str = Field(default="", max_length=200)
    conditions: list[Label] = Field(default_factory=list, max_length=30)
    comparisons: list[Annotated[list[Label], Field(min_length=2, max_length=2)]] = Field(
        default_factory=list, max_length=100)
    field_metadata: dict[Id, RegionFieldMetadata] = Field(default_factory=dict, max_length=100)
    # Drafts may be incomplete. Scientific confirmations remain in the execution contracts.


class FigureDraft(RegionModel):
    metric: DraftOutcome = "area_px"
    channel_id: Id | None = None
    plot: CommonComparisonPlot | AssociationPlot = Field(default_factory=CommonComparisonPlot)


class SavedNuclearProcessing(DraftNuclearProcessing):
    channel: Id


class SavedNucleolarProcessing(DraftNucleolarProcessing):
    channel: Id


class SavedSignalProcessing(DraftSignalProcessing):
    channel: Id


class SavedCellProcessing(DraftCellProcessing):
    channel: Id


class SavedProcessing(RegionModel):
    version: Literal["1.0.0"] = "1.0.0"
    nuclei: SavedNuclearProcessing | None
    nucleoli: SavedNucleolarProcessing | None
    signal: SavedSignalProcessing | None
    cells: SavedCellProcessing | None = None


def _now() -> float:
    return time.time()


class PrimaryOutcome(RegionModel):
    """The measure declared primary before results are read (genellect/cytellect#257 RP-04); any other measure is
    exploratory. The server sets `declared_at` when the declared measure changes, so it cannot be backdated."""
    version: Literal["1.0.0"] = "1.0.0"
    metric: DraftOutcome
    region_set_id: Literal["nuclei", "nucleoli", "nucleoplasm", "cell"]
    channel_id: Id | None = None
    declared_at: float | None = None

    @model_validator(mode="after")
    def declared_measure_exists(self):
        """A declaration names a measure a result can have: its region set and whether it reads a stain."""
        nuclear = ("solidity", "axis_ratio", "eccentricity", "nucleus_count", "nucleus_density_per_mm2")
        summaries = ("nucleolar_count", "nucleolar_area_fraction", "nucleolar_area_px", "nucleolar_area_um2",
                     "nucleolar_eccentricity", "largest_nucleolus_fraction")
        if self.metric in ("solidity", "axis_ratio", "eccentricity") and self.region_set_id != "nuclei":
            # Nuclear shape metrics describe nuclei only (nuclear-features/1.0.0).
            raise ValueError("nuclear_features_nuclei_only")
        if ((self.metric in nuclear and self.region_set_id != "nuclei")
                or (self.metric in (*summaries, "log2_nucleoplasm_over_nucleolus") and self.region_set_id != "nucleoplasm")):
            raise ValueError("primary_outcome_region_mismatch")
        no_stain = self.metric.startswith("area_") or self.metric in (*nuclear, *summaries)
        if self.metric not in get_args(LegacyMetric) and no_stain != (self.channel_id is None):
            raise ValueError("primary_outcome_channel_mismatch")
        return self


class AnalysisSpec(RegionModel):
    schema_version: Literal["1.0.0"] = "1.0.0"
    channel_assignment_version: int = Field(ge=0)
    target: Literal["nuclei", "nucleoli", "nucleoplasm", "cell"] = "nuclei"
    settings: RuntimeSettingsDraft = Field(default_factory=RuntimeSettingsDraft)
    processing: SavedProcessing | None = None
    measurement: RawIntensityPolicy | AutomaticBackgroundPolicy | None = None
    backgrounds: dict[Id, dict[Id, RegionBackground]] = Field(default_factory=dict, max_length=100)
    confirmed_channel_ids: list[Id] = Field(default_factory=list, max_length=6)
    metrics: list[SavedDraftMetric] = Field(default_factory=list, max_length=8)
    selection: AnalysisSelectionDraft = Field(default_factory=AnalysisSelectionDraft)
    statistics: StatisticsDraft | None = None
    additional_analyses: list[SavedDraftStatistics] = Field(default_factory=list, max_length=3)
    figure_proposals: list[SavedDraftFigure] = Field(default_factory=list, max_length=8)
    figure: FigureDraft | None = None
    # The adopted proposal's figure composition and legend terms (prompt 2026-11-19.1 and later).
    figure_presentation: DraftFigurePresentation | None = None
    # Experiment design 1.0.0 (additive): groups, runs and samples entered before analysis;
    # 1.1.0 adds declared strata compared one at a time.
    experiment: AnyExperimentDesign | None = None
    # Primary outcome 1.0.0 (additive): omitted until one is declared, so earlier specs keep their shape.
    primary_outcome: PrimaryOutcome | None = Field(default=None, exclude_if=lambda value: value is None)

    @model_validator(mode="after")
    def consistent_measurement(self):
        if len(set(self.confirmed_channel_ids)) != len(self.confirmed_channel_ids):
            raise ValueError("analysis_spec_duplicate_confirmed_channel")
        if self.settings.background == "confirmed_roi" and self.measurement is not None:
            raise ValueError("analysis_spec_background_mismatch")
        if self.measurement is not None:
            expected = "raw_intensity" if self.settings.background == "raw" else "automatic_background"
            if self.measurement.mode != expected:
                raise ValueError("analysis_spec_background_mismatch")
        return self


class AnalysisSpecWrite(RegionModel):
    version: int = Field(ge=0)
    spec: AnalysisSpec

    @model_validator(mode="after")
    def executable_association_axes(self):
        methods = [*self.spec.additional_analyses]
        if self.spec.statistics is not None and self.spec.statistics.method is not None:
            methods.append(self.spec.statistics.method)
        for method in methods:
            if method.kind == "association" and (method.x is not None or method.y is not None):
                if (method.x is None or method.y is None or method.x.region is None
                        or method.y.region is None or method.x.region != method.y.region):
                    raise ValueError("proposal_association_same_region_required")
        return self


class AnalysisSpecView(RegionModel):
    version: int = Field(ge=0)
    spec: AnalysisSpec | None
    # Hash of the saved experiment design; a stratified cohort request names it (experiment design 1.1.0).
    experiment_sha256: str | None = Field(default=None, exclude_if=lambda value: value is None)


def analysis_spec_at(conn, wid):
    row = conn.execute(select(workspace_analysis_specs).where(
        workspace_analysis_specs.c.workspace_id == wid)).mappings().first()
    if not row:
        return {"version": 0, "spec": None}
    return with_experiment_sha256({"version": row["version"], "spec": row["spec"]})


def with_experiment_sha256(view):
    """Add the hash of a stratified saved design (1.1.0); other responses keep their earlier shape."""
    from cytellect_analysis.experiment_strata import design_sha256, stratified

    experiment = (view["spec"] or {}).get("experiment")
    if experiment is not None and stratified(experiment) is not None:
        return {**view, "experiment_sha256": design_sha256(experiment)}
    return view


def saved_experiment(conn, wid):
    """The workspace's saved experiment design document, or None."""
    spec = analysis_spec_at(conn, wid)["spec"]
    return (spec or {}).get("experiment")


def require_source_strata(conn, rev):
    """API guard: a description or comparison reads exactly one declared stratum (design 1.1.0)."""
    from cytellect_analysis.experiment_strata import check_source_strata

    try:
        check_source_strata(saved_experiment(conn, rev["workspace_id"]), rev["config"])
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from None


def require_preview_strata(conn, rev):
    """API guard: an automatic preview never pools fields of several declared strata."""
    from cytellect_analysis.experiment_strata import check_preview_strata

    try:
        check_preview_strata(saved_experiment(conn, rev["workspace_id"]), rev["config"])
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from None


def register_analysis_spec_routes(api, store, owner, workspace, touch):
    Owner = Annotated[str, Depends(owner)]

    @api.get("/v1/workspaces/{wid}/analysis-spec", response_model=AnalysisSpecView)
    def get_spec(wid: str, who: Owner):
        workspace(wid, who)
        with store.engine.connect() as conn:
            return analysis_spec_at(conn, wid)

    @api.put("/v1/workspaces/{wid}/analysis-spec", response_model=AnalysisSpecView)
    def save_spec(wid: str, body: AnalysisSpecWrite, who: Owner):
        workspace(wid, who)
        with store.transaction() as conn:
            touch(conn, wid)
            previous = analysis_spec_at(conn, wid)
            if previous["version"] != body.version:
                raise HTTPException(409, "analysis_spec_changed")
            if assignments_at(conn, wid)["version"] != body.spec.channel_assignment_version:
                raise HTTPException(409, "channel_assignments_changed")
            registered = conn.execute(select(fields.c.id).where(fields.c.workspace_id == wid)).scalars().all()
            referenced = set(body.spec.selection.field_ids)
            referenced.update(body.spec.backgrounds)
            if body.spec.selection.gfp is not None:
                referenced.update(getattr(body.spec.selection.gfp, "control_field_ids", []))
            if body.spec.statistics is not None:
                referenced.update(body.spec.statistics.field_metadata)
            if body.spec.experiment is not None:
                referenced.update(body.spec.experiment.fields)
            if referenced - set(registered):
                raise HTTPException(422, "analysis_spec_unknown_field")
            spec = body.spec.model_dump(mode="json")
            spec_primary = spec.get("primary_outcome")
            if spec_primary is not None:
                earlier = (previous["spec"] or {}).get("primary_outcome") or {}
                same = all(earlier.get(key) == spec_primary[key] for key in ("metric", "region_set_id", "channel_id"))
                # The time of a declaration is the server's: kept while the measure is unchanged, renewed when it changes.
                spec_primary["declared_at"] = earlier.get("declared_at") if same and earlier.get("declared_at") else _now()
            updated = {"version": body.version + 1, "spec": spec}
            if previous["version"]:
                conn.execute(workspace_analysis_specs.update().where(
                    workspace_analysis_specs.c.workspace_id == wid).values(**updated))
            else:
                conn.execute(workspace_analysis_specs.insert().values(workspace_id=wid, **updated))
            return with_experiment_sha256(updated)
