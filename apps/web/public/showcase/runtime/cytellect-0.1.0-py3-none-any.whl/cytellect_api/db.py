"""Local SQLite transactions; CAS leases prevent stale workers publishing."""

import contextlib
import hashlib
import os
import secrets
import sqlite3
import time
import uuid
from pathlib import Path, PurePath, PureWindowsPath

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    Float,
    Index,
    Integer,
    MetaData,
    String,
    Table,
    create_engine,
    event,
    false,
    select,
    update,
)

meta = MetaData()
workspaces = Table(
    "workspaces",
    meta,
    Column("id", String, primary_key=True),
    Column("owner", String, nullable=False, index=True),
    Column("title", String, nullable=False),
    Column("created", Float, nullable=False),
    Column("expires", Float, nullable=False),
    Column("deleted", Boolean, default=False, nullable=False),
    Column("active_revision", String),
    Column("bytes", Integer, default=0, nullable=False),
    Column("analysis_plan", JSON),
)
# One installation-wide row. Once manual retention is recorded, a later TTL start
# is refused even if the marker file beside the database is lost.
retention_policy = Table(
    "retention_policy",
    meta,
    Column("id", Integer, primary_key=True),
    Column("mode", String, nullable=False),
    Column("activated", Float, nullable=False),
)
workspace_selections = Table(
    "workspace_selections", meta,
    Column("workspace_id", String, primary_key=True),
    Column("version", Integer, nullable=False),
    Column("entries", JSON, nullable=False),
)
workspace_channel_assignments = Table(
    "workspace_channel_assignments", meta,
    Column("workspace_id", String, primary_key=True),
    Column("version", Integer, nullable=False),
    Column("assignments", JSON, nullable=False),
    Column("global_field_ids", JSON, nullable=False, default=list),
    Column("groups", JSON, nullable=False, default=list),
)
workspace_analysis_specs = Table(
    "workspace_analysis_specs", meta,
    Column("workspace_id", String, primary_key=True),
    Column("version", Integer, nullable=False),
    Column("spec", JSON, nullable=False),
)
workspace_analysis_runs = Table(
    "workspace_analysis_runs", meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("request_id", String, nullable=False),
    Column("request_fingerprint", String, nullable=False),
    Column("spec_version", Integer, nullable=False),
    Column("spec_snapshot", JSON, nullable=False),
    Column("selection_snapshot", JSON, nullable=False),
    Column("assignments_snapshot", JSON, nullable=False),
    Column("target", String, nullable=False),
    Column("state", String, nullable=False),
    Column("steps", JSON, nullable=False),
    Column("created", Float, nullable=False),
    Column("updated", Float, nullable=False),
    Index("uq_analysis_run_request", "workspace_id", "request_id", unique=True),
)
workspace_field_links = Table(
    "workspace_field_links", meta,
    Column("workspace_id", String, primary_key=True),
    Column("version", Integer, nullable=False),
    Column("entries", JSON, nullable=False),
)
invitations = Table(
    "invitations",
    meta,
    Column("digest", String, primary_key=True),
    Column("expires", Float, nullable=False),
    Column("used", Boolean, default=False, nullable=False),
)
sessions = Table(
    "sessions",
    meta,
    Column("digest", String, primary_key=True),
    Column("owner", String, nullable=False),
    Column("expires", Float, nullable=False),
    Column("revoked", Boolean, default=False, nullable=False),
)
fields = Table(
    "fields",
    meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("metadata", JSON, nullable=False),
    Column("image_info", JSON, nullable=False),
    Column("synthetic", Boolean, default=False, nullable=False),
    Column("client_upload_id", String),
    Column("upload_fingerprint", String),
    Column("display_name", String),
    Index("uq_fields_workspace_client_upload_id", "workspace_id", "client_upload_id", unique=True),
)
revisions = Table(
    "revisions",
    meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("parent_id", String),
    Column("config", JSON, nullable=False),
    Column("state", String, nullable=False),
    Column("reviewed", Boolean, default=False, nullable=False),
    Column("review_record", JSON),
    Column("result_dir", String),
    Column("created", Float, nullable=False),
)
jobs = Table(
    "jobs",
    meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("revision_id", String, nullable=False),
    Column("kind", String, nullable=False),
    Column("state", String, nullable=False),
    Column("payload", JSON, nullable=False),
    Column("created", Float, nullable=False),
    Column("lease", String),
    Column("lease_until", Float),
    Column("attempts", Integer, default=0, nullable=False),
    Column("error", String),
    Column("result_dir", String),
)
attempts = Table(
    "job_attempts",
    meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("job_id", String, nullable=False),
    Column("created", Float, nullable=False),
)
tables = Table(
    "numerical_tables",
    meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("metadata", JSON, nullable=False),
    Column("row_count", Integer, nullable=False),
    Column("created", Float, nullable=False),
)
proposal_drafts = Table(
    "proposal_drafts", meta,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("cache_key", String, nullable=False),
    Column("request_id", String, nullable=False),
    Column("state", String, nullable=False),
    Column("created", Float, nullable=False),
    Column("lease_until", Float, nullable=False),
    Column("proposal", JSON),
    Index("uq_proposal_workspace_key", "workspace_id", "cache_key", unique=True),
)
events = Table(
    "events",
    meta,
    Column("id", String, primary_key=True),
    Column("kind", String, nullable=False),
    Column("created", Float, nullable=False),
    Column("data", JSON, nullable=False),
)


def uid():
    return str(uuid.uuid4())


def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def _windows_storage_path(path: PureWindowsPath) -> PureWindowsPath | None:
    """Compare resolved drive/UNC paths without stripping extended semantics."""
    if not path.is_absolute() or ".." in path.parts:
        return None
    drive = path.drive
    extended = drive.startswith("\\\\?\\")
    plain_drive = drive[4:] if extended else drive
    if (len(plain_drive) == 2 and plain_drive[0] in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            and plain_drive[1] == ":"):
        return path if extended else PureWindowsPath("\\\\?\\" + str(path))
    # Do not reinterpret device paths (\\.\, GLOBALROOT, volume GUIDs) as UNC.
    if extended:
        if not plain_drive.startswith("UNC\\"):
            return None
        share = plain_drive[4:].split("\\")
    else:
        if not drive.startswith("\\\\"):
            return None
        share = drive[2:].split("\\")
    if len(share) != 2 or any(part in {"", ".", "..", "?"} for part in share):
        return None
    return path if extended else PureWindowsPath("\\\\?\\UNC\\" + str(path)[2:])


def _relative_storage_path(target: PurePath, root: PurePath) -> str:
    if isinstance(target, PureWindowsPath) or isinstance(root, PureWindowsPath):
        if not isinstance(target, PureWindowsPath) or not isinstance(root, PureWindowsPath):
            raise ValueError("invalid_storage_path")
        windows_target, windows_root = _windows_storage_path(target), _windows_storage_path(root)
        if windows_target is None or windows_root is None:
            raise ValueError("invalid_storage_path")
        target, root = windows_target, windows_root
    try:
        return target.relative_to(root).as_posix()
    except ValueError:
        raise ValueError("invalid_storage_path") from None


def _is_within_storage(target: PurePath, root: PurePath) -> bool:
    try:
        _relative_storage_path(target, root)
        return True
    except ValueError:
        return False


def recorded_retention_mode(root: Path) -> str | None:
    """Read an existing installation's recorded policy without migrating or writing."""
    database = root / "cytellect.sqlite"
    if not database.is_file():
        return None
    try:
        with contextlib.closing(sqlite3.connect(f"file:{database.as_posix()}?mode=ro", uri=True)) as conn:
            row = conn.execute("SELECT mode FROM retention_policy WHERE id = 1").fetchone()
    except sqlite3.Error:
        return None
    return row[0] if row else None


class Store:
    def __init__(self, root: Path, *, workspace_retention_mode: str = "ttl"):
        if workspace_retention_mode not in {"ttl", "manual"}:
            raise ValueError("workspace_retention_mode_invalid")
        self.workspace_retention_mode = workspace_retention_mode
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        # A permanent, empty marker prevents a later TTL launch from deleting
        # workspaces with dormant historical deadlines. Never auto-remove it.
        marker = self.root / ".manual-workspace-retention"
        if workspace_retention_mode == "manual":
            if marker.is_symlink() or (marker.exists() and not marker.is_file()):
                raise ValueError("workspace_retention_marker_invalid")
            try:
                fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                pass
            else:
                try:
                    os.fsync(fd)
                finally:
                    os.close(fd)
            if os.name == "posix":
                directory_fd = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        self.assert_retention_mode()
        self.engine = create_engine(
            "sqlite:///" + (self.root / "cytellect.sqlite").as_posix(),
            connect_args={"check_same_thread": False, "timeout": 30},
        )

        @event.listens_for(self.engine, "connect")
        def pragma(dbapi, _):
            dbapi.execute("PRAGMA journal_mode=WAL")
            dbapi.execute("PRAGMA foreign_keys=ON")
            dbapi.execute("PRAGMA busy_timeout=30000")

        from alembic import command
        from alembic.config import Config

        migration = Config()
        migration.set_main_option("script_location", str(Path(__file__).parent / "migrations"))
        with self.transaction() as conn:
            migration.attributes["connection"] = conn
            command.upgrade(migration, "head")
        self._activate_retention_mode()

    def _activate_retention_mode(self):
        now = time.time()
        with self.transaction() as conn:
            recorded = conn.execute(select(retention_policy.c.mode).where(retention_policy.c.id == 1)).scalar()
            if recorded == "manual" and self.workspace_retention_mode == "ttl":
                raise ValueError("workspace_retention_manual_to_ttl_forbidden")
            if recorded is None and self.workspace_retention_mode == "manual":
                # A deadline that already passed under TTL stays expired: switching to
                # manual retention never revives it, and cleanup removes its files.
                conn.execute(update(workspaces)
                             .where(workspaces.c.deleted.is_(False), workspaces.c.expires <= now)
                             .values(deleted=True))
                conn.execute(retention_policy.insert().values(id=1, mode="manual", activated=now))
        self._policy_recorded = True

    def assert_retention_mode(self):
        marker = self.root / ".manual-workspace-retention"
        if marker.is_symlink() or (marker.exists() and not marker.is_file()):
            raise ValueError("workspace_retention_marker_invalid")
        if self.workspace_retention_mode == "ttl" and marker.exists():
            raise ValueError("workspace_retention_manual_to_ttl_forbidden")

    def workspace_expired_filter(self, now):
        self.assert_retention_mode()
        return workspaces.c.expires <= now if self.workspace_retention_mode == "ttl" else false()

    def workspace_is_live(self, record, now=None):
        self.assert_retention_mode()
        return bool(record and not record["deleted"] and (
            self.workspace_retention_mode == "manual"
            or record["expires"] > (time.time() if now is None else now)))

    def workspace_view(self, record):
        self.assert_retention_mode()
        return {**dict(record), "expires": None if self.workspace_retention_mode == "manual" else record["expires"]}

    @contextlib.contextmanager
    def transaction(self):
        with self.engine.connect() as conn:
            conn.exec_driver_sql("BEGIN IMMEDIATE")
            self.assert_retention_mode()
            if self.workspace_retention_mode == "ttl" and getattr(self, "_policy_recorded", False) and conn.execute(
                    select(retention_policy.c.mode).where(retention_policy.c.id == 1)).scalar() == "manual":
                raise ValueError("workspace_retention_manual_to_ttl_forbidden")
            try:
                yield conn
                conn.commit()
            except BaseException:
                conn.rollback()
                raise

    def one(self, table, **filters):
        with self.engine.connect() as conn:
            return conn.execute(select(table).filter_by(**filters)).mappings().first()

    def rows(self, table, **filters):
        with self.engine.connect() as conn:
            return list(conn.execute(select(table).filter_by(**filters)).mappings())

    def invite(self, ttl=86400):
        token = secrets.token_urlsafe(32)
        with self.transaction() as c:
            c.execute(
                invitations.insert().values(digest=digest(token), expires=time.time() + ttl, used=False)
            )
        return token

    def claim(self):
        now = time.time()
        with self.transaction() as c:
            expired = (
                c.execute(select(jobs).where(jobs.c.state == "running", jobs.c.lease_until < now))
                .mappings()
                .all()
            )
            for job in expired:
                state = "queued" if job["attempts"] < 2 else "failed"
                c.execute(
                    update(jobs)
                    .where(jobs.c.id == job["id"])
                    .values(
                        state=state, lease=None, error="worker_interrupted" if state == "failed" else None
                    )
                )
                if state == "failed" and job["kind"] == "analysis":
                    c.execute(
                        update(revisions).where(revisions.c.id == job["revision_id"]).values(state="failed")
                    )
            # Exactly one live scientific task across multiple accidental worker processes.
            if c.execute(
                select(jobs.c.id).where(jobs.c.lease_until > now, jobs.c.state.in_(["running", "cancelled"]))
            ).first():
                return None
            job = (
                c.execute(
                    select(jobs)
                    .join(workspaces, jobs.c.workspace_id == workspaces.c.id)
                    .where(
                        jobs.c.state == "queued", workspaces.c.deleted.is_(False), ~self.workspace_expired_filter(now)
                    )
                    .order_by(jobs.c.created)
                    .limit(1)
                )
                .mappings()
                .first()
            )
            if job is None:
                return None
            lease = uid()
            c.execute(
                update(jobs)
                .where(jobs.c.id == job["id"])
                .values(state="running", lease=lease, lease_until=now + 60, attempts=job["attempts"] + 1)
            )
            if job["kind"] == "analysis":
                c.execute(
                    update(revisions).where(revisions.c.id == job["revision_id"]).values(state="running")
                )
            return {**dict(job), "lease": lease, "attempts": job["attempts"] + 1}

    def heartbeat(self, job):
        with self.transaction() as c:
            workspace = (
                c.execute(select(workspaces).where(workspaces.c.id == job["workspace_id"])).mappings().first()
            )
            if not self.workspace_is_live(workspace):
                return False
            result = c.execute(
                update(jobs)
                .where(
                    jobs.c.id == job["id"],
                    jobs.c.lease == job["lease"],
                    jobs.c.state == "running",
                    jobs.c.lease_until > time.time(),
                )
                .values(lease_until=time.time() + 60)
            )
            return result.rowcount == 1

    def finish(self, job, result_dir=None, error=None):
        state = "failed" if error else "succeeded"
        with self.transaction() as c:
            workspace = (
                c.execute(select(workspaces).where(workspaces.c.id == job["workspace_id"])).mappings().first()
            )
            if not self.workspace_is_live(workspace):
                return False
            # Adoption and successful publication share this SQLite write lock.
            # An already completed artifact stays immutable; only the running
            # attempt is rejected when another tab changed its selected inputs.
            if not error and job["kind"] == "statistics" and job["payload"].get("mode") in ("region-experimental-unit", "region-association"):
                from .workspace_selection import selection_at

                source = c.execute(select(revisions).where(revisions.c.id == job["revision_id"])).mappings().first()
                adoption = source["config"].get("workspace_selection") if source else None
                if adoption and selection_at(c, job["workspace_id"]) != adoption:
                    state, error, result_dir = "failed", "workspace_selection_changed", None
            result = c.execute(
                update(jobs)
                .where(
                    jobs.c.id == job["id"],
                    jobs.c.lease == job["lease"],
                    jobs.c.state == "running",
                    jobs.c.lease_until > time.time(),
                )
                .values(state=state, result_dir=result_dir, error=error)
            )
            if result.rowcount != 1:
                return False
            if job["kind"] == "analysis":
                c.execute(
                    update(revisions)
                    .where(revisions.c.id == job["revision_id"])
                    .values(state=state, result_dir=result_dir)
                )
            c.execute(
                events.insert().values(
                    id=uid(),
                    kind="job_finished",
                    created=time.time(),
                    data={"kind": job["kind"], "state": state, "attempt": job["attempts"]},
                )
            )
            return True

    def safe_path(self, *parts):
        target = self.root.joinpath(*parts).resolve()
        # Windows realpath may retain \\?\ if a missing parent appears between
        # lookups. Compare both resolved paths in one namespace, but keep the
        # resolved I/O path (including junction resolution) unchanged.
        if not _is_within_storage(target, self.root):
            raise ValueError("invalid_storage_path")
        return target

    def relative_path(self, path: Path) -> str:
        """Return a checked POSIX artifact name without altering its I/O path."""
        return _relative_storage_path(path.resolve(), self.root)
