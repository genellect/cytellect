# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
106 selected observations are shown across all 1 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=106; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=096854e4-38ab-493f-8353-fd8dbb5aa2a4; selected=22; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 2: field_id=0ff90359-f67c-40d5-8fbf-eb0de015a9c9; selected=20; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 3: field_id=a1f361b8-974d-4a02-b63c-9fdb278f5fab; selected=14; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 4: field_id=bcbb1c89-92ca-4b9f-b197-d38078f43243; selected=10; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 5: field_id=cf4b59fe-86b8-4b5a-b029-8d91f55b05be; selected=25; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 6: field_id=de5e2572-907b-4a95-9c47-c4c84265278b; selected=15; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=096854e4-38ab-493f-8353-fd8dbb5aa2a4; Field 2: field_id=0ff90359-f67c-40d5-8fbf-eb0de015a9c9; Field 3: field_id=a1f361b8-974d-4a02-b63c-9fdb278f5fab; Field 4: field_id=bcbb1c89-92ca-4b9f-b197-d38078f43243; Field 5: field_id=cf4b59fe-86b8-4b5a-b029-8d91f55b05be; Field 6: field_id=de5e2572-907b-4a95-9c47-c4c84265278b
