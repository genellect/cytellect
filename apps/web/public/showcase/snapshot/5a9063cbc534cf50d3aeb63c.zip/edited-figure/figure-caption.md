# Figure legend

Large points are independent experimental units (median per field → sample mean → unit mean); the same marker marks the same run and lines join a run's units; small points are field values (median of the field's observations). Horizontal lines show the mean of unit values (descriptive: no test or interval, run independence not confirmed). n is the number of experimental units, not fields or nuclei.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 8e4d36a2-5272-40f7-a8e2-c5865fbac948; fingerprint: c8e9d37c8582fc0ac9980b58914ce046a499ae939c05d11cd78ee1a49a31127f.

Inference core: 1.0.0; request protocol: 2.0.0.

The inferential unit was 反復（Rep1–Rep3。独立性は出典で確認できない）.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each independent experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: 5-EU: Mean intensity
(a.u.); region definition: 核.

Outcome channel ID: eu5; declared stain: 5-EU.

Outcome uses raw original-pixel intensity measurements.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と ActD. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): ActD 1 µM minus Untreated; n=3 and 3 independent units, 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=2340.2964, ActD 1 µM=2562.6296, difference=222.33318.

Run Rep2: Untreated=3020.0327, ActD 1 µM=2712.2646, difference=-307.76816.

Run Rep3: Untreated=3250.441, ActD 1 µM=2582.2225, difference=-668.21851.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
