# Cytellect publication package

`edited-figure/` contains the figure as saved in the workspace. `figure-result.json` contains its immutable measurements, statistics and plot settings.

Extract `analysis.zip` and follow its replay instructions to regenerate the masks, measurements and statistics. Use that pinned Python environment to run `python replay-figure.py output` for the edited figure. Changing its appearance does not recalculate statistics. `manifest.json` records SHA-256 hashes linking these files.
