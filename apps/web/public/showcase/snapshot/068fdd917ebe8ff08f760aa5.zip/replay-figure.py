from pathlib import Path
from typing import Any, Callable
import json
import hashlib
import sys
from cytellect_analysis.common_statistics_figures import render_common_statistics
from cytellect_analysis.descriptive_output import render_descriptive_output
from cytellect_analysis.figures import render_figures
from cytellect_analysis.region_comparison_figures import render_region_comparison
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
for name, digest in manifest['files'].items():
    path = root / name
    if path.resolve().is_relative_to(root) is False or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise ValueError('source file changed')
result = json.loads((root / 'figure-result.json').read_text(encoding='utf-8'))
result.pop('figure', None)
if result.get('analysis_kind') == 'region-association' or result.get('region_comparison_version') == '2.0.0':
    renderer = render_common_statistics
elif result.get('analysis_kind') == 'region-comparison':
    renderer = render_region_comparison
elif result.get('source_kind') == 'measured-numerical-assay' and result.get('spec', {}).get('mode') != 'descriptive':
    renderer = render_figures
else:
    renderer = render_descriptive_output
renderer(result, Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'regenerated-figure')
