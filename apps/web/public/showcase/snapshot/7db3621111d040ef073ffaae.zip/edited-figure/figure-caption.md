# Figure legend

**Nuclei per field decreased by 79–84% with PLK1 KO.**

We quantified nuclei per field in [Cell line] cells ([treatment and duration]) labelled with [antibody or dye for each stain]. Small dots show individual fields, coloured by run; large symbols show the value of each run (the mean of its fields); lines join the same run; horizontal lines show the mean of runs. n = 3 runs per condition; 9 fields per condition; individual fields are not treated as independent replicates. Per-run changes of PLK1 KO relative to Non-targeting: −82% (Run1), −79% (Run2) and −84% (Run3). No hypothesis test or confidence interval was calculated because the independence of the runs was not confirmed.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 798ab06f-a9cb-4877-ad2e-68a97f047e48; fingerprint: 1fbb48885cfe211ea6ad6c4ee6220b3e324bdf34ee66f6787fcd574aea578f88.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 実験回（Run1–Run3。日付の異なるバッチの別のプレート）; the researcher had not confirmed that these units were independent.

Each field contributed one field value, then fields were reduced to an unweighted mean within each sample and samples to an unweighted mean within each recorded experimental unit. Fields were not treated as independent replicates.

Conditions in the declared analysis: Non-targeting, PLK1 KO.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: Nucleus count
(nuclei per field); region definition: 核.

Outcome is one value per field (field-summary selection 1.0.0): adopted nuclei per field, including nuclei touching the image border (field-summary/1.0.0). Fields, not nuclei, are the observations; explicitly excluded nuclei are not counted and excluded or failed fields are not observations. A nucleus count is the number of imaged nuclei, not a viability or proliferation measure, and it depends on how fields were chosen.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ実験回（プレート）の対照と PLK1 ノックアウト. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): PLK1 KO minus Non-targeting; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Run1: Non-targeting=456.33333, PLK1 KO=80, difference=-376.33333.

Run Run2: Non-targeting=347.33333, PLK1 KO=73, difference=-274.33333.

Run Run3: Non-targeting=450.33333, PLK1 KO=70.333333, difference=-380.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
