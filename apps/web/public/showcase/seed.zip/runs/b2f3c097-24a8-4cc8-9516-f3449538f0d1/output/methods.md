# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: mean; unit: a.u..
Region definition: nucleoli (region set ID nucleoli; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measured channel: 5-EU; stain: 5-EU; recorded channel ID: eu5.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
Each region outcome is the arithmetic mean of (I) over its measured pixels.
The selected raw outcome does not subtract background.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 588; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 588 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 0 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 03edbd56-898a-4e31-8be6-1da76cc60b6c, 03f6ef2f-c197-4be5-bc4b-d8acccc56e60, 14dd89f1-5d07-4b2f-ab4e-b4d9c8c73189, 1ca4b476-0a50-4f2b-984c-92c2dad5a78f, 32d6623a-3b5c-426c-b09b-34db06c0ef92, 3f2f0bfc-b5c5-491e-bcea-287b6cf815df, 3f577820-ed9a-4946-a1d6-6bc29bcd94ef, 48459d7f-4a2f-4358-b319-32aa43329645, 52223f05-82d2-4b69-b464-92c6edb9fc68, 90162934-cd9f-44bb-8211-708224c058ba, 9b057468-a01f-47ab-8e91-a74d4eba9edd, a44c1da1-728a-4f41-852f-91ff7683ad06, a5829f7f-0aaa-4c3e-818a-b36d0495b989, abd7d7ae-8031-49bd-995b-46f28cd108a2, b6a4b55f-0b76-4ff3-a920-7bd3f78e62de, c297ed2d-2b48-42be-907a-4bb44b1b51d1, dafaa5ec-640a-4183-ba48-784d467114ae, dc91ded5-8614-4864-a940-f995cfc41f5e) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
