# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=0922beb0-273c-4e09-b121-77201f3e23ec; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=1532c783-a0e7-49b0-b866-3d6ac3a23686; selected=31; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2d5d5dae-f9ea-45f8-a9cd-10b32dbaccc5; selected=52; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=436db75e-8874-42e9-8dab-1e1ca2e672dd; selected=36; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=5aadaab6-cd36-45d2-a86b-df5f439ae8e3; selected=12; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=65e543f8-58ad-47e4-a5a2-fa1d89524a13; selected=62; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=6c66c709-6ab2-429a-b9f2-831213c4ba5a; selected=78; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=6eec0e3f-121a-4fc1-8184-4883606304b9; selected=37; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=75c952a7-1a8c-4139-93d4-a2f2ea7d8114; selected=19; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=7ab87c0c-177a-480f-b61d-0095ec9c0967; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=9f83ac84-7500-4bca-a79d-7ba48d3d78c2; selected=13; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=a2b9c2d7-02e0-45dc-9408-aa4e16d43733; selected=17; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=a54337aa-8bb5-47ef-bd1a-aa3f99555013; selected=22; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=b0a9c81a-75ad-4b9f-98db-87b245373671; selected=32; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=ef02a6f3-a6c6-4952-bca5-72d64ecf6088; selected=33; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=f3c972dd-20e4-4e61-ad5f-ad094d15ba91; selected=15; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=f5d09f72-87df-4c7e-a569-fb3de08bcf15; selected=83; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=f77ddf6f-4150-4486-93b6-669c80651404; selected=10; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=0922beb0-273c-4e09-b121-77201f3e23ec; Field 2: field_id=1532c783-a0e7-49b0-b866-3d6ac3a23686; Field 3: field_id=2d5d5dae-f9ea-45f8-a9cd-10b32dbaccc5; Field 4: field_id=436db75e-8874-42e9-8dab-1e1ca2e672dd; Field 5: field_id=5aadaab6-cd36-45d2-a86b-df5f439ae8e3; Field 6: field_id=65e543f8-58ad-47e4-a5a2-fa1d89524a13; Field 7: field_id=6c66c709-6ab2-429a-b9f2-831213c4ba5a; Field 8: field_id=6eec0e3f-121a-4fc1-8184-4883606304b9
- Page 2: Field 9: field_id=75c952a7-1a8c-4139-93d4-a2f2ea7d8114; Field 10: field_id=7ab87c0c-177a-480f-b61d-0095ec9c0967; Field 11: field_id=9f83ac84-7500-4bca-a79d-7ba48d3d78c2; Field 12: field_id=a2b9c2d7-02e0-45dc-9408-aa4e16d43733; Field 13: field_id=a54337aa-8bb5-47ef-bd1a-aa3f99555013; Field 14: field_id=b0a9c81a-75ad-4b9f-98db-87b245373671; Field 15: field_id=ef02a6f3-a6c6-4952-bca5-72d64ecf6088; Field 16: field_id=f3c972dd-20e4-4e61-ad5f-ad094d15ba91
- Page 3: Field 17: field_id=f5d09f72-87df-4c7e-a569-fb3de08bcf15; Field 18: field_id=f77ddf6f-4150-4486-93b6-669c80651404
