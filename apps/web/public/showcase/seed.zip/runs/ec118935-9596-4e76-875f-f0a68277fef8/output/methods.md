# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: aebf232d-0590-4963-8d0a-a756ca9c5729; fingerprint: 78a30422b54214dcbebef2f91feb13794e78405d6722dabd46ec696b46c2f21a.

Inference core: 1.0.0; request protocol: 1.0.0.

The inferential unit was 反復（Rep1–Rep3）内の各処理条件（同日撮影。反復の独立性は出典に記載なし）.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each independent experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

X: Region area
(pixel²); region definition: 核.

X counts original mask pixels.

X missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

X acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Y: NPM1: Mean intensity
(a.u.); region definition: 核.

Y channel ID: npm1; declared stain: NPM1.

Y uses raw original-pixel intensity measurements.

Y missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Y acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Association scope: per-condition. X and Y were independently aggregated and matched by the same condition and independent-unit identity, never by observation order. Unmatched unexcluded units were rejected. Different retained region/field counts per axis remain in the ledgers.

Holm correction covers every declared association scope in family declared-association-scopes. The scatter contains one X/Y point per matched independent unit; no regression line or confidence band was estimated.

Untreated: Pearson correlation; statistic=0.54579183; p=0.63245787; Holm-adjusted p=0.63245787.

Resolved test settings: {"alternative": "two-sided", "inference_version": "1.0.0", "inferential_unit": "independent experimental unit", "null_hypothesis": "zero population Pearson correlation", "p_value_method": "exact beta null distribution under independent normal samples", "resamples": null, "scipy_version": "1.18.1", "seed": null, "selection": "explicit researcher choice; no normality pretest or p-based selection"}.

ActD 1 µM: Pearson correlation; statistic=-0.95873055; p=0.18353313; Holm-adjusted p=0.36706627.

Resolved test settings: {"alternative": "two-sided", "inference_version": "1.0.0", "inferential_unit": "independent experimental unit", "null_hypothesis": "zero population Pearson correlation", "p_value_method": "exact beta null distribution under independent normal samples", "resamples": null, "scipy_version": "1.18.1", "seed": null, "selection": "explicit researcher choice; no normality pretest or p-based selection"}.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: association_does_not_establish_causation_no_regression_or_batch_adjustment.
