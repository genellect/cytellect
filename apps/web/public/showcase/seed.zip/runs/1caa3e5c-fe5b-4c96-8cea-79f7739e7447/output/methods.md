# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: nucleolar_eccentricity; unit: dimensionless.
Region definition: nucleoplasm (region set ID nucleoplasm; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
The outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 149; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 152 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 3 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 0918cecf-fcc2-480a-a6fc-6c4449acb17d, 0dc45eed-4c45-427c-b653-69bf15854adf, 0fe56243-6366-48b6-a4b9-eb29f810f5f3, 101d584a-f5aa-42aa-811a-342d71e555c3, 1a574513-9ceb-448f-a889-469f87cdf8b5, 225f5980-0854-4318-a70b-76cd31272579, 3990f2f5-5a18-477c-a31e-686c429d367c, 3c32fadd-8e9c-4f8a-8e96-4972835bfe91, 3e2c7833-734a-40d2-9173-f4da004ebbc3, 46da09c0-211c-4157-af7b-44f4333cfd9b, 4b3f56f3-7143-4430-bca0-1fa1aad3d377, 6fbc1a06-aee0-457d-93f2-f3d7066b5c73, 72edb396-a0c1-4314-82e3-ee4f16739ebc, 73567d2b-ce89-4a6e-b3f8-29b3e3f1ce5f, 76dce44c-9e77-4674-be9e-c3e81a09e5ec, 86dc900c-4b5d-4914-aad4-199d9eb21a71, 9371f19d-494c-4748-8795-cf72d049db19, 942fb703-0321-4e64-89ba-22f4da8f422d, 962d4127-4e87-4cfd-9866-0094042b5fc2, 982ae3b7-90b5-4bee-bfad-b5141d166c16, a004a91f-1811-4f43-b4de-a955f29a7208, a65f81b9-6b3a-4f58-b7ed-a8458755af9e, a95d4fc5-2b4b-44af-bcee-30cb4afcb40a, b0a88abb-d63a-4245-8cd5-f46ca0f6c590, cb8a09b7-10bf-4a10-8425-3687b87ec6cf, ccaadb69-582c-4ddc-8543-26d9a7fc2236, d1ce8ce6-eca5-45dc-889f-420e8703ce27, d46989b4-0245-4695-a65a-6aeb84bd73d6, d64e3110-4cef-4c3e-a359-7ca65014a08c, e37ac93e-2c28-4ae0-96ad-3c9b215a4c52, ee8969b6-4008-4959-890f-ff6035a7c6e0, f16af30f-71f1-4fba-8553-36ea0defd4ab, f25c1d8d-0972-4d91-9075-458b501b5256, f4bda12e-b8d4-437f-9794-dc2d05ee569f, f8802403-c2e7-44e7-910f-e68e91d490c8, fdc4fbd8-1ca2-4ec3-ad60-a88d9bbd3e41) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established; missing_outcomes_excluded_inspect_fieldwise_missingness

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
Cisplatin 10 µM, Rep1 · Cisplatin 10 µM: 0 of 19 nuclei missing (0.0%); 0 explicitly excluded.
Cisplatin 10 µM, Rep2 · Cisplatin 10 µM: 0 of 24 nuclei missing (0.0%); 0 explicitly excluded.
Cisplatin 10 µM, Rep3 · Cisplatin 10 µM: 1 of 23 nuclei missing (4.3%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
