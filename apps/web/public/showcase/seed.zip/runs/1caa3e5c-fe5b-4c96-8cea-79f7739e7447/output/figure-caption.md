# Figure legend

Per-field descriptive measurements: nucleolar_eccentricity (dimensionless).
Per-nucleus compartment-summary value: area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0); per-field observed values.
Points are nuclei; horizontal lines show the median within each field.
149 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=152; explicitly excluded=0; outside saved selection=0; missing metric=3.
No manual mask edits are recorded; masks are the initial regions.
Points are placed side by side by a deterministic layout (display only); their colour shows the field's condition; values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=04199d88-504c-4588-aabc-f87023401d41; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=1b6e2aed-124e-4262-83d7-641ce405c580; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=43680cdc-d688-40d4-a617-da2e31b9f13f; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=45def878-bd3a-4012-b116-c57327f8cbc9; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=4bf55f47-4351-478a-9194-361aef360838; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=58516c35-6f16-40fe-b673-39c0b0ec7d92; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=8bc85b43-9828-4cdb-9e14-08423af2caee; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=8e019da5-bd48-4ee3-b415-078d6453ebb0; selected=18; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=9047a6bf-5c45-41a8-bf49-b895c402f056; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=a27ad184-37b1-4965-bace-346d26290190; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=a43fe457-da6f-4bca-986f-84861bc3d1a1; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=a4947e87-16e0-4cc9-94a2-f9cecb1f14e9; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=b24ff03e-9f2c-4ade-9494-9ec5410493f8; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=bd75903c-b53b-4e10-83b1-3e2798623e57; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=dba6850e-d21a-4d76-9830-f87799277209; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=dbe207ff-7410-415e-b2e7-8647d976413c; selected=12; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=e62e8bef-d114-4d0c-bf50-99f0dcbe7625; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=e6c7e28e-566d-4514-b130-874d807c54f0; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established
- missing_outcomes_excluded_inspect_fieldwise_missingness

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=04199d88-504c-4588-aabc-f87023401d41; Field 2: field_id=1b6e2aed-124e-4262-83d7-641ce405c580; Field 3: field_id=43680cdc-d688-40d4-a617-da2e31b9f13f; Field 4: field_id=45def878-bd3a-4012-b116-c57327f8cbc9; Field 5: field_id=4bf55f47-4351-478a-9194-361aef360838; Field 6: field_id=58516c35-6f16-40fe-b673-39c0b0ec7d92; Field 7: field_id=8bc85b43-9828-4cdb-9e14-08423af2caee; Field 8: field_id=8e019da5-bd48-4ee3-b415-078d6453ebb0
- Page 2: Field 9: field_id=9047a6bf-5c45-41a8-bf49-b895c402f056; Field 10: field_id=a27ad184-37b1-4965-bace-346d26290190; Field 11: field_id=a43fe457-da6f-4bca-986f-84861bc3d1a1; Field 12: field_id=a4947e87-16e0-4cc9-94a2-f9cecb1f14e9; Field 13: field_id=b24ff03e-9f2c-4ade-9494-9ec5410493f8; Field 14: field_id=bd75903c-b53b-4e10-83b1-3e2798623e57; Field 15: field_id=dba6850e-d21a-4d76-9830-f87799277209; Field 16: field_id=dbe207ff-7410-415e-b2e7-8647d976413c
- Page 3: Field 17: field_id=e62e8bef-d114-4d0c-bf50-99f0dcbe7625; Field 18: field_id=e6c7e28e-566d-4514-b130-874d807c54f0
