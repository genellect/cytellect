# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
106 selected observations are shown across all 1 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=106; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=21ef8d13-139a-4c80-88c4-af10f3757b77; selected=15; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 2: field_id=ab8403c9-beb2-4666-86b2-2a174cfc137b; selected=25; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 3: field_id=af49cf01-3f97-4db5-aa0a-b83adc9ece4a; selected=14; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 4: field_id=bb651eb5-2024-43af-861b-673ae309d7e9; selected=22; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 5: field_id=ee6019e1-be47-4ca4-baec-b1c0af7b94db; selected=20; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 6: field_id=f6804bb6-7eea-48d0-899a-31cc0e768a1f; selected=10; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=21ef8d13-139a-4c80-88c4-af10f3757b77; Field 2: field_id=ab8403c9-beb2-4666-86b2-2a174cfc137b; Field 3: field_id=af49cf01-3f97-4db5-aa0a-b83adc9ece4a; Field 4: field_id=bb651eb5-2024-43af-861b-673ae309d7e9; Field 5: field_id=ee6019e1-be47-4ca4-baec-b1c0af7b94db; Field 6: field_id=f6804bb6-7eea-48d0-899a-31cc0e768a1f
