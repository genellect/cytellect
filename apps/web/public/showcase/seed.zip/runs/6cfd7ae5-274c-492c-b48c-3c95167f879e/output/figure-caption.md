# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; horizontal lines show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Points are placed side by side by a deterministic layout (display only); their colour shows the field's condition; values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=0b646227-ea34-4d54-beea-04e7514fd2db; selected=332; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 2: field_id=20ea1a56-a162-4da9-9df9-9600e662c555; selected=45; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 3: field_id=3548da91-47bf-4ac1-b0e0-c59c6a7c5f6b; selected=376; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 4: field_id=35da5b46-7ffa-4ca3-8254-8175f8fb13c3; selected=56; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 5: field_id=5d1bfe59-5e7a-488a-9a5b-32cebf50aa80; selected=244; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 6: field_id=5fede1a8-4e55-471e-ac3d-ddcde6b05c20; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 7: field_id=72c5ced8-4562-4929-9152-affc01ba4f0d; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 8: field_id=796570c0-5f88-4998-8dec-de9cb4195ea3; selected=452; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 9: field_id=7f2df8aa-26ae-45e9-8614-7f4e240fcfba; selected=47; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 10: field_id=8738a884-78a3-43e7-a2b8-a3d97f215c37; selected=446; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 11: field_id=a4f3546d-3d7c-456a-8697-2a9bda62516c; selected=87; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 12: field_id=b0952ef6-66c0-48d3-b81d-25937a641915; selected=37; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 13: field_id=b85e058c-2928-4d82-be2a-a2b4afba6a3a; selected=643; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 14: field_id=bc486e99-3a41-4645-9bc8-dcc55e363052; selected=44; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 15: field_id=cdae1d5f-c66c-4008-b66e-ff7e79adf474; selected=471; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 16: field_id=f068b643-4dff-4c8c-947a-26b5cfb6fe94; selected=116; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 17: field_id=f0c7b8f9-77a6-4eb3-a6ad-26af5814290f; selected=295; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 18: field_id=f1f6cf43-a3b7-4a03-a0eb-5f1bf7a89593; selected=503; status=selected; definition=nuclei; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=0b646227-ea34-4d54-beea-04e7514fd2db; Field 2: field_id=20ea1a56-a162-4da9-9df9-9600e662c555; Field 3: field_id=3548da91-47bf-4ac1-b0e0-c59c6a7c5f6b; Field 4: field_id=35da5b46-7ffa-4ca3-8254-8175f8fb13c3; Field 5: field_id=5d1bfe59-5e7a-488a-9a5b-32cebf50aa80; Field 6: field_id=5fede1a8-4e55-471e-ac3d-ddcde6b05c20; Field 7: field_id=72c5ced8-4562-4929-9152-affc01ba4f0d; Field 8: field_id=796570c0-5f88-4998-8dec-de9cb4195ea3
- Page 2: Field 9: field_id=7f2df8aa-26ae-45e9-8614-7f4e240fcfba; Field 10: field_id=8738a884-78a3-43e7-a2b8-a3d97f215c37; Field 11: field_id=a4f3546d-3d7c-456a-8697-2a9bda62516c; Field 12: field_id=b0952ef6-66c0-48d3-b81d-25937a641915; Field 13: field_id=b85e058c-2928-4d82-be2a-a2b4afba6a3a; Field 14: field_id=bc486e99-3a41-4645-9bc8-dcc55e363052; Field 15: field_id=cdae1d5f-c66c-4008-b66e-ff7e79adf474; Field 16: field_id=f068b643-4dff-4c8c-947a-26b5cfb6fe94
- Page 3: Field 17: field_id=f0c7b8f9-77a6-4eb3-a6ad-26af5814290f; Field 18: field_id=f1f6cf43-a3b7-4a03-a0eb-5f1bf7a89593
