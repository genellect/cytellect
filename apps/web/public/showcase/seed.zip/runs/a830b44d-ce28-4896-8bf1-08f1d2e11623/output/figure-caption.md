# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=010270c6-fd72-4f04-97cb-afbfaa21e107; selected=17; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=068479b3-f414-4fa9-911f-38b2acedae50; selected=36; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=08f409ce-0f8a-420d-ab51-dac99807e3b5; selected=10; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=156b2ff2-48a3-46b0-a6e9-a25f3d46042d; selected=52; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=21099c3b-1787-46ff-b50a-ce0c89a023c8; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=35bf80c1-e775-4c7f-8bcb-da88c9f0f8f4; selected=13; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=398a2714-3aba-4c33-b5b9-43a15095c2e6; selected=22; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=52f9e52f-f538-499d-b308-642bdb487682; selected=83; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=660fd17b-f488-4a53-a2df-f456b2760243; selected=62; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=671d0181-8952-4915-bd02-436d4d277dd1; selected=32; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=776c364c-bb6e-40c0-9574-e0586e2368ac; selected=31; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=a0afa333-ec2e-4859-b80b-06a5bf018ddb; selected=33; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=b30507fc-5417-4380-9aba-26f57eefa745; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=cbac68b0-6577-442c-ad81-01806737f8eb; selected=15; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=d069f51c-4f2c-43a1-9402-e2912078e669; selected=19; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=db242881-beda-499c-bc99-42b6fa29c452; selected=37; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=e54560f5-e582-46e1-9ed2-bcb686e15a71; selected=12; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=f3f0749c-97b2-4d1a-b17e-da70585ddf56; selected=78; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=010270c6-fd72-4f04-97cb-afbfaa21e107; Field 2: field_id=068479b3-f414-4fa9-911f-38b2acedae50; Field 3: field_id=08f409ce-0f8a-420d-ab51-dac99807e3b5; Field 4: field_id=156b2ff2-48a3-46b0-a6e9-a25f3d46042d; Field 5: field_id=21099c3b-1787-46ff-b50a-ce0c89a023c8; Field 6: field_id=35bf80c1-e775-4c7f-8bcb-da88c9f0f8f4; Field 7: field_id=398a2714-3aba-4c33-b5b9-43a15095c2e6; Field 8: field_id=52f9e52f-f538-499d-b308-642bdb487682
- Page 2: Field 9: field_id=660fd17b-f488-4a53-a2df-f456b2760243; Field 10: field_id=671d0181-8952-4915-bd02-436d4d277dd1; Field 11: field_id=776c364c-bb6e-40c0-9574-e0586e2368ac; Field 12: field_id=a0afa333-ec2e-4859-b80b-06a5bf018ddb; Field 13: field_id=b30507fc-5417-4380-9aba-26f57eefa745; Field 14: field_id=cbac68b0-6577-442c-ad81-01806737f8eb; Field 15: field_id=d069f51c-4f2c-43a1-9402-e2912078e669; Field 16: field_id=db242881-beda-499c-bc99-42b6fa29c452
- Page 3: Field 17: field_id=e54560f5-e582-46e1-9ed2-bcb686e15a71; Field 18: field_id=f3f0749c-97b2-4d1a-b17e-da70585ddf56
