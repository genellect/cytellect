# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: mean; unit: a.u..
Region definition: nucleoli (region set ID nucleoli; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measured channel: 5-EU; stain: 5-EU; recorded channel ID: eu5.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
Each region outcome is the arithmetic mean of (I) over its measured pixels.
The selected raw outcome does not subtract background.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 588; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 588 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 0 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 00ab5072-d634-433b-85ff-6e29c43cc80a, 21ccb219-a066-4518-b2dd-900c8cc9c493, 313184ca-0d35-4ddb-93ec-e9e22e32efb7, 457b914a-d49d-46da-925d-9ba8bbb8b174, 4aa6a8b8-0826-43b9-9e29-83dbdd599fb6, 54149745-c3cf-43b2-a9e1-3e53b1cb7b90, 6a794bd7-d58c-448f-92ab-f3d6525cf758, 6ae333aa-43b5-4d74-b551-863ed91950c7, 78e11854-4e1f-43a4-852d-185fb3b51f72, 87e95fed-8262-4ffc-bd81-817656e13563, 924cde34-5448-4fb4-9d08-84854e5f71e3, b602cb00-6472-4c6f-901f-a14aed9cc7da, c0c09c88-9f9a-4efb-a8c9-1ca68e412094, ccaf1e51-03b7-40e2-9682-2dced81533b8, d32ba635-b04f-42a2-87e1-778057861de1, d7162912-4bbb-4654-9c11-62461ce407f9, f4973b9c-6548-44d5-84ea-4be265b78d06, ff3cef82-7dd8-4899-97d2-03d43e44cca2) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
