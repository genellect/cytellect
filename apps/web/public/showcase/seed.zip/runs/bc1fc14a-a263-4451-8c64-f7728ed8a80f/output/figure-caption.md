# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=11f0bec4-959c-46aa-8155-0837a8d4bb2c; selected=83; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=1e313503-c64c-4d4a-bf2c-320ba98489b2; selected=37; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2b13bc99-fa8b-4980-8940-0e5e6d99ffb1; selected=52; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=3a3bcc30-3c54-4728-b197-c76b0d3fc017; selected=15; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=3d5e9bbd-9e36-4ff0-a4fe-d4d4806a0de3; selected=32; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=4d072085-e54b-48cd-84d7-502d38fe18e4; selected=10; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=537e996c-5b62-40e8-a7df-2430cb76e3d3; selected=31; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=596a0fb8-eca7-427c-82e1-1c099059dda9; selected=13; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=5f910b51-1ea5-4685-bf08-e0ef662dc233; selected=36; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=711aeb10-d7af-4e21-a774-c060737ee8de; selected=19; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=73160e0d-c663-4807-9f6e-ba4c581a2505; selected=78; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=7ffbde22-1b8f-4e61-a598-6e4f5338bc22; selected=12; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=995867e0-aa03-4554-876c-87ccdc694a2f; selected=22; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=a2b82a64-43a9-4ed8-a43e-1665fb0b47e0; selected=62; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=a5c4c117-e999-4adf-ade5-6f5edf26ae0e; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=a8b306d4-e1b1-4a6b-8c90-96311f0c9948; selected=17; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=c398d4b1-3efe-4535-9ab0-6778e2e8efda; selected=33; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=f96f8dee-1a03-440a-b75e-43e51b1a003b; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=11f0bec4-959c-46aa-8155-0837a8d4bb2c; Field 2: field_id=1e313503-c64c-4d4a-bf2c-320ba98489b2; Field 3: field_id=2b13bc99-fa8b-4980-8940-0e5e6d99ffb1; Field 4: field_id=3a3bcc30-3c54-4728-b197-c76b0d3fc017; Field 5: field_id=3d5e9bbd-9e36-4ff0-a4fe-d4d4806a0de3; Field 6: field_id=4d072085-e54b-48cd-84d7-502d38fe18e4; Field 7: field_id=537e996c-5b62-40e8-a7df-2430cb76e3d3; Field 8: field_id=596a0fb8-eca7-427c-82e1-1c099059dda9
- Page 2: Field 9: field_id=5f910b51-1ea5-4685-bf08-e0ef662dc233; Field 10: field_id=711aeb10-d7af-4e21-a774-c060737ee8de; Field 11: field_id=73160e0d-c663-4807-9f6e-ba4c581a2505; Field 12: field_id=7ffbde22-1b8f-4e61-a598-6e4f5338bc22; Field 13: field_id=995867e0-aa03-4554-876c-87ccdc694a2f; Field 14: field_id=a2b82a64-43a9-4ed8-a43e-1665fb0b47e0; Field 15: field_id=a5c4c117-e999-4adf-ade5-6f5edf26ae0e; Field 16: field_id=a8b306d4-e1b1-4a6b-8c90-96311f0c9948
- Page 3: Field 17: field_id=c398d4b1-3efe-4535-9ab0-6778e2e8efda; Field 18: field_id=f96f8dee-1a03-440a-b75e-43e51b1a003b
