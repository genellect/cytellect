# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=01e8e264-17d6-4ba3-a75f-f1dc52ae70dd; selected=376; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 2: field_id=36266644-3049-49f2-93f5-2f94e0cd3bec; selected=503; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 3: field_id=475ceb38-ec38-43a4-80e8-5ece3600fd92; selected=56; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 4: field_id=595a4091-4a0d-4e0a-9bc1-95926d243e79; selected=45; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 5: field_id=5c1a2f45-cada-4193-9e7b-21fc4070247c; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 6: field_id=77fce37b-1739-46a2-ac57-25ffe8dc68bb; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 7: field_id=7a6dd3c7-9f26-49b3-a0e5-5f54bf14a987; selected=87; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 8: field_id=7b318479-3c8a-4871-aebf-38b2ddf9f547; selected=47; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 9: field_id=848836a1-fcc0-4247-b367-11182f137a2c; selected=44; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 10: field_id=ab883147-17d0-4c5e-b9e5-558615a8c7ff; selected=332; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 11: field_id=acbd4b91-5a6c-4fd2-a037-cad0258fe8f7; selected=116; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 12: field_id=b6b219c2-87a6-4982-8890-3f54d006c6e9; selected=446; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 13: field_id=b6f67b3a-29c5-4bbc-8363-2ea7961b1ede; selected=471; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 14: field_id=dad5aa3f-fa69-4664-9398-a90012f049ce; selected=643; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 15: field_id=dd24cbc9-dc92-4354-a90c-0d874ca02b25; selected=244; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 16: field_id=e61ec35e-f61d-4063-b093-237b48f2030c; selected=37; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 17: field_id=ebcfe0a1-75db-43a3-b6d6-b1571fbbc6a3; selected=295; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 18: field_id=eeca1fd1-0c6a-446e-b14a-e238e702da31; selected=452; status=selected; definition=核; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=01e8e264-17d6-4ba3-a75f-f1dc52ae70dd; Field 2: field_id=36266644-3049-49f2-93f5-2f94e0cd3bec; Field 3: field_id=475ceb38-ec38-43a4-80e8-5ece3600fd92; Field 4: field_id=595a4091-4a0d-4e0a-9bc1-95926d243e79; Field 5: field_id=5c1a2f45-cada-4193-9e7b-21fc4070247c; Field 6: field_id=77fce37b-1739-46a2-ac57-25ffe8dc68bb; Field 7: field_id=7a6dd3c7-9f26-49b3-a0e5-5f54bf14a987; Field 8: field_id=7b318479-3c8a-4871-aebf-38b2ddf9f547
- Page 2: Field 9: field_id=848836a1-fcc0-4247-b367-11182f137a2c; Field 10: field_id=ab883147-17d0-4c5e-b9e5-558615a8c7ff; Field 11: field_id=acbd4b91-5a6c-4fd2-a037-cad0258fe8f7; Field 12: field_id=b6b219c2-87a6-4982-8890-3f54d006c6e9; Field 13: field_id=b6f67b3a-29c5-4bbc-8363-2ea7961b1ede; Field 14: field_id=dad5aa3f-fa69-4664-9398-a90012f049ce; Field 15: field_id=dd24cbc9-dc92-4354-a90c-0d874ca02b25; Field 16: field_id=e61ec35e-f61d-4063-b093-237b48f2030c
- Page 3: Field 17: field_id=ebcfe0a1-75db-43a3-b6d6-b1571fbbc6a3; Field 18: field_id=eeca1fd1-0c6a-446e-b14a-e238e702da31
