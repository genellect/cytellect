# Figure legend

Per-field descriptive measurements: nucleolar_eccentricity (dimensionless).
Per-nucleus compartment-summary value: area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0); per-field observed values.
Points are nuclei; horizontal lines show the median within each field.
149 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=151; explicitly excluded=0; outside saved selection=0; missing metric=2.
No manual mask edits are recorded; masks are the initial regions.
Points are placed side by side by a deterministic layout (display only); their colour shows the field's condition; values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=00637450-3528-4587-a2f0-ef2012e7c5fe; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=0c96f7e8-db8a-494d-8631-62498e77219d; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=0e2f9e4c-a304-4e8a-8def-dd03bea9a1b1; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=19a077ea-dddc-454f-a3c2-808676ab62af; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=2426ad54-99c9-47bc-8b82-b8177dda5ba4; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=2bac9136-e8d6-401e-88e5-acf4b7ef8dca; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=354a02f0-21f6-4d10-9501-5f336e5f80fd; selected=12; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=44202918-e88c-493b-aa58-daf47fc8f9fb; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=693fe6e7-3451-4e46-94fd-7f55c8640aa0; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=6b9b2460-62f3-4b0c-8f52-2429685c4a36; selected=18; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=75b7c87e-b4c4-470b-832a-4b982a6fe0b3; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=877526e6-8d20-4750-8f06-7f97641dfd8b; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=87e21991-e6b3-4dac-9f22-5a1716cbd4d1; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=899affb4-fd3a-4d3c-b984-281c9cdb6f93; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=9bfc3091-a889-4909-8719-bf17c487c7ee; selected=3; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=c1c457c2-c943-4ea5-bb37-d1edb975c691; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=d16e6e4b-6e88-4467-864f-40f0e08dabe8; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=d1a345ed-213b-4b98-995d-0e5f9720ee68; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established
- missing_outcomes_excluded_inspect_fieldwise_missingness

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=00637450-3528-4587-a2f0-ef2012e7c5fe; Field 2: field_id=0c96f7e8-db8a-494d-8631-62498e77219d; Field 3: field_id=0e2f9e4c-a304-4e8a-8def-dd03bea9a1b1; Field 4: field_id=19a077ea-dddc-454f-a3c2-808676ab62af; Field 5: field_id=2426ad54-99c9-47bc-8b82-b8177dda5ba4; Field 6: field_id=2bac9136-e8d6-401e-88e5-acf4b7ef8dca; Field 7: field_id=354a02f0-21f6-4d10-9501-5f336e5f80fd; Field 8: field_id=44202918-e88c-493b-aa58-daf47fc8f9fb
- Page 2: Field 9: field_id=693fe6e7-3451-4e46-94fd-7f55c8640aa0; Field 10: field_id=6b9b2460-62f3-4b0c-8f52-2429685c4a36; Field 11: field_id=75b7c87e-b4c4-470b-832a-4b982a6fe0b3; Field 12: field_id=877526e6-8d20-4750-8f06-7f97641dfd8b; Field 13: field_id=87e21991-e6b3-4dac-9f22-5a1716cbd4d1; Field 14: field_id=899affb4-fd3a-4d3c-b984-281c9cdb6f93; Field 15: field_id=9bfc3091-a889-4909-8719-bf17c487c7ee; Field 16: field_id=c1c457c2-c943-4ea5-bb37-d1edb975c691
- Page 3: Field 17: field_id=d16e6e4b-6e88-4467-864f-40f0e08dabe8; Field 18: field_id=d1a345ed-213b-4b98-995d-0e5f9720ee68
