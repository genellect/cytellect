# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: nucleolar_eccentricity; unit: dimensionless.
Region definition: nucleoplasm (region set ID nucleoplasm; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
The outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 149; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 151 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 2 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 09befacc-429f-461b-87d2-efc7c0c28275, 107666e3-5ab6-40bf-bd9a-770cb6a0e71f, 12bdee76-4d50-4ddb-a78b-742934169067, 137719b4-1f0f-4d54-af26-5deaf68d7f59, 16188e40-4ee3-4401-b97e-72ef4bdd3ab0, 1e9d8889-b582-4bd6-a094-59c4e7cf7754, 20a11174-cf14-46d9-892b-66ec0e296ea0, 20f95b45-103c-43aa-a874-bd50a61c59d4, 252659d6-d9e0-430c-8231-f6906c144da4, 2b2cdfcd-711f-400c-af2d-2cc525752d19, 360f0834-a0d7-427d-93fa-96fb9882277c, 4a434668-7d59-48cc-a449-ae3e46e93ac5, 514ef11e-6259-4c98-8230-06f49e9023d3, 517e6ea6-fef2-4000-a59a-db1cd9ec52ca, 58252ee6-9db4-472b-bdbe-1e214521311c, 5997e1df-56f5-4942-9650-345e7997c131, 6114c39e-fc45-4f4b-9908-f51bdc2996b4, 6323a1aa-0a81-4f02-a873-0c6201c3a0d1, 65449d85-8e24-48da-8060-f3f54fc41435, 7b7c23fd-2072-4223-bf08-d0de784e4a34, 8e09ee00-d9e3-4076-a7f1-8953dd48b12f, 95514bcf-389f-4cd0-80b3-bc4771dfd932, 95a463e6-5d65-427d-88cc-2607561a2345, 969dee57-155c-4636-9d8f-f02566b009b5, 9ca10f46-2efd-4e60-b351-43ad04548570, 9df453a5-b70f-45de-8b6d-b5990937c181, a518d788-6713-4f95-82d1-25e199fa8f1c, a6602587-2f64-481a-bea0-d050733a94b6, a71d746c-19a7-4c34-944d-3e57719d61bd, a9eefba6-d352-4860-9f2e-31b34fe50459, b303e10c-4227-40f2-94b6-dda10cf35e82, b4f577ad-b2c0-4f45-9f3b-902b9eaf6528, c45d61b2-0ad8-408f-8073-6195e7b8d605, cf483b7c-490e-4a2c-9120-087032dad9ae, d9ee26df-b28f-4756-bbc8-6c437adb07f8, f0bbf76f-d4c3-4dc9-aad1-20eed3c45238) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established; missing_outcomes_excluded_inspect_fieldwise_missingness

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
Oxaliplatin 10 µM, Rep1 · Oxaliplatin 10 µM: 0 of 25 nuclei missing (0.0%); 0 explicitly excluded.
Oxaliplatin 10 µM, Rep2 · Oxaliplatin 10 µM: 0 of 17 nuclei missing (0.0%); 0 explicitly excluded.
Oxaliplatin 10 µM, Rep3 · Oxaliplatin 10 µM: 0 of 23 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
