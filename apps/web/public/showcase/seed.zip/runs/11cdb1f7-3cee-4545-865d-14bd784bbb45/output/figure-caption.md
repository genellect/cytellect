# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=39c4bc4f-9e09-43f9-9494-e4e855dd1145; selected=87; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 2: field_id=39c89b08-c4b1-41e7-9daf-7f0f4293bd9a; selected=452; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 3: field_id=42fa6708-b506-4ee3-976a-622578d994ba; selected=332; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 4: field_id=5a203d19-4a60-4f00-a315-d675714dee28; selected=47; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 5: field_id=679a7f0f-f26e-4fbb-803d-4861be6fbb9a; selected=446; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 6: field_id=6d2926ec-b937-4a43-9639-ea1b9f15ec16; selected=471; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 7: field_id=a9513926-460c-4314-a346-6134bb963962; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 8: field_id=aa2bfbb4-35aa-46dc-93bf-a257cb4f79a3; selected=376; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 9: field_id=b0af82db-80ba-4fe5-90b2-d8e75765c955; selected=295; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 10: field_id=c27a556f-5810-4edf-a693-1cdfd8925220; selected=244; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 11: field_id=c2e0ae38-5bdf-4082-b081-d91bdb8da867; selected=56; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 12: field_id=c6be85d6-8cba-40f1-a521-5f7ae40b586a; selected=643; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 13: field_id=d762e979-b6e7-4beb-8859-a3ebcc967841; selected=37; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 14: field_id=e252f950-0cfb-49e3-9534-ebdd4958ab31; selected=503; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 15: field_id=e261b2fa-71c0-4ae0-8a6a-e5b5410791e5; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 16: field_id=eb77eb09-d4c9-4017-8955-6e2bd82c9e32; selected=116; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 17: field_id=ec5519b3-4224-4c1a-ae3d-dc7b260fdf9c; selected=45; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 18: field_id=f01fcdc6-718b-4330-bc5b-3823b92b1353; selected=44; status=selected; definition=nuclei; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=39c4bc4f-9e09-43f9-9494-e4e855dd1145; Field 2: field_id=39c89b08-c4b1-41e7-9daf-7f0f4293bd9a; Field 3: field_id=42fa6708-b506-4ee3-976a-622578d994ba; Field 4: field_id=5a203d19-4a60-4f00-a315-d675714dee28; Field 5: field_id=679a7f0f-f26e-4fbb-803d-4861be6fbb9a; Field 6: field_id=6d2926ec-b937-4a43-9639-ea1b9f15ec16; Field 7: field_id=a9513926-460c-4314-a346-6134bb963962; Field 8: field_id=aa2bfbb4-35aa-46dc-93bf-a257cb4f79a3
- Page 2: Field 9: field_id=b0af82db-80ba-4fe5-90b2-d8e75765c955; Field 10: field_id=c27a556f-5810-4edf-a693-1cdfd8925220; Field 11: field_id=c2e0ae38-5bdf-4082-b081-d91bdb8da867; Field 12: field_id=c6be85d6-8cba-40f1-a521-5f7ae40b586a; Field 13: field_id=d762e979-b6e7-4beb-8859-a3ebcc967841; Field 14: field_id=e252f950-0cfb-49e3-9534-ebdd4958ab31; Field 15: field_id=e261b2fa-71c0-4ae0-8a6a-e5b5410791e5; Field 16: field_id=eb77eb09-d4c9-4017-8955-6e2bd82c9e32
- Page 3: Field 17: field_id=ec5519b3-4224-4c1a-ae3d-dc7b260fdf9c; Field 18: field_id=f01fcdc6-718b-4330-bc5b-3823b92b1353
