# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: area_px; unit: pixel².
Region definition: nuclei (region set ID nuclei; regions from StarDist nuclear segmentation; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
Area is the number of original-coordinate mask pixels; calibrated area multiplies this count by the recorded X and Y pixel sizes (or the square of the scalar pixel size in nuclear recipes). Unknown calibration is missing, never zero. Repeated channel rows do not increase region counts.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 4432; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 4432 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 0 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (StarDist nuclear candidates).
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
