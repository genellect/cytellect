# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=0a6495c3-bd14-4365-aeb5-daab81b8f852; selected=503; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 2: field_id=1f133026-6b9a-4950-bdae-3b296d0a84e7; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 3: field_id=35c75aae-b014-4ece-8f2b-225fd4b35add; selected=116; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 4: field_id=3a12a11e-1932-4e1a-9c72-f83d423752dd; selected=45; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 5: field_id=5994d8b5-5ba1-4e13-9b76-9ddbae584fc3; selected=376; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 6: field_id=5ec53056-c58a-4d77-bc66-24a0cc1b3db7; selected=471; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 7: field_id=7bedfea3-1229-41c7-976f-07a5033ca2ca; selected=643; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 8: field_id=92bdab9c-9ca2-49d7-9843-829d756ac87c; selected=44; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 9: field_id=975ff1ff-c92c-49de-9f1d-d718637648ed; selected=56; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 10: field_id=b017dc5f-33e7-4276-b925-671d5eeb0076; selected=87; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 11: field_id=d10649ac-f7eb-40bb-bf25-8235d741b958; selected=47; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 12: field_id=d19e50d0-e914-4c88-9770-b99d812fb238; selected=446; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 13: field_id=d763c60b-8121-4f75-b126-50623f5702f4; selected=244; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 14: field_id=d8644554-b0b6-424d-a191-5c258977ea2d; selected=452; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 15: field_id=d9c0f8c7-09ab-48ab-85be-eac4079dff2c; selected=295; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 16: field_id=e2ae72ae-072c-44de-b167-7292fb243f00; selected=37; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 17: field_id=e9009acb-ce30-4ec7-8fc6-cc4fc7486fe6; selected=332; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 18: field_id=e9ce0793-a33a-4f97-8538-fa581ef0837a; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=0a6495c3-bd14-4365-aeb5-daab81b8f852; Field 2: field_id=1f133026-6b9a-4950-bdae-3b296d0a84e7; Field 3: field_id=35c75aae-b014-4ece-8f2b-225fd4b35add; Field 4: field_id=3a12a11e-1932-4e1a-9c72-f83d423752dd; Field 5: field_id=5994d8b5-5ba1-4e13-9b76-9ddbae584fc3; Field 6: field_id=5ec53056-c58a-4d77-bc66-24a0cc1b3db7; Field 7: field_id=7bedfea3-1229-41c7-976f-07a5033ca2ca; Field 8: field_id=92bdab9c-9ca2-49d7-9843-829d756ac87c
- Page 2: Field 9: field_id=975ff1ff-c92c-49de-9f1d-d718637648ed; Field 10: field_id=b017dc5f-33e7-4276-b925-671d5eeb0076; Field 11: field_id=d10649ac-f7eb-40bb-bf25-8235d741b958; Field 12: field_id=d19e50d0-e914-4c88-9770-b99d812fb238; Field 13: field_id=d763c60b-8121-4f75-b126-50623f5702f4; Field 14: field_id=d8644554-b0b6-424d-a191-5c258977ea2d; Field 15: field_id=d9c0f8c7-09ab-48ab-85be-eac4079dff2c; Field 16: field_id=e2ae72ae-072c-44de-b167-7292fb243f00
- Page 3: Field 17: field_id=e9009acb-ce30-4ec7-8fc6-cc4fc7486fe6; Field 18: field_id=e9ce0793-a33a-4f97-8538-fa581ef0837a
