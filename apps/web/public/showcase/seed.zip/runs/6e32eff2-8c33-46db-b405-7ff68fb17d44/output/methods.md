# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: aaa9d3e2-7039-4857-a976-d4a21647cbe9; fingerprint: a0d7d3f5404cfde156b953629e97fe5d40ce6480bb08bf54b51ff3e2b9a8842e.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 反復（Rep1–Rep3。独立性は出典で確認できない）; the researcher had not confirmed that these units were independent.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each recorded experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: Nucleolar eccentricity
(dimensionless); region definition: 核質.

Outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と ActD. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): ActD 1 µM minus Untreated; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=0.82709153, ActD 1 µM=0.51922447, difference=-0.30786706.

Run Rep2: Untreated=0.75199847, ActD 1 µM=0.38424543, difference=-0.36775304.

Run Rep3: Untreated=0.7316373, ActD 1 µM=0.57791175, difference=-0.15372555.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
