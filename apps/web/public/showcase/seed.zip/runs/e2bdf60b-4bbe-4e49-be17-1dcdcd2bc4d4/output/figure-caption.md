# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=14d44ff8-cfb5-4755-b225-39628b6d7310; selected=87; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 2: field_id=2dc3ae40-c34a-42e1-abec-45c133c4e2e1; selected=45; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 3: field_id=39b9e76b-eeba-46e0-b747-dda6420041a1; selected=332; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 4: field_id=6d16ea30-f65b-48d9-9235-f41b6d965ca7; selected=503; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 5: field_id=6f2213c3-f159-45dc-8e01-7842f1087d9c; selected=643; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 6: field_id=7f0717f2-c3d9-4292-9bc8-1820910443ea; selected=244; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 7: field_id=7fe4246d-a860-4931-b90f-4170b48c87d8; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 8: field_id=811ca752-33dc-49ec-9b9e-79d8c0464c9e; selected=471; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 9: field_id=8a9288a9-345a-48fe-98d9-bbaedaefc14e; selected=56; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 10: field_id=92b7da22-0544-485f-aa81-e558bb79db04; selected=44; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 11: field_id=9a225c69-f02b-4658-a81f-0a0be7a92c7a; selected=295; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 12: field_id=9a678606-5f6b-4084-bb5f-e6fe1b3463cc; selected=37; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 13: field_id=a42094bc-b82e-4558-a200-b5bf26926f4e; selected=446; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 14: field_id=c64249e3-e34a-46a4-af43-69c29cf810f4; selected=376; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 15: field_id=cd2620fe-fa8e-41c7-b987-ea6df60b514b; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 16: field_id=e37972c2-d97a-489a-a506-88811cf5ff24; selected=47; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 17: field_id=e7d62a84-52b7-43de-be4e-60ab9d183cb6; selected=452; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 18: field_id=fbba8b6e-1963-4d2a-83c6-ff56adc302af; selected=116; status=selected; definition=核; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=14d44ff8-cfb5-4755-b225-39628b6d7310; Field 2: field_id=2dc3ae40-c34a-42e1-abec-45c133c4e2e1; Field 3: field_id=39b9e76b-eeba-46e0-b747-dda6420041a1; Field 4: field_id=6d16ea30-f65b-48d9-9235-f41b6d965ca7; Field 5: field_id=6f2213c3-f159-45dc-8e01-7842f1087d9c; Field 6: field_id=7f0717f2-c3d9-4292-9bc8-1820910443ea; Field 7: field_id=7fe4246d-a860-4931-b90f-4170b48c87d8; Field 8: field_id=811ca752-33dc-49ec-9b9e-79d8c0464c9e
- Page 2: Field 9: field_id=8a9288a9-345a-48fe-98d9-bbaedaefc14e; Field 10: field_id=92b7da22-0544-485f-aa81-e558bb79db04; Field 11: field_id=9a225c69-f02b-4658-a81f-0a0be7a92c7a; Field 12: field_id=9a678606-5f6b-4084-bb5f-e6fe1b3463cc; Field 13: field_id=a42094bc-b82e-4558-a200-b5bf26926f4e; Field 14: field_id=c64249e3-e34a-46a4-af43-69c29cf810f4; Field 15: field_id=cd2620fe-fa8e-41c7-b987-ea6df60b514b; Field 16: field_id=e37972c2-d97a-489a-a506-88811cf5ff24
- Page 3: Field 17: field_id=e7d62a84-52b7-43de-be4e-60ab9d183cb6; Field 18: field_id=fbba8b6e-1963-4d2a-83c6-ff56adc302af
