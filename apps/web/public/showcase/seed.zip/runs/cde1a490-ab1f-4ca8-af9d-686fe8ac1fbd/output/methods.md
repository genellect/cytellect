# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: nucleolar_eccentricity; unit: dimensionless.
Region definition: nucleoplasm (region set ID nucleoplasm; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
The outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 149; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 151 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 2 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 00217b3a-8946-4b44-818f-b8b9502c6292, 0206fc70-002a-47ae-ad9b-442d741e5340, 049fe79c-88c1-4f1e-83c3-85f9ec6c3730, 09ff4900-6ee8-4c63-902c-7f230f0c4d76, 1249ecb6-8088-4ded-8009-ba399625a376, 194ed891-48ab-40f2-8ee3-6650beb8fe9e, 1f7e5504-4881-4ecc-8223-0c9619a152a5, 202a8fdd-ec0a-47c5-8c98-4808a3b9bbf0, 218f96fc-d5d4-420c-ae61-68afdf30781c, 286e8d2d-c105-47cc-8fdd-01ba07768324, 2caea280-c8b7-4431-b7b6-dadd3b7e67ec, 32229cc6-f6b8-4765-adc6-9ae78f1489ab, 3aaf9639-c43f-4158-a871-999fa60f28b9, 40315c5d-30e9-468f-ab59-ad88d7fa822e, 46c5c2d6-16d9-45b0-9f9e-b6276712687d, 47af029e-2160-4025-be99-ead4d73f568d, 4c46c67a-e438-49a5-8ae7-f9118b41f962, 51c1d26e-27c7-4104-8682-3c9d589799a7, 61d0c73b-b073-40c7-a1b2-dbb8c93521ff, 66463ca4-f353-4b9b-ba34-c7d6e24d406e, 6c63a6c7-3efe-494c-a194-a4919e4b3612, 8b544776-6727-4633-9fcc-e5ad031ba38d, 8f5e9da5-c7fc-40af-930c-ba635df5b1f4, 9aebdf6b-fb89-4cfc-bd5f-53294ff9a973, 9b5319ed-d7a5-4114-902a-1e53ee930ddb, a71cdbd0-8c8e-48c3-92bf-638e2dd2f520, aa3e9746-d712-4703-a01b-e1b597fbdc93, b9e91bb0-63b0-4c87-bdbe-5f9f9a4984f4, c1496fcc-3a21-4818-8472-6115f7f41c1d, c4e259b0-40a4-4170-8907-4d07627f3007, c65e7b85-accf-4304-8f36-ffbbf3a32792, d65493df-459d-4d33-8e70-8a772734942c, d963a124-cb30-484b-ad9e-1cb9433a5d67, ebd8b908-606f-42e3-8e55-8766bad8fe1c, ed7fc849-b765-4076-bb5c-47dcd8909591, f07f21d2-2de6-42f2-b5ee-08ef0ff2de1c) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established; missing_outcomes_excluded_inspect_fieldwise_missingness

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
Oxaliplatin 10 µM, Rep1 · Oxaliplatin 10 µM: 0 of 25 nuclei missing (0.0%); 0 explicitly excluded.
Oxaliplatin 10 µM, Rep2 · Oxaliplatin 10 µM: 0 of 17 nuclei missing (0.0%); 0 explicitly excluded.
Oxaliplatin 10 µM, Rep3 · Oxaliplatin 10 µM: 0 of 23 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
