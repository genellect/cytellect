# Figure legend

Per-field descriptive measurements: nucleolar_eccentricity (dimensionless).
Per-nucleus compartment-summary value: area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0); per-field observed values.
Points are nuclei; squares show the median within each field.
149 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=151; explicitly excluded=0; outside saved selection=0; missing metric=2.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=0da89c92-ccf4-4c6f-89be-d175ce8e2927; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=1be013ca-9655-4f98-958f-b1ac59283c13; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2ce6c281-8b80-4d6f-b2d5-086289596f5f; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=3ac9ab2a-3ad9-4615-985f-10bd7b350fc7; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=47048619-be67-473a-995c-d14def55ae1d; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=50f1f6a8-13a6-4f51-aa88-387640640220; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=5d1216eb-21c2-47f1-a499-06b99d026be3; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=72a2580d-cf1a-4a3d-8782-b55865d129d6; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=815a2113-9438-44fd-9834-5d362d90fa97; selected=3; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=85a74c75-5316-4473-980d-68746a6e0da6; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=8fe05958-fba5-465b-a115-7f6c873b7b87; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=9077be71-bf75-4ad2-aa12-45b5f1d6c17b; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=9a0b79e7-2d7a-465b-9a98-9323e2a6da6d; selected=12; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=a2365d34-e138-497c-b500-0c294fde70dd; selected=18; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=a36c6035-4853-4e7c-87e4-c10f8a2ca4ce; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=b834132e-acbd-45b4-ac51-d9dd366f93a4; selected=8; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=bdd813f2-8064-47b0-9343-b9784fc7b7d3; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fe70c661-9710-455d-9b96-085a9f3b98cd; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established
- missing_outcomes_excluded_inspect_fieldwise_missingness

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=0da89c92-ccf4-4c6f-89be-d175ce8e2927; Field 2: field_id=1be013ca-9655-4f98-958f-b1ac59283c13; Field 3: field_id=2ce6c281-8b80-4d6f-b2d5-086289596f5f; Field 4: field_id=3ac9ab2a-3ad9-4615-985f-10bd7b350fc7; Field 5: field_id=47048619-be67-473a-995c-d14def55ae1d; Field 6: field_id=50f1f6a8-13a6-4f51-aa88-387640640220; Field 7: field_id=5d1216eb-21c2-47f1-a499-06b99d026be3; Field 8: field_id=72a2580d-cf1a-4a3d-8782-b55865d129d6
- Page 2: Field 9: field_id=815a2113-9438-44fd-9834-5d362d90fa97; Field 10: field_id=85a74c75-5316-4473-980d-68746a6e0da6; Field 11: field_id=8fe05958-fba5-465b-a115-7f6c873b7b87; Field 12: field_id=9077be71-bf75-4ad2-aa12-45b5f1d6c17b; Field 13: field_id=9a0b79e7-2d7a-465b-9a98-9323e2a6da6d; Field 14: field_id=a2365d34-e138-497c-b500-0c294fde70dd; Field 15: field_id=a36c6035-4853-4e7c-87e4-c10f8a2ca4ce; Field 16: field_id=b834132e-acbd-45b4-ac51-d9dd366f93a4
- Page 3: Field 17: field_id=bdd813f2-8064-47b0-9343-b9784fc7b7d3; Field 18: field_id=fe70c661-9710-455d-9b96-085a9f3b98cd
