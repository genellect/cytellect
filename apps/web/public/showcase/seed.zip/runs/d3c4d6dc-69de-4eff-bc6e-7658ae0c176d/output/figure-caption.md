# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; horizontal lines show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Points are placed side by side by a deterministic layout (display only); their colour shows the field's condition; values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=00dbf895-c995-40b8-a5af-8c61cb282d51; selected=33; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=13e46b30-43e6-45df-8ac3-8beae8b05b81; selected=31; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=16e19931-e74e-418e-9591-cd6e58c215c8; selected=37; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=23af73b5-595d-418f-9d88-c8365e0835fc; selected=12; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=3980a172-c3ec-4696-af35-95344d772a5f; selected=52; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=59a06349-80c7-43ea-b875-8d4bd65d91fc; selected=62; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=641007d5-2714-4f51-8fee-7360b1066dd0; selected=32; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=83afb02f-3cd8-4ccb-8ba4-cbb8ac8d68ee; selected=19; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=8ab2ef48-d1f5-42ef-b899-60c3f6cb5d1d; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=9b5ee5a8-8329-4788-b3c7-14c95eb36838; selected=10; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=a9abe1f8-9586-46cb-86bd-dae42940d2f7; selected=13; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=bdf35fc2-d551-4f01-bfa3-927ae78c3478; selected=22; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=e0189574-09c2-4cde-924b-f68520511cd6; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=e039376c-1154-4dfa-b6d4-d5cf570f624a; selected=83; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=f27fef47-6393-407e-925d-89f15bb3f477; selected=15; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=f6e8ffc9-192e-4c09-85ce-3c8591fe654e; selected=36; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=f9639a88-5675-4451-96bb-f1f7e5cdfcb9; selected=17; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fbd72a5e-228a-4243-b19b-5f746738ddb1; selected=78; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=00dbf895-c995-40b8-a5af-8c61cb282d51; Field 2: field_id=13e46b30-43e6-45df-8ac3-8beae8b05b81; Field 3: field_id=16e19931-e74e-418e-9591-cd6e58c215c8; Field 4: field_id=23af73b5-595d-418f-9d88-c8365e0835fc; Field 5: field_id=3980a172-c3ec-4696-af35-95344d772a5f; Field 6: field_id=59a06349-80c7-43ea-b875-8d4bd65d91fc; Field 7: field_id=641007d5-2714-4f51-8fee-7360b1066dd0; Field 8: field_id=83afb02f-3cd8-4ccb-8ba4-cbb8ac8d68ee
- Page 2: Field 9: field_id=8ab2ef48-d1f5-42ef-b899-60c3f6cb5d1d; Field 10: field_id=9b5ee5a8-8329-4788-b3c7-14c95eb36838; Field 11: field_id=a9abe1f8-9586-46cb-86bd-dae42940d2f7; Field 12: field_id=bdf35fc2-d551-4f01-bfa3-927ae78c3478; Field 13: field_id=e0189574-09c2-4cde-924b-f68520511cd6; Field 14: field_id=e039376c-1154-4dfa-b6d4-d5cf570f624a; Field 15: field_id=f27fef47-6393-407e-925d-89f15bb3f477; Field 16: field_id=f6e8ffc9-192e-4c09-85ce-3c8591fe654e
- Page 3: Field 17: field_id=f9639a88-5675-4451-96bb-f1f7e5cdfcb9; Field 18: field_id=fbd72a5e-228a-4243-b19b-5f746738ddb1
