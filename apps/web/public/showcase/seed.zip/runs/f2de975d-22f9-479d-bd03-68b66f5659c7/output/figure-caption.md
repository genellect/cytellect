# Figure legend

Large points are recorded experimental units, independence not confirmed (median per field → sample mean → unit mean); the same marker marks the same run and lines join a run's units; small points are field values (median of the field's observations). Horizontal lines show the mean of unit values (descriptive: no test or interval, run independence not confirmed). n is the number of experimental units, not fields or nuclei.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: bb47318a-f184-41a1-8982-05d0744b2e12; fingerprint: 2f5b119f34e91cfe70c6acd7f11f9d75c25400c4dd988ee5522c24423550e39b.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 反復（Rep1–Rep3。独立性は出典で確認できない）; the researcher had not confirmed that these units were independent.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each recorded experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, Cisplatin 10 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: 5-EU: Mean intensity
(a.u.); region definition: 核小体.

Outcome channel ID: eu5; declared stain: 5-EU.

Outcome uses raw original-pixel intensity measurements.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.

Cisplatin 10 µM, Rep1 · Cisplatin 10 µM: 0 of 19 nuclei missing (0.0%); 0 explicitly excluded.

Cisplatin 10 µM, Rep2 · Cisplatin 10 µM: 0 of 24 nuclei missing (0.0%); 0 explicitly excluded.

Cisplatin 10 µM, Rep3 · Cisplatin 10 µM: 1 of 23 nuclei missing (4.3%); 0 explicitly excluded.

Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.

Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.

Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と Cisplatin 10 µM. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): Cisplatin 10 µM minus Untreated; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=2530.8248, Cisplatin 10 µM=5859.4859, difference=3328.6611.

Run Rep2: Untreated=3713.0679, Cisplatin 10 µM=3579.8009, difference=-133.26693.

Run Rep3: Untreated=4114.0585, Cisplatin 10 µM=3660.6683, difference=-453.39026.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
