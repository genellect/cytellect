# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=1c17b677-a18a-494c-9072-de3c7ee63372; selected=83; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=28ace67b-7bdd-4163-a68c-6b8f2e7bb716; selected=17; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2dd73705-5538-4340-a35a-f0ecb9dff702; selected=33; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=3aaee473-85c6-426e-92bf-29a127d429f6; selected=15; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=495b4160-ae24-4817-9df7-94f8f18108ae; selected=37; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=4ba901a7-a655-4666-9c7d-a251d7cdada5; selected=12; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=52047641-b878-43f6-b655-cf251332200e; selected=10; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=59ddad33-ba42-49a9-800c-921b09d9addf; selected=32; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=9eeb2bf6-f379-4723-8393-21aba10d1a34; selected=19; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=b3e339e0-7ff8-4bbb-b50b-6b7236ec26ee; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=bd922413-313f-47a1-9856-010dba7d15c0; selected=62; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=bdd1ed1f-2a2f-4c75-b2f7-c26969ad4318; selected=78; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=c0e78def-b7aa-432c-abcc-3c326cfa4124; selected=36; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=c74d130f-0419-44a3-9373-d2bbb2e83c6d; selected=52; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=c8a17b04-1222-48d7-ac35-d66bad468ce9; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=ea0fbec0-325d-454e-8736-e1c1e85d6878; selected=22; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=ef382399-ccd6-4418-b2e6-6ef2f0faf6e7; selected=13; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fa238bab-2dcc-4c87-9493-c8c1b6e38be9; selected=31; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=1c17b677-a18a-494c-9072-de3c7ee63372; Field 2: field_id=28ace67b-7bdd-4163-a68c-6b8f2e7bb716; Field 3: field_id=2dd73705-5538-4340-a35a-f0ecb9dff702; Field 4: field_id=3aaee473-85c6-426e-92bf-29a127d429f6; Field 5: field_id=495b4160-ae24-4817-9df7-94f8f18108ae; Field 6: field_id=4ba901a7-a655-4666-9c7d-a251d7cdada5; Field 7: field_id=52047641-b878-43f6-b655-cf251332200e; Field 8: field_id=59ddad33-ba42-49a9-800c-921b09d9addf
- Page 2: Field 9: field_id=9eeb2bf6-f379-4723-8393-21aba10d1a34; Field 10: field_id=b3e339e0-7ff8-4bbb-b50b-6b7236ec26ee; Field 11: field_id=bd922413-313f-47a1-9856-010dba7d15c0; Field 12: field_id=bdd1ed1f-2a2f-4c75-b2f7-c26969ad4318; Field 13: field_id=c0e78def-b7aa-432c-abcc-3c326cfa4124; Field 14: field_id=c74d130f-0419-44a3-9373-d2bbb2e83c6d; Field 15: field_id=c8a17b04-1222-48d7-ac35-d66bad468ce9; Field 16: field_id=ea0fbec0-325d-454e-8736-e1c1e85d6878
- Page 3: Field 17: field_id=ef382399-ccd6-4418-b2e6-6ef2f0faf6e7; Field 18: field_id=fa238bab-2dcc-4c87-9493-c8c1b6e38be9
