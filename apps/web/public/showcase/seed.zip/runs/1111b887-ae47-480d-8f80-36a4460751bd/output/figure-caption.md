# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=08039441-a8bf-4cb1-97c3-93d27807c89c; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 2: field_id=0f40a8af-2c3c-4ce3-b194-696af9755361; selected=332; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 3: field_id=1494dfe2-d196-4d80-a67c-ab9673163cc6; selected=44; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 4: field_id=25aa8bcb-ac8c-43ec-94f9-e7dccc84a95a; selected=56; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 5: field_id=25f56fe1-0d4c-4215-a503-16931976a527; selected=376; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 6: field_id=272902ce-beb9-4886-acd2-811eecc0fbdb; selected=503; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 7: field_id=34105124-151d-4af2-bc21-2ae8aa829001; selected=37; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 8: field_id=42ed7930-2069-4354-824d-582e9faa06ee; selected=471; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 9: field_id=4bc325e2-50c5-45ae-b721-79a3f6daf506; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 10: field_id=72b85e6c-d773-4c99-941e-ebcbc8920bb0; selected=45; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 11: field_id=7fc6e82d-13db-4979-89a9-03e6ec73473f; selected=87; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 12: field_id=9b40ae39-a417-48f3-adbc-dc718ffdd15b; selected=47; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 13: field_id=a41402f1-67ba-485d-b79e-4a7126de1a99; selected=116; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 14: field_id=c5dfa213-f8aa-4fc3-b3f0-9aa5af94e879; selected=244; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 15: field_id=d6f00a48-872a-4cb3-a5e5-6e61e884776c; selected=643; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 16: field_id=dc6e391e-5a44-4de0-b431-b0e4b7984b04; selected=452; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 17: field_id=dcf27815-c5c2-43ae-9fd5-f7a1e2851c34; selected=446; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 18: field_id=f7aad053-8882-4e4f-af16-6a158f9bd7b3; selected=295; status=selected; definition=nuclei; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=08039441-a8bf-4cb1-97c3-93d27807c89c; Field 2: field_id=0f40a8af-2c3c-4ce3-b194-696af9755361; Field 3: field_id=1494dfe2-d196-4d80-a67c-ab9673163cc6; Field 4: field_id=25aa8bcb-ac8c-43ec-94f9-e7dccc84a95a; Field 5: field_id=25f56fe1-0d4c-4215-a503-16931976a527; Field 6: field_id=272902ce-beb9-4886-acd2-811eecc0fbdb; Field 7: field_id=34105124-151d-4af2-bc21-2ae8aa829001; Field 8: field_id=42ed7930-2069-4354-824d-582e9faa06ee
- Page 2: Field 9: field_id=4bc325e2-50c5-45ae-b721-79a3f6daf506; Field 10: field_id=72b85e6c-d773-4c99-941e-ebcbc8920bb0; Field 11: field_id=7fc6e82d-13db-4979-89a9-03e6ec73473f; Field 12: field_id=9b40ae39-a417-48f3-adbc-dc718ffdd15b; Field 13: field_id=a41402f1-67ba-485d-b79e-4a7126de1a99; Field 14: field_id=c5dfa213-f8aa-4fc3-b3f0-9aa5af94e879; Field 15: field_id=d6f00a48-872a-4cb3-a5e5-6e61e884776c; Field 16: field_id=dc6e391e-5a44-4de0-b431-b0e4b7984b04
- Page 3: Field 17: field_id=dcf27815-c5c2-43ae-9fd5-f7a1e2851c34; Field 18: field_id=f7aad053-8882-4e4f-af16-6a158f9bd7b3
