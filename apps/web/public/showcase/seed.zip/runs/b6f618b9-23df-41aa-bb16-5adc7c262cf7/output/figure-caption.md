# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=02c3302b-bc3a-4e90-89a7-cdcf44c11968; selected=12; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=06d586b0-1fcd-4cea-9e64-b28d0282ec36; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=0a13d4d3-7c65-4a77-a319-772fa1b5e119; selected=62; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=0e0cc448-f205-42c8-93bf-ef1e701c7b60; selected=19; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=2123d37b-8761-48bb-866b-5e91ce97ddff; selected=78; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=435f5e7c-ff51-48f5-b6e6-1bae3f91d591; selected=15; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=4d6ed26f-6c6a-4895-bcd2-ff5a7f2dae33; selected=52; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=527ce123-5f19-455e-a11b-910ffa745ef1; selected=32; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=594365e1-361f-4766-92fa-f96cbe891eb2; selected=22; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=8b0c1684-8690-4cc0-9700-5130c9e7f38a; selected=13; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=8e4c5196-fb7c-4910-b933-784168c7fab3; selected=36; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=9d710385-c634-4d3b-ba22-92ec9684db64; selected=10; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=9dbdbf3c-2f30-4a80-8b69-a6d4e2378db6; selected=37; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=c585cea8-94ec-4731-803e-827d498edd5f; selected=17; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=c7ad79f8-e0e3-4008-9f38-5ffd35ac734f; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=c94e38b9-0549-4b20-8325-1f0270b84a18; selected=33; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=d44d7d98-1a94-4b18-9012-cc2be14a38e7; selected=83; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fbc61031-8f79-45fa-96c6-4432003f6e92; selected=31; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=02c3302b-bc3a-4e90-89a7-cdcf44c11968; Field 2: field_id=06d586b0-1fcd-4cea-9e64-b28d0282ec36; Field 3: field_id=0a13d4d3-7c65-4a77-a319-772fa1b5e119; Field 4: field_id=0e0cc448-f205-42c8-93bf-ef1e701c7b60; Field 5: field_id=2123d37b-8761-48bb-866b-5e91ce97ddff; Field 6: field_id=435f5e7c-ff51-48f5-b6e6-1bae3f91d591; Field 7: field_id=4d6ed26f-6c6a-4895-bcd2-ff5a7f2dae33; Field 8: field_id=527ce123-5f19-455e-a11b-910ffa745ef1
- Page 2: Field 9: field_id=594365e1-361f-4766-92fa-f96cbe891eb2; Field 10: field_id=8b0c1684-8690-4cc0-9700-5130c9e7f38a; Field 11: field_id=8e4c5196-fb7c-4910-b933-784168c7fab3; Field 12: field_id=9d710385-c634-4d3b-ba22-92ec9684db64; Field 13: field_id=9dbdbf3c-2f30-4a80-8b69-a6d4e2378db6; Field 14: field_id=c585cea8-94ec-4731-803e-827d498edd5f; Field 15: field_id=c7ad79f8-e0e3-4008-9f38-5ffd35ac734f; Field 16: field_id=c94e38b9-0549-4b20-8325-1f0270b84a18
- Page 3: Field 17: field_id=d44d7d98-1a94-4b18-9012-cc2be14a38e7; Field 18: field_id=fbc61031-8f79-45fa-96c6-4432003f6e92
