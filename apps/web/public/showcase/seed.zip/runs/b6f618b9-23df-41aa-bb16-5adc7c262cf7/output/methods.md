# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: mean; unit: a.u..
Region definition: nucleoli (region set ID nucleoli; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measured channel: 5-EU; stain: 5-EU; recorded channel ID: eu5.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
Each region outcome is the arithmetic mean of (I) over its measured pixels.
The selected raw outcome does not subtract background.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 588; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 588 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 0 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 1fd56fed-2bb5-4cd7-8002-b7350e2c2b3c, 2e7cfdfe-692b-4d8a-9b25-bef40b399bb0, 36e45338-72d0-4c03-a5f1-40f114946aaa, 51ae4d28-2c44-4480-b8e8-fc64282190e8, 5c5e6705-0f7e-4f1b-9eac-7794e0be9915, 5f4a2743-1af8-4bb2-ae81-10fd1c0ee7ff, 695647c0-e1a4-4a9a-b43d-c073281dce93, 757a7e95-0a00-4cca-9c7c-bec8ec5a2814, 77a1833e-0f0c-4764-b29b-e332ce7175ac, 9d2de280-39e2-4176-83c7-f007e6f243e6, a926c579-1ae2-451f-9a11-5b7a62e36b12, ad114ce7-0366-4ee2-b121-ccc16f412fc4, b65bbb12-a148-493b-9732-d841858b3827, c89535ec-b89d-4caa-b0c6-6dc54203f926, d4c7b9e4-a66e-457c-a483-a515274a7df0, d7f67c37-863e-45fd-9c63-6e68de3c0326, dfddbadc-ee0a-4698-aa1f-460d6845971f, f3dbdd04-2869-4471-9d35-1e29a027cc3a) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
