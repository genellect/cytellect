# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=38198fa8-7a60-4303-b928-464edc9ba640; selected=503; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 2: field_id=3f140306-d4c5-4b75-a033-765b01bb9a07; selected=244; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 3: field_id=3f239d78-374c-4c63-b5c9-39d4a26e4d01; selected=643; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 4: field_id=4206aee7-3190-429f-b95f-d7d2b03d58b7; selected=295; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 5: field_id=42dbc785-1963-4d71-9c50-72f30eb89b4e; selected=44; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 6: field_id=44aaf814-f094-4ff4-9e88-b74d41816ae7; selected=56; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 7: field_id=5da35746-8669-455a-8197-40d76d33e071; selected=47; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 8: field_id=82f0e19a-e52a-4f6c-a82b-999941295c70; selected=116; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 9: field_id=8fc5709b-05b4-4284-b431-341ce534d883; selected=37; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 10: field_id=9517b367-799d-4537-bc0b-6c3de9483022; selected=332; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 11: field_id=9811d8de-108e-42cd-8f3a-2bb3264ed92e; selected=45; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 12: field_id=adaf485d-391b-4530-8035-0472ad475b39; selected=376; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 13: field_id=b9635e3d-92e7-48ac-952c-c4bccc7f9500; selected=87; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 14: field_id=c013896d-3ecc-4c5c-b686-c1a12b0b2ce0; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 15: field_id=d3734bae-3940-4f81-a5a1-7d3bed4619ae; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 16: field_id=dbb1d733-b0de-4a82-8b3d-0eb8fb792445; selected=446; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 17: field_id=ee504057-3c1f-4be1-b1da-11c6164498b3; selected=471; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 18: field_id=ef95482b-fd8a-4e42-bd32-1589df7b8a69; selected=452; status=selected; definition=核; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=38198fa8-7a60-4303-b928-464edc9ba640; Field 2: field_id=3f140306-d4c5-4b75-a033-765b01bb9a07; Field 3: field_id=3f239d78-374c-4c63-b5c9-39d4a26e4d01; Field 4: field_id=4206aee7-3190-429f-b95f-d7d2b03d58b7; Field 5: field_id=42dbc785-1963-4d71-9c50-72f30eb89b4e; Field 6: field_id=44aaf814-f094-4ff4-9e88-b74d41816ae7; Field 7: field_id=5da35746-8669-455a-8197-40d76d33e071; Field 8: field_id=82f0e19a-e52a-4f6c-a82b-999941295c70
- Page 2: Field 9: field_id=8fc5709b-05b4-4284-b431-341ce534d883; Field 10: field_id=9517b367-799d-4537-bc0b-6c3de9483022; Field 11: field_id=9811d8de-108e-42cd-8f3a-2bb3264ed92e; Field 12: field_id=adaf485d-391b-4530-8035-0472ad475b39; Field 13: field_id=b9635e3d-92e7-48ac-952c-c4bccc7f9500; Field 14: field_id=c013896d-3ecc-4c5c-b686-c1a12b0b2ce0; Field 15: field_id=d3734bae-3940-4f81-a5a1-7d3bed4619ae; Field 16: field_id=dbb1d733-b0de-4a82-8b3d-0eb8fb792445
- Page 3: Field 17: field_id=ee504057-3c1f-4be1-b1da-11c6164498b3; Field 18: field_id=ef95482b-fd8a-4e42-bd32-1589df7b8a69
