# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=3e5f1e59-5bd8-4c38-9669-a14ec825f6cd; selected=62; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=4f5872b7-10ca-4240-abd6-8e0791004479; selected=15; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=5ad6c7f5-5fa5-4659-a584-f8b6a1469d12; selected=52; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=698078e2-6d5a-402e-a308-3c74950f2573; selected=31; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=6ff834b7-2aa3-42ea-9776-a63ff225943c; selected=19; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=7034046e-2199-497c-b0fd-73c056bacc65; selected=10; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=7de731a2-47d0-448a-980a-828047ef8837; selected=13; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=859aa2d7-6dcb-4abd-a941-2c685c0bcc44; selected=37; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=91163bc0-1ad2-4517-9863-110f19cf595e; selected=22; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=9ec6102c-15a6-45de-8ac2-11072919129d; selected=36; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=b57dbd09-5ddb-4c73-ad05-30a981150043; selected=33; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=b74051b0-a3b7-429d-a9bd-bb30e2907e6b; selected=83; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=c905aca6-7e2c-49a5-9585-7590ecd65200; selected=17; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=d5c7a6b2-2a59-430c-8522-8dfde0ffb991; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=ec8df691-469c-49ec-9754-f09c792fccb0; selected=78; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=f30f407a-7799-46da-a267-4cf886f19303; selected=32; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=f827df72-3805-4a0b-b82b-6e3790d5face; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=feff3021-e978-4190-a824-e1ff7094b204; selected=12; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=3e5f1e59-5bd8-4c38-9669-a14ec825f6cd; Field 2: field_id=4f5872b7-10ca-4240-abd6-8e0791004479; Field 3: field_id=5ad6c7f5-5fa5-4659-a584-f8b6a1469d12; Field 4: field_id=698078e2-6d5a-402e-a308-3c74950f2573; Field 5: field_id=6ff834b7-2aa3-42ea-9776-a63ff225943c; Field 6: field_id=7034046e-2199-497c-b0fd-73c056bacc65; Field 7: field_id=7de731a2-47d0-448a-980a-828047ef8837; Field 8: field_id=859aa2d7-6dcb-4abd-a941-2c685c0bcc44
- Page 2: Field 9: field_id=91163bc0-1ad2-4517-9863-110f19cf595e; Field 10: field_id=9ec6102c-15a6-45de-8ac2-11072919129d; Field 11: field_id=b57dbd09-5ddb-4c73-ad05-30a981150043; Field 12: field_id=b74051b0-a3b7-429d-a9bd-bb30e2907e6b; Field 13: field_id=c905aca6-7e2c-49a5-9585-7590ecd65200; Field 14: field_id=d5c7a6b2-2a59-430c-8522-8dfde0ffb991; Field 15: field_id=ec8df691-469c-49ec-9754-f09c792fccb0; Field 16: field_id=f30f407a-7799-46da-a267-4cf886f19303
- Page 3: Field 17: field_id=f827df72-3805-4a0b-b82b-6e3790d5face; Field 18: field_id=feff3021-e978-4190-a824-e1ff7094b204
