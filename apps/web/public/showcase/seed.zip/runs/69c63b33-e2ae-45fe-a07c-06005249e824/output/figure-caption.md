# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
106 selected observations are shown across all 1 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=106; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=081620c8-e1b6-411f-83bd-a1d4fb92da90; selected=14; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 2: field_id=3ea70d38-cb66-4e8d-83db-f01d86a8dae4; selected=25; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 3: field_id=6d91a0d6-077f-4dfa-8f50-719878400416; selected=20; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 4: field_id=e278bb13-caa4-4d6f-9a1f-d534728e4e5d; selected=10; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 5: field_id=f21ac3e2-c436-4b9c-b7b8-501b70dcb1b4; selected=15; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 6: field_id=ffc953f6-ae80-413d-90f2-5c75cb5e63a0; selected=22; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=081620c8-e1b6-411f-83bd-a1d4fb92da90; Field 2: field_id=3ea70d38-cb66-4e8d-83db-f01d86a8dae4; Field 3: field_id=6d91a0d6-077f-4dfa-8f50-719878400416; Field 4: field_id=e278bb13-caa4-4d6f-9a1f-d534728e4e5d; Field 5: field_id=f21ac3e2-c436-4b9c-b7b8-501b70dcb1b4; Field 6: field_id=ffc953f6-ae80-413d-90f2-5c75cb5e63a0
