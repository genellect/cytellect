# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=16126f5b-0359-4af7-8c9a-924138bfe01d; selected=22; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=171728d2-3e52-41d6-8405-6d00537f3979; selected=33; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2d5ed832-7cbb-44ce-a2b3-c326f60bf9cf; selected=37; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=2de6697b-0181-4f40-9d59-0a2219b6ab74; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=47ef73e8-b01a-4e09-9db0-06b826576597; selected=17; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=6150d07f-65c0-4302-a507-229a6eae3960; selected=78; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=669bc769-c7df-4a9c-a773-3f5a8a49078b; selected=12; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=695262f3-b673-4778-837c-66761dcd38ed; selected=13; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=733e68c3-6ec5-409a-89fe-c3947d01164b; selected=15; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=889b7ec1-ad5c-4aee-ab2b-7c2bc8ea80c5; selected=36; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=a5e346a2-6228-42e1-bc8c-4ddc482d2764; selected=31; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=ca3de514-f567-4b52-91a7-86528684ef2d; selected=10; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=deec6b59-d8af-454b-b6b8-e4e13ed45f74; selected=83; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=e25bc62d-9257-47dd-b416-e942133040a5; selected=32; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=e29c3aa7-4e12-4eb5-8c45-33de507cd98b; selected=62; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=e47cb467-5d7b-4c16-8e2d-cec0628fd5f0; selected=18; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=f183caa2-e506-4315-9db9-e51f2f257f82; selected=19; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=f30c596a-6162-4319-85ad-315a7bb19ae3; selected=52; status=selected; definition=nucleoli; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=16126f5b-0359-4af7-8c9a-924138bfe01d; Field 2: field_id=171728d2-3e52-41d6-8405-6d00537f3979; Field 3: field_id=2d5ed832-7cbb-44ce-a2b3-c326f60bf9cf; Field 4: field_id=2de6697b-0181-4f40-9d59-0a2219b6ab74; Field 5: field_id=47ef73e8-b01a-4e09-9db0-06b826576597; Field 6: field_id=6150d07f-65c0-4302-a507-229a6eae3960; Field 7: field_id=669bc769-c7df-4a9c-a773-3f5a8a49078b; Field 8: field_id=695262f3-b673-4778-837c-66761dcd38ed
- Page 2: Field 9: field_id=733e68c3-6ec5-409a-89fe-c3947d01164b; Field 10: field_id=889b7ec1-ad5c-4aee-ab2b-7c2bc8ea80c5; Field 11: field_id=a5e346a2-6228-42e1-bc8c-4ddc482d2764; Field 12: field_id=ca3de514-f567-4b52-91a7-86528684ef2d; Field 13: field_id=deec6b59-d8af-454b-b6b8-e4e13ed45f74; Field 14: field_id=e25bc62d-9257-47dd-b416-e942133040a5; Field 15: field_id=e29c3aa7-4e12-4eb5-8c45-33de507cd98b; Field 16: field_id=e47cb467-5d7b-4c16-8e2d-cec0628fd5f0
- Page 3: Field 17: field_id=f183caa2-e506-4315-9db9-e51f2f257f82; Field 18: field_id=f30c596a-6162-4319-85ad-315a7bb19ae3
