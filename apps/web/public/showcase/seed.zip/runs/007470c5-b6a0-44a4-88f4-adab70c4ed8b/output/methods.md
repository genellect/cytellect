# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: mean; unit: a.u..
Region definition: nucleoli (region set ID nucleoli; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measured channel: 5-EU; stain: 5-EU; recorded channel ID: eu5.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
Each region outcome is the arithmetic mean of (I) over its measured pixels.
The selected raw outcome does not subtract background.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 588; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 588 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 0 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 0995f489-bfa9-4ccc-95fd-18fbf6bd58b3, 0b3c0b61-d2f1-4994-960c-d420987fe06b, 3d4be9e4-485d-4740-882c-5e66533bd81f, 6b491633-d2c0-43d8-a157-0d5e4f0d726f, 6da02837-a7cb-43e3-9a62-2cbd869a9219, 97a355f6-1e37-4181-93bf-eb694414d777, 989e172c-c1be-4537-9782-74e6634b00fb, b1af857c-b513-4c88-991b-b93d1409b30d, ca522088-fe6e-4032-a3ef-959bc4542056, d09ae8c6-09c7-4b7e-9a20-dfc11cb22c3f, d2e13c9b-d22e-4134-8a46-be03c92c5c88, d367ca81-d6d4-40cf-9015-8dbe7406cf38, dcb04c57-f969-4b44-932a-f068b31e0547, de739e4d-42c9-4019-8db0-3cbe35635aae, efe03f72-bbef-4416-9e3f-1378aebe72e1, f98ba6d8-119a-4bb4-8d92-eb01b6b0cb64, fead81dc-5630-491a-8061-282a5a184081, ff02cbe9-bbd1-49e0-b495-10c1274246b0) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.
ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
