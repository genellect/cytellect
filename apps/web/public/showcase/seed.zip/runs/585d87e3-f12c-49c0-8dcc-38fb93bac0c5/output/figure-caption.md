# Figure legend

Points are independent-unit summaries; jitter affects display only (seed 0). Lines connect saved complete pair identities.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: aebf232d-0590-4963-8d0a-a756ca9c5729; fingerprint: 78a30422b54214dcbebef2f91feb13794e78405d6722dabd46ec696b46c2f21a.

Inference core: 1.0.0; request protocol: 2.0.0.

The inferential unit was 反復（Rep1–Rep3）内の各処理条件（同日撮影。反復の独立性は出典に記載なし）.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each independent experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: NPM1: Mean intensity
(a.u.); region definition: 核.

Outcome channel ID: npm1; declared stain: NPM1.

Outcome uses raw original-pixel intensity measurements.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）で撮影したUntreated と ActD 1 µM. Pairs use saved identity; incomplete pairs were rejected.

Holm family workspace-planned: Untreated versus ActD 1 µM. Every declared contrast is tested regardless of the omnibus result. These are planned pairwise tests, not Dunn or Games–Howell tests. Any t-test difference intervals are pointwise 95% intervals, not multiplicity-adjusted.

Untreated versus ActD 1 µM: paired t-test; statistic=0.46115926; p=0.68997778; Holm-adjusted p=0.68997778.

Mean difference=336.00086; pointwise 95% CI [-2798.914, 3470.9158].

Resolved test settings: {"alternative": "two-sided", "inference_version": "1.0.0", "inferential_unit": "independent experimental unit", "p_value_method": "Student t reference distribution", "resamples": null, "scipy_version": "1.18.1", "seed": null, "selection": "explicit researcher choice; no normality pretest or p-based selection"}.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: few_independent_units_model_assumptions_and_power_require_review.
