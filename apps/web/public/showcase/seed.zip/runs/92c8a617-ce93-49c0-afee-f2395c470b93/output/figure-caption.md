# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
103 selected observations are shown across all 1 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=103; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=1efa043b-2d70-4880-8609-a677aa4b2609; selected=21; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 2: field_id=2e7dbb34-1679-410e-87b8-2c1306d83f29; selected=20; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 3: field_id=4b475418-876c-450e-84e1-9f9e68ef49e8; selected=14; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 4: field_id=96fa5667-5059-46db-b223-c62d495904ab; selected=24; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 5: field_id=f3eb3ba2-5b51-4057-87ad-37381a231093; selected=10; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)
- Field 6: field_id=f92f39b4-66a9-456a-977a-c4bb3f9d49b8; selected=14; status=selected; definition=核; Hoechst (stain=Hoechst); NPM1 (stain=NPM1)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=1efa043b-2d70-4880-8609-a677aa4b2609; Field 2: field_id=2e7dbb34-1679-410e-87b8-2c1306d83f29; Field 3: field_id=4b475418-876c-450e-84e1-9f9e68ef49e8; Field 4: field_id=96fa5667-5059-46db-b223-c62d495904ab; Field 5: field_id=f3eb3ba2-5b51-4057-87ad-37381a231093; Field 6: field_id=f92f39b4-66a9-456a-977a-c4bb3f9d49b8
