# Figure legend

Per-field descriptive measurements: mean (a.u.).
Measured channel: channel_id=eu5; label=5-EU; stain=5-EU.
Points are regions; squares show the median within each field.
588 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=588; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=334d0b9a-d8a2-4264-b991-bca19a768310; selected=78; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=3c02a30e-d56e-4c2b-a09d-a21c944aa10c; selected=37; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=40b2ff45-1b4e-451e-8bf1-fe4e4edebfbd; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=57dacd28-efa7-42db-8233-d6d22c7f5e51; selected=13; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=7d6eff63-3ae2-422d-a949-55b53bc237f7; selected=62; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=9b7f4b2a-1e98-433a-9d25-5147bd555259; selected=18; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=a4bdd5ec-fd84-4089-b870-f160c9b9bc7d; selected=12; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=a88dbb40-04a9-4d4b-a011-58e8b0776cdb; selected=32; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=aa47fdfa-3e9e-4562-bfc5-ddf71d0a2400; selected=52; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=aca399fc-eea6-49ee-ad25-65b068febc76; selected=22; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=bfd4b138-b1f5-446d-83ce-9da6644a1337; selected=10; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=c2a1bf43-8ed4-4e6a-99a0-ad4eb7cf37f4; selected=15; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=d3c47941-ba84-43ce-b1c3-8825e4bab4b0; selected=36; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=d7eaa006-e745-4dbc-bbae-2df30d995c61; selected=33; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=dbe2d692-50d0-419b-be5c-6b45dfb9e7de; selected=31; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=dfc3dd50-0768-45b3-97b8-7606b42f844b; selected=17; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=eaf9df85-35f8-493c-b64d-8104cbc9c61a; selected=83; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fa56703e-76a7-4c4e-88aa-28db01e3ec6c; selected=19; status=selected; definition=核小体; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=334d0b9a-d8a2-4264-b991-bca19a768310; Field 2: field_id=3c02a30e-d56e-4c2b-a09d-a21c944aa10c; Field 3: field_id=40b2ff45-1b4e-451e-8bf1-fe4e4edebfbd; Field 4: field_id=57dacd28-efa7-42db-8233-d6d22c7f5e51; Field 5: field_id=7d6eff63-3ae2-422d-a949-55b53bc237f7; Field 6: field_id=9b7f4b2a-1e98-433a-9d25-5147bd555259; Field 7: field_id=a4bdd5ec-fd84-4089-b870-f160c9b9bc7d; Field 8: field_id=a88dbb40-04a9-4d4b-a011-58e8b0776cdb
- Page 2: Field 9: field_id=aa47fdfa-3e9e-4562-bfc5-ddf71d0a2400; Field 10: field_id=aca399fc-eea6-49ee-ad25-65b068febc76; Field 11: field_id=bfd4b138-b1f5-446d-83ce-9da6644a1337; Field 12: field_id=c2a1bf43-8ed4-4e6a-99a0-ad4eb7cf37f4; Field 13: field_id=d3c47941-ba84-43ce-b1c3-8825e4bab4b0; Field 14: field_id=d7eaa006-e745-4dbc-bbae-2df30d995c61; Field 15: field_id=dbe2d692-50d0-419b-be5c-6b45dfb9e7de; Field 16: field_id=dfc3dd50-0768-45b3-97b8-7606b42f844b
- Page 3: Field 17: field_id=eaf9df85-35f8-493c-b64d-8104cbc9c61a; Field 18: field_id=fa56703e-76a7-4c4e-88aa-28db01e3ec6c
