# Figure legend

Large points are recorded experimental units, independence not confirmed (median per field → sample mean → unit mean); the same marker marks the same run and lines join a run's units; small points are field values (median of the field's observations). Horizontal lines show the mean of unit values (descriptive: no test or interval, run independence not confirmed). n is the number of experimental units, not fields or nuclei.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 4cf8c05d-b29b-4344-9ce2-318df49854ec; fingerprint: a0aa647fdd0a22666832fe28d6eb078fbb32ff3cdef050dcb4f07cbc6c272751.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 反復（Rep1–Rep3。独立性は出典で確認できない）; the researcher had not confirmed that these units were independent.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each recorded experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: Nucleolar eccentricity
(dimensionless); region definition: 核質.

Outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.

Outcome missing outcomes: 3; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.

ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.

ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.

ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.

Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.

Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.

Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と ActD. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): ActD 1 µM minus Untreated; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=0.82709153, ActD 1 µM=0.51922447, difference=-0.30786706.

Run Rep2: Untreated=0.75199847, ActD 1 µM=0.38424543, difference=-0.36775304.

Run Rep3: Untreated=0.7316373, ActD 1 µM=0.57791175, difference=-0.15372555.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: missing_outcomes_excluded_not_assumed_missing_at_random.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
