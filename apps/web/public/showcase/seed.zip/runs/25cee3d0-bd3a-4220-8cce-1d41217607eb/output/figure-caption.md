# Figure legend

Histogram counts independent units using shared equal-width bins; rugs show every unit.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 105c7c0d-3721-4b18-814b-2e3598897b38; fingerprint: 742cac0bb2e4732744fcb8f2e5cb80c0abf97b2754a06c161ef0a37a9cd8e2f1.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 反復（Rep1–Rep3。独立性は出典で確認できない）; the researcher had not confirmed that these units were independent.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each recorded experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, ActD 1 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: 5-EU: Mean intensity
(a.u.); region definition: 核小体.

Outcome channel ID: eu5; declared stain: 5-EU.

Outcome uses raw original-pixel intensity measurements.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.

ActD 1 µM, Rep1 · ActD 1 µM: 0 of 20 nuclei missing (0.0%); 0 explicitly excluded.

ActD 1 µM, Rep2 · ActD 1 µM: 0 of 30 nuclei missing (0.0%); 0 explicitly excluded.

ActD 1 µM, Rep3 · ActD 1 µM: 1 of 22 nuclei missing (4.5%); 0 explicitly excluded.

Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.

Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.

Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と ActD. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): ActD 1 µM minus Untreated; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=2530.8248, ActD 1 µM=2793.7285, difference=262.90368.

Run Rep2: Untreated=3713.0679, ActD 1 µM=3629.7597, difference=-83.308161.

Run Rep3: Untreated=4114.0585, ActD 1 µM=2797.2762, difference=-1316.7823.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
