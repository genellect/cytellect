# Figure legend

Large points are recorded experimental units, independence not confirmed (median per field → sample mean → unit mean); the same marker marks the same run and lines join a run's units; small points are field values (median of the field's observations). Horizontal lines show the mean of unit values (descriptive: no test or interval, run independence not confirmed). n is the number of experimental units, not fields or nuclei.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 4736b363-a8d9-4de6-9cd5-f8f8414e53de; fingerprint: 8a448efa5c0c8262612b11d3bd49d0f07f27ff2610c5695a7f6f2a9e12caac09.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 反復（Rep1–Rep3。独立性は出典で確認できない）; the researcher had not confirmed that these units were independent.

Region measurements were reduced to a median within each field, an unweighted mean of fields within each sample, and an unweighted mean of samples within each recorded experimental unit. Regions and fields were not treated as independent replicates.

Conditions in the declared analysis: Untreated, Oxaliplatin 10 µM.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: Nucleolar area per nucleus
(px²); region definition: 核質.

Outcome is a per-nucleus compartment-summary value (selection 1.1.0): pixel area of the adopted nucleolar union per nucleus with at least one adopted nucleolus (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.

Outcome missing outcomes: 2; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.

Oxaliplatin 10 µM, Rep1 · Oxaliplatin 10 µM: 0 of 25 nuclei missing (0.0%); 0 explicitly excluded.

Oxaliplatin 10 µM, Rep2 · Oxaliplatin 10 µM: 0 of 17 nuclei missing (0.0%); 0 explicitly excluded.

Oxaliplatin 10 µM, Rep3 · Oxaliplatin 10 µM: 0 of 23 nuclei missing (0.0%); 0 explicitly excluded.

Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.

Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.

Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ反復（Rep）の未処理と Oxaliplatin 10 µM. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): Oxaliplatin 10 µM minus Untreated; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Rep1: Untreated=566.5, Oxaliplatin 10 µM=469.83333, difference=-96.666667.

Run Rep2: Untreated=601.33333, Oxaliplatin 10 µM=499.33333, difference=-102.

Run Rep3: Untreated=703.66667, Oxaliplatin 10 µM=383.33333, difference=-320.33333.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: missing_outcomes_excluded_not_assumed_missing_at_random.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
