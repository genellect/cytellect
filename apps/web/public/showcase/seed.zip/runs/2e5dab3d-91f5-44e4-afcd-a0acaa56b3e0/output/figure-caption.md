# Figure legend

Per-field descriptive measurements: nucleolar_eccentricity (dimensionless).
Per-nucleus compartment-summary value: area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0); per-field observed values.
Points are nuclei; squares show the median within each field.
149 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=152; explicitly excluded=0; outside saved selection=0; missing metric=3.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=295f171e-3b35-442e-b93e-5d4570f32ba2; selected=18; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 2: field_id=2a4b0408-a9e1-47b2-a2f6-6b8b0f9c7fdf; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 3: field_id=2fed1217-ede3-46fe-81cd-3eea664a06f6; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 4: field_id=31cb6ef2-81bd-4719-abf2-e483d3c6bb42; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 5: field_id=5dffca8a-da6f-4725-a69c-fc83e510cc0c; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 6: field_id=64b15c95-b733-4412-abd2-48401509c67c; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 7: field_id=68f4c43a-b8ce-439f-8a00-cbc398d0a046; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 8: field_id=6d8f90b8-99eb-4c7b-8e9f-5e47f1d7c814; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 9: field_id=7fcf148a-70f7-4f76-a406-8c491a7d1c85; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 10: field_id=8422e54b-20c0-4ce6-86a5-ae3d008645fc; selected=5; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 11: field_id=8b82d6d7-5866-43a7-82db-738679d8e56b; selected=9; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 12: field_id=a2e02b94-f149-42d6-8d49-39027b208eff; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 13: field_id=aa3925ca-52f3-4a62-a62a-b45f108012f5; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 14: field_id=d3cab9dc-88d8-438c-9ca8-f462cb3353cf; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 15: field_id=e65c9544-a002-4f8b-bb65-0d763653ab27; selected=10; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 16: field_id=e89d165a-4103-4049-af89-386c44ab1137; selected=12; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 17: field_id=ef452328-b7e5-4d77-beb4-89c00cd0ea7d; selected=7; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)
- Field 18: field_id=fda98fda-dc85-4cb4-b6d5-325b22433187; selected=6; status=selected; definition=nucleoplasm; Hoechst (stain=Hoechst); NPM1 (stain=NPM1); 5-EU (stain=5-EU)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established
- missing_outcomes_excluded_inspect_fieldwise_missingness

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=295f171e-3b35-442e-b93e-5d4570f32ba2; Field 2: field_id=2a4b0408-a9e1-47b2-a2f6-6b8b0f9c7fdf; Field 3: field_id=2fed1217-ede3-46fe-81cd-3eea664a06f6; Field 4: field_id=31cb6ef2-81bd-4719-abf2-e483d3c6bb42; Field 5: field_id=5dffca8a-da6f-4725-a69c-fc83e510cc0c; Field 6: field_id=64b15c95-b733-4412-abd2-48401509c67c; Field 7: field_id=68f4c43a-b8ce-439f-8a00-cbc398d0a046; Field 8: field_id=6d8f90b8-99eb-4c7b-8e9f-5e47f1d7c814
- Page 2: Field 9: field_id=7fcf148a-70f7-4f76-a406-8c491a7d1c85; Field 10: field_id=8422e54b-20c0-4ce6-86a5-ae3d008645fc; Field 11: field_id=8b82d6d7-5866-43a7-82db-738679d8e56b; Field 12: field_id=a2e02b94-f149-42d6-8d49-39027b208eff; Field 13: field_id=aa3925ca-52f3-4a62-a62a-b45f108012f5; Field 14: field_id=d3cab9dc-88d8-438c-9ca8-f462cb3353cf; Field 15: field_id=e65c9544-a002-4f8b-bb65-0d763653ab27; Field 16: field_id=e89d165a-4103-4049-af89-386c44ab1137
- Page 3: Field 17: field_id=ef452328-b7e5-4d77-beb4-89c00cd0ea7d; Field 18: field_id=fda98fda-dc85-4cb4-b6d5-325b22433187
