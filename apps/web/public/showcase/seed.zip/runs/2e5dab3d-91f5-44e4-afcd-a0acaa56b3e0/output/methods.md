# Cytellect descriptive Methods

Generated from saved settings; review before publication.
Statistical Methods template: cytellect-statistical-methods 1.1.0.
Descriptive protocol: 1.0.0; source: region-2d.
Selected outcome: nucleolar_eccentricity; unit: dimensionless.
Region definition: nucleoplasm (region set ID nucleoplasm; regions from Fiji nuclear-compartment detection; the recorded label is retained in figure-data.json). Saved reviewed integer-labelled pixel unions in original image coordinates defined the measured regions; an object ID does not establish a biological cell.
Measurement protocol 4.0.0 (policy 1.2.0, automatic_background) recorded raw mean, median and pixel sum of the unchanged original pixels at original resolution, as in raw protocol 3.0.0, plus corrections from an automatic background candidate (algorithm cytellect-automatic-background 1.0.0). The candidate was selected by the software; it is not a human-confirmed background ROI.
The selected outcome does not use these automatic background corrections.
The outcome is a per-nucleus compartment-summary value (selection 1.1.0): area-weighted mean over the nucleus's adopted nucleoli of sqrt(1 − λmin/λmax) of each object's pixel-centre covariance; one-pixel objects are not measured (compartment-summary selection 1.1.0). Nuclei, not regions, are the observations; the summary was bound to the reviewed nucleoplasm mask by exact nucleus identity and area. Missing values keep their recorded reason and were not replaced with zero.
Only per-field descriptions were calculated: median and linearly interpolated quartiles at index (n−1)p in the ordered observations. No hypothesis test, regression, standard error or confidence interval was calculated.
Selected observations: 149; fields with selected values: 18 of 18 registered fields. Independent experimental n was not assessed; region, field and sample labels do not establish independence.
Of 152 measured observation rows, 0 were explicitly excluded, 0 were unselected by the saved gate and 3 otherwise selected outcomes were missing.
Manual mask edits: none are recorded for the 18 measured fields; their measured masks are the initial regions (Fiji nuclear-compartment candidates).
Edits to the pinned source masks (revisions 148d67a1-2802-4bab-9da0-a4432f724bd5, 18b1c702-60a3-4a11-9cef-f870a100afc9, 1b307da7-3f90-4921-af8c-9c316707827d, 1ccd006e-4cd2-410c-9a06-23ddc9acc0c5, 2e2e7e50-b936-4f34-93db-a56ad1ca421a, 3c469cef-4925-4fda-aaeb-bafc70e5dd41, 407eb54d-9615-470f-bfe9-eec4387d9a26, 4ab66c2a-0ee6-4b1e-b6d6-367ff7caf41d, 4bf154a9-6dbc-40b7-9c97-e8886d2bf7f5, 4e2becf5-ddd0-4f8c-876a-65cc4e33c97f, 4f1c289b-7769-4416-8116-f298d8640332, 51c33ed8-900b-41f4-9e4e-2d4de37068c4, 5f2794ef-e216-48fd-8fcd-9f656a803d24, 6a47e23c-4931-4aaf-a5a8-ea2faf748637, 6ac0925c-22d1-43cf-8b61-31fdd5093d4e, 6c0fde35-b258-4a29-9e90-6ba1f24875e7, 6f4cabed-060b-4802-80aa-631b7d4baa9c, 873326f5-daf3-401a-9832-1ac67420c1bf, 89319637-fe42-4d9a-b676-3cf7cb24a30b, 8b14dd1b-2f85-415b-bffc-e6147f2f9667, 96c342d0-fb39-4c59-905d-d9b294fea625, 9bbe887b-6096-4b4e-a2e2-1317bfdc9e3e, 9c92f782-eec0-4cd1-8dbf-d9c9eac25797, 9ecb7ff8-1bd1-453a-b690-2b79131ca20b, a63cd364-6e52-478b-b59c-9acfe5ecc428, a7762cd9-746b-4ecc-bfcc-a869dd349f14, aa19ada7-e2b0-451b-95c5-be20d4720fd9, c1394b75-7b03-41f0-9d8f-c0ac1119eeb9, c4b12a88-d3df-40a5-9f16-8b793336028b, ca9f03d7-0746-4ee3-b33b-0c73e109bea5, d1bc325f-213e-4eda-8528-6c06336a2b57, dd8717a7-4f40-415c-8379-2bce9df1f1ca, de269c06-8d53-4d66-9b5c-cf6639950a40, def775e6-0383-4ae0-940e-4897f3ea63b3, f06e0d00-7b56-417c-8215-d0d389bb5a72, fabb97b3-f172-4259-acb0-74f4dfb53508) are recorded in those revisions and are not counted here.
Explicitly excluded failed fields: 0; their observation counts remain unknown. Missing values and empty fields were retained with reasons, not replaced with zero.
No new normalization, image processing or selection was performed by this descriptive protocol.
Complete observation values, field summaries and selection records are in plot-data.csv, field-summary.csv, selection.csv and figure-data.json; missingness.csv is included when missing outcomes exist. The source JSON retains field, mask, channel, recipe and applicable background/calibration provenance. Hashes in the accompanying source/manifest identify those files.
Original acquisition details and biological suitability require researcher review; absent facts are not inferred.
Warnings: descriptive_independence_not_assessed; acquisition_comparability_not_established; missing_outcomes_excluded_inspect_fieldwise_missingness

Unresolved nucleoli (unresolved-as-missing/1.0.0): nuclei whose nucleolus was not established (no candidate, indeterminate, or an empty nucleoplasm) were kept in the ledger as missing, not removed; values describe the nuclei with an established nucleolus. The researcher confirmed the per-field list of reasons before the analysis. Missing fractions use all nuclei as the denominator.
Cisplatin 10 µM, Rep1 · Cisplatin 10 µM: 0 of 19 nuclei missing (0.0%); 0 explicitly excluded.
Cisplatin 10 µM, Rep2 · Cisplatin 10 µM: 0 of 24 nuclei missing (0.0%); 0 explicitly excluded.
Cisplatin 10 µM, Rep3 · Cisplatin 10 µM: 1 of 23 nuclei missing (4.3%); 0 explicitly excluded.
Untreated, Rep1 · Untreated: 0 of 37 nuclei missing (0.0%); 0 explicitly excluded.
Untreated, Rep2 · Untreated: 2 of 23 nuclei missing (8.7%); 0 explicitly excluded.
Untreated, Rep3 · Untreated: 0 of 26 nuclei missing (0.0%); 0 explicitly excluded.

Descriptive figure policy: 2.0.0 (field-pages); output status: ready. Pages preserve the complete field order, global field labels and common Y limits/ticks. Pagination does not select observations or change any numerical summary.
