# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
No manual mask edits are recorded; masks are the initial regions.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=0288698e-8fff-4ee9-9201-eda06763c13a; selected=332; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 2: field_id=03290c0a-250d-480f-8593-a1b060803134; selected=643; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 3: field_id=074317f0-1305-4899-8d7a-3ef224daf9ef; selected=471; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 4: field_id=147a9b7b-5631-4595-927d-2eaee203ccfd; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 5: field_id=17521999-1fa1-4f32-841f-7984fb9c2ac3; selected=446; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 6: field_id=4824c4dc-055b-4a9a-b474-1eb2531349dd; selected=503; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 7: field_id=5a4c5af1-f45b-4c7f-88b0-6f2f5e50805a; selected=376; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 8: field_id=74e8f5d1-4bc5-40e5-9e55-c21040f8b6ed; selected=452; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 9: field_id=86ddbe2f-9cd0-49e8-9b6f-0cd23324d8b4; selected=44; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 10: field_id=9b8d85e6-9dfa-4dd0-bb92-3a14ce9c5452; selected=119; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 11: field_id=9fd699ac-94e1-4c7e-a971-baa476949a8b; selected=87; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 12: field_id=a30c735e-7727-4591-a7b7-820d0328d2ae; selected=244; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 13: field_id=af2c83db-7dc5-49e7-8719-83f6952503ed; selected=56; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 14: field_id=bd0a1311-95aa-4e7a-8e5b-e3221abff163; selected=47; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 15: field_id=c57ff33b-c329-471c-a10b-9005c38a597d; selected=37; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 16: field_id=cdac8f36-3baa-40ae-bae6-20cca4c0770b; selected=295; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 17: field_id=d98ca16c-98c6-413a-94f0-4d107dff184b; selected=116; status=selected; definition=nuclei; Hoechst (stain=Hoechst)
- Field 18: field_id=ece1942b-6b3a-43a2-a494-ec1069b75837; selected=45; status=selected; definition=nuclei; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=0288698e-8fff-4ee9-9201-eda06763c13a; Field 2: field_id=03290c0a-250d-480f-8593-a1b060803134; Field 3: field_id=074317f0-1305-4899-8d7a-3ef224daf9ef; Field 4: field_id=147a9b7b-5631-4595-927d-2eaee203ccfd; Field 5: field_id=17521999-1fa1-4f32-841f-7984fb9c2ac3; Field 6: field_id=4824c4dc-055b-4a9a-b474-1eb2531349dd; Field 7: field_id=5a4c5af1-f45b-4c7f-88b0-6f2f5e50805a; Field 8: field_id=74e8f5d1-4bc5-40e5-9e55-c21040f8b6ed
- Page 2: Field 9: field_id=86ddbe2f-9cd0-49e8-9b6f-0cd23324d8b4; Field 10: field_id=9b8d85e6-9dfa-4dd0-bb92-3a14ce9c5452; Field 11: field_id=9fd699ac-94e1-4c7e-a971-baa476949a8b; Field 12: field_id=a30c735e-7727-4591-a7b7-820d0328d2ae; Field 13: field_id=af2c83db-7dc5-49e7-8719-83f6952503ed; Field 14: field_id=bd0a1311-95aa-4e7a-8e5b-e3221abff163; Field 15: field_id=c57ff33b-c329-471c-a10b-9005c38a597d; Field 16: field_id=cdac8f36-3baa-40ae-bae6-20cca4c0770b
- Page 3: Field 17: field_id=d98ca16c-98c6-413a-94f0-4d107dff184b; Field 18: field_id=ece1942b-6b3a-43a2-a494-ec1069b75837
