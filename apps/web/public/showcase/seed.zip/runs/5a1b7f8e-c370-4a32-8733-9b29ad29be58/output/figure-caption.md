# Figure legend

Points are summaries of recorded experimental units (independence not confirmed); jitter affects display only (seed 0). Boxes show linear-interpolated quartiles and median; whiskers end at observations within 1.5 IQR. All units remain shown.

# Cytellect common-statistics Methods



Review this saved-settings draft before publication.

Methods template: cytellect-common-statistics-methods 1.0.0.

Source revision: 682ecc6a-899b-420d-b29e-6bb97cb331b4; fingerprint: 86bc1a175f50e1b8776aac6dce862fbd798dcff1b264a40bcd2ffdc05abffbfd.

Inference core: 1.0.0; request protocol: 2.0.0.

The experimental unit was 実験回（Run1–Run3。日付の異なるバッチの別のプレート）; the researcher had not confirmed that these units were independent.

Each field contributed one field value, then fields were reduced to an unweighted mean within each sample and samples to an unweighted mean within each recorded experimental unit. Fields were not treated as independent replicates.

Conditions in the declared analysis: Non-targeting, PLK1 KO.

The researcher selected the method explicitly. No normality pretest or observed p-value selected a method.

Reviewed original-coordinate regions and saved original-pixel measurements were used. No normalization, batch adjustment or measurement transformation was performed at this statistical stage.

Outcome: Nucleus count
(nuclei per field); region definition: 核.

Outcome is one value per field (field-summary selection 1.0.0): adopted nuclei per field, including nuclei touching the image border (field-summary/1.0.0). Fields, not nuclei, are the observations; explicitly excluded nuclei are not counted and excluded or failed fields are not observations. A nucleus count is the number of imaged nuclei, not a viability or proliferation measure, and it depends on how fields were chosen.

Outcome missing outcomes: 0; explicitly excluded failed fields: 0. Full field, observation and unit ledgers are exported.

Outcome acquisition basis: same-settings; comparability is researcher-confirmed, not established by the software.

Pairing basis: 同じ実験回（プレート）の対照と PLK1 ノックアウト. Pairs use saved identity; incomplete pairs were rejected.

Estimates (comparison-estimates/1.0.0): PLK1 KO minus Non-targeting; n=3 and 3 recorded experimental units (independence not confirmed), 3 complete pairs.

Difference: not estimated (inference_not_requested).

Ratio: not estimated (inference_not_requested).

Run Run1: Non-targeting=456.33333, PLK1 KO=80, difference=-376.33333.

Run Run2: Non-targeting=347.33333, PLK1 KO=73, difference=-274.33333.

Run Run3: Non-targeting=450.33333, PLK1 KO=70.333333, difference=-380.

Descriptive comparison: no hypothesis test, p-value or confidence interval was calculated, because the independence of the experimental units was not confirmed by the researcher. Unit values and per-run differences are descriptive and must not be read as inference.

Missingness was not assumed random. All explicit exclusions remain recorded; unexcluded units without outcomes were rejected. Inferential applicability depends on the recorded design and assumptions.

Warning: acquisition_comparability_user_confirmed_not_machine_verified.

Warning: descriptive_comparison_no_test_or_interval.
