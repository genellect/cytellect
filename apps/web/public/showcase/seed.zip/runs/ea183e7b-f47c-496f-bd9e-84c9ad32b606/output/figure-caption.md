# Figure legend

Per-field descriptive measurements: area_px (pixel²).
Points are regions; squares show the median within each field.
4432 selected observations are shown across all 3 pages.
Observation and field counts do not denote independent experimental replicates. Independent experimental units were not assessed in this descriptive analysis.
No hypothesis test, regression, standard error or confidence interval was calculated. Acquisition comparability has not been established.
Quartiles describe the observed distribution, not uncertainty; linear interpolation uses h=(n−1)p.
Input=4432; explicitly excluded=0; outside saved selection=0; missing metric=0.
Horizontal jitter affects display only (seed 0); values and selection are unchanged.

Field / source mapping:
- Field 1: field_id=04a19e78-9b57-4933-b8f1-4d7d0d5f8577; selected=47; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 2: field_id=07df66a1-be8f-40b3-addd-bb70eabe12fe; selected=332; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 3: field_id=19c99305-95d3-419b-b325-61010578dd41; selected=87; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 4: field_id=253175ce-2933-4c32-919a-15c352eddd23; selected=45; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 5: field_id=2720cd88-24d4-47e8-94ca-c272cf7a2740; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 6: field_id=2a0f577a-0a04-45ac-8aa1-e05300bba6eb; selected=116; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 7: field_id=39968f54-2abd-43ea-834c-d1776af9ff44; selected=44; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 8: field_id=4a152777-d904-4c5b-9e71-0f07751562a5; selected=37; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 9: field_id=4cde2189-6c76-45c6-ad62-9a291db22fdc; selected=452; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 10: field_id=6f951bde-e2ce-4b8c-8295-58f1a7cec1f0; selected=376; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 11: field_id=78c27781-12ea-45b0-85f1-a5d62c2784d9; selected=295; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 12: field_id=901ecd25-4f3c-4911-a2c2-a5a6edbe1d75; selected=471; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 13: field_id=b3a6ab70-2b70-4563-ae4f-bfb32c949e3b; selected=119; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 14: field_id=bf56ca07-fe61-4e2d-b1fc-fa3738e22f52; selected=244; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 15: field_id=cf35ae53-5250-4f57-9ba3-48e051ce9550; selected=56; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 16: field_id=de4fc7b5-d86c-4365-a143-f4d224423e6e; selected=446; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 17: field_id=dff593d6-d502-4b52-ae88-02fa33419d05; selected=503; status=selected; definition=核; Hoechst (stain=Hoechst)
- Field 18: field_id=fbb1c988-d5b0-43e1-83ae-8561fe1f70ac; selected=643; status=selected; definition=核; Hoechst (stain=Hoechst)

Selection reasons, source revisions, masks, backgrounds and channel identities are recorded in figure-data.json and source tables. Review the recorded measurement definition before publication.
A journal-size preset controls formatting; it does not establish biological validity or journal acceptance.
- descriptive_independence_not_assessed
- acquisition_comparability_not_established

Page / saved field mapping (field numbers are global; all pages share one Y scale):
- Page 1: Field 1: field_id=04a19e78-9b57-4933-b8f1-4d7d0d5f8577; Field 2: field_id=07df66a1-be8f-40b3-addd-bb70eabe12fe; Field 3: field_id=19c99305-95d3-419b-b325-61010578dd41; Field 4: field_id=253175ce-2933-4c32-919a-15c352eddd23; Field 5: field_id=2720cd88-24d4-47e8-94ca-c272cf7a2740; Field 6: field_id=2a0f577a-0a04-45ac-8aa1-e05300bba6eb; Field 7: field_id=39968f54-2abd-43ea-834c-d1776af9ff44; Field 8: field_id=4a152777-d904-4c5b-9e71-0f07751562a5
- Page 2: Field 9: field_id=4cde2189-6c76-45c6-ad62-9a291db22fdc; Field 10: field_id=6f951bde-e2ce-4b8c-8295-58f1a7cec1f0; Field 11: field_id=78c27781-12ea-45b0-85f1-a5d62c2784d9; Field 12: field_id=901ecd25-4f3c-4911-a2c2-a5a6edbe1d75; Field 13: field_id=b3a6ab70-2b70-4563-ae4f-bfb32c949e3b; Field 14: field_id=bf56ca07-fe61-4e2d-b1fc-fa3738e22f52; Field 15: field_id=cf35ae53-5250-4f57-9ba3-48e051ce9550; Field 16: field_id=de4fc7b5-d86c-4365-a143-f4d224423e6e
- Page 3: Field 17: field_id=dff593d6-d502-4b52-ae88-02fa33419d05; Field 18: field_id=fbb1c988-d5b0-43e1-83ae-8561fe1f70ac
